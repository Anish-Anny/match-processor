#!/bin/bash
# Name all the files to copyas a comma separated list
export FILE_TO_COPY="auth_match.jar"

# Backup folder
export BACKUP_FOLDER="/amex/gms/AuthMatch/tmp/"

# Destination folder
export DEST_FOLDER="/amex/gms/AuthMatch/"

#SRC dir, not needed in the final script
export SRC_FOLDER="../../"

# Enviorment Command
n=$HOSTNAME
if [ "$n" = "lpdosput50501.phx.aexp.com" ] || [ "$n" = "lpdosput50503.phx.aexp.com" ]
then
        ENV="e1"
        DData="ipc1"
        FLAG="N"
        RTFenv="e1"
fi

if [ "$n" = "lpqosput50164.phx.aexp.com" ] || [ "$n" = "lpqosput50163.phx.aexp.com" ] || [ "$n" = "lpqosput50160.phx.aexp.com" ]
then 
	  ENV="e2_dc1"
	  DData="ipc1"
	  FLAG="N"
	  RTFenv="e2"
fi 

if [ "$n" = "lpposput50157.phx.aexp.com" ] || [ "$n" = "lpposput50158.phx.aexp.com" ] || [ "$n" = "lpposput50159.phx.aexp.com" ] || [ "$n" = "lpposput50160.phx.aexp.com" ] || [ "$n" = "lpposput50161.phx.aexp.com" ] || [ "$n" = "lpposput50162.phx.aexp.com" ]
then 
	  ENV="e3_ipc1"
	  DData="e3_ipc1"
	  FLAG="N"
	  RTFenv="e3"
fi 

if [ "$n" = "lgposput60213.gso.aexp.com" ] || [ "$n" = "lgposput60214.gso.aexp.com" ] || [ "$n" = "lgposput60215.gso.aexp.com" ] || [ "$n" = "lgposput60217.gso.aexp.com" ] || [ "$n" = "lgposput60219.gso.aexp.com" ] || [ "$n" = "lgposput60220.gso.aexp.com" ]
then 
	  ENV="e3_ipc2"
	  DData="e3_ipc2"
	  FLAG="N"
	  RTFenv="e3"
fi 
export $ENV
export $DData
export $FLAG
export $RTFenv