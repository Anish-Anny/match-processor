#!/bin/bash
# Script to rollback changes made during install script execution

# Call the set environment script to set variable
source setenv.sh

# getting temp directory for backup, assuming rollback on same day
TMP_DIR="$(date +"backup_%d_%m_%Y")"

# Loop through the file list and restore from backup
for file in ${FILE_TO_COPY//,/ }
do
   echo "Restoring $file from $BACKUP_FOLDER$TMP_DIR"
   /bin/su -c "mv $BACKUP_FOLDER$TMP_DIR/$file $DEST_FOLDER" gridgain
done
echo "********* Rollback of files completed *********" 

echo "********* Removing the backup directory *********"
/bin/su -c "rmdir $BACKUP_FOLDER$TMP_DIR" gridgain

echo "********* Starting Application *********"
cd /amex/gms/AuthMatch
for pid in ` ps aux | grep server.port=8383 | awk '{print $2}'` ; do kill $pid ; done
sleep 10
/bin/su -c "nohup java -Xms512m -Xmx512m -jar -Dspring.profiles.active=$ENV  -DAIM_ID=41140955 -DAPP_NAME=GMS_AUTH_MATCH -Dlog4j.configurationFile=log4j2.xml -Dserver.port=8383 -Denv=$ENV -Ddata-center=$DData -Djava.net.preferIPv4Stack=true -DcassandraDisableFlag=$FLAG auth_match.jar >/dev/null 2>&1 &" gridgain
echo "********* Process finished *********"
exit 0 