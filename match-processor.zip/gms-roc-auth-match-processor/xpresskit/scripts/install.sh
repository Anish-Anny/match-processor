#!/bin/bash
# Script to move files from packaged artifact to different directories on the server

# Call the set environment script to set variable
source setenv.sh
# Back up all files before making any changes.

# Termination for AuthMatch program will fail if application not terminated before install
for pid in ` ps aux | grep server.port=8383 | grep auth_match.jar | awk '{print $2}'` ; do kill $pid ; done
sleep 10 
echo "Killing RAM with PID: $pid"
for pid in ` ps aux | grep server.port=8383 | grep auth_match.jar | awk '{print $2}'` ; do proc=$pid ; done
if [ -v proc ];then
        echo "Application is still running, waiting 20 seconds."
        sleep 20
fi
for pid in ` ps aux | grep server.port=8383 | grep auth_match.jar | awk '{print $2}'` ; do proc2=$pid ; done
if [ -v proc2 ];then
        echo "Application is still not terminated waiting another 20 seconds."
        sleep 20
fi
for pid in ` ps aux | grep server.port=8383 | grep auth_match.jar | awk '{print $2}'` ; do proc3=$pid ; done
if [ -v proc3 ];then
        echo "Application failed to terminate, deployment failure"
        exit 1
fi

# create a temp directory for backup
TMP_DIR="$(date +"backup_%d_%m_%Y")"
/bin/su -c "mkdir -p $BACKUP_FOLDER""$TMP_DIR" gridgain

echo ""
echo "********* Back up of files starting *********" 
# Loop through the file list and backup the file
for file in ${FILE_TO_COPY//,/ }
do
    if [ -e "$DEST_FOLDER$file" ]
    then
      echo "Taking back up of $file"
      /bin/su -c "mv $DEST_FOLDER$file $BACKUP_FOLDER$TMP_DIR" gridgain
    else
      echo "$file not present in $DEST_FOLDER"
      exit 1
    fi
done
echo "********* Back up of files completed *********" 

echo ""
echo "********* Copying latest  files starting *********"
# Loop through the file list and move it to destination folder
for file in ${FILE_TO_COPY//,/ }
do
	if [ -e "$SRC_FOLDER$file" ]
	then
    	echo "Moving $file to $DEST_FOLDER"
    	/bin/su -c "mv $SRC_FOLDER$file $DEST_FOLDER" gridgain
	else 
		echo "$file not present in $SRC_FOLDER"
		exit 1
	fi
done
echo "********* Copying latest  files completed *********"
echo "********* Starting Application *********"
cd /amex/gms/AuthMatch
/bin/su -c "nohup java -Xms512m -Xmx512m -jar -Dspring.profiles.active=$ENV -DAIM_ID=41140955 -Drtf_client_env=$RTFenv -DAPP_NAME=GMS_AUTH_MATCH -Dlog4j.configurationFile=log4j2.xml -Dserver.port=8383 -Denv=$ENV -Ddata-center=$DData -Djava.net.preferIPv4Stack=true -DcassandraDisableFlag=$FLAG auth_match.jar >/dev/null 2>&1 &" gridgain
echo "********* Process finished *********"
exit 0 



