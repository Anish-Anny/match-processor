package com.aexp.gms.risk.authmatch.test.model;

import com.aexp.gms.risk.authmatch.rest.client.BackoffJitter;
import com.aexp.gms.risk.authmatch.rest.client.CasHighRiskAssessApi;
import com.aexp.gms.risk.authmatch.rest.client.RiskRestClientErrorHandler;
import org.junit.Test;

public class CasHighRiskAssessApiTest {
  RiskRestClientErrorHandler riskRestClientErrorHandler = new RiskRestClientErrorHandler();
  private static BackoffJitter BackoffJitter;

  @Test
  public void testInit() {

    CasHighRiskAssessApi casHighRiskAssessApi =
        new CasHighRiskAssessApi(riskRestClientErrorHandler, BackoffJitter);

    casHighRiskAssessApi.init();
  }
}
