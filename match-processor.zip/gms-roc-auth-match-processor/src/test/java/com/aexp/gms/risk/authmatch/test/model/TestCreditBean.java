package com.aexp.gms.risk.authmatch.test.model;

import com.aexp.gms.risk.authmatch.model.HighRiskAssesmentRequest;
import com.aexp.gms.risk.authmatch.model.HighRiskAssesmentResponse;
import com.aexp.gms.risk.authmatch.model.RiskAssessmentRequest;
import com.aexp.gms.risk.authmatch.model.RiskAssessmentResponse;
import org.junit.Test;

public class TestCreditBean {
  @Test
  public void testHighRiskAssesmentResponse() {
    HighRiskAssesmentResponse highRiskAssesmentResponse = new HighRiskAssesmentResponse();
    RiskAssessmentResponse risk_assesment = new RiskAssessmentResponse();
    highRiskAssesmentResponse.getRisk_assessment();
    highRiskAssesmentResponse.setRisk_assessment(null);
  }

  @Test
  public void testHighRiskAssesmentRequest() {
    RiskAssessmentRequest risk_assesment = new RiskAssessmentRequest();
    HighRiskAssesmentRequest highRiskAssesmentRequest =
        new HighRiskAssesmentRequest(risk_assesment);

    highRiskAssesmentRequest.getRisk_assessment();
    highRiskAssesmentRequest.setRisk_assessment(null);
  }
}
