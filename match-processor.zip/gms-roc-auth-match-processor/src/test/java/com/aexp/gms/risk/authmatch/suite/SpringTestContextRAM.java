package com.aexp.gms.risk.authmatch.suite;

import java.io.IOException;
import java.util.Map;
import org.apache.thrift.transport.TTransportException;
import org.cassandraunit.utils.EmbeddedCassandraServerHelper;
import org.springframework.boot.test.context.ConfigFileApplicationContextInitializer;
import org.springframework.test.context.ContextConfiguration;
import org.yaml.snakeyaml.Yaml;

@ContextConfiguration(
    value = "classpath:authmatch-processor-spring-config.xml",
    initializers = ConfigFileApplicationContextInitializer.class)
public class SpringTestContextRAM {

  static {
    System.setProperty("env", "e0");
    System.setProperty("spring.profiles.active", "e0");
    System.setProperty("server.port", "8282");

    try {
      setupCassandra();
    } catch (TTransportException | IOException e) {
      e.printStackTrace();
    }
  }

  private static void setupCassandra() throws TTransportException, IOException {
    System.out.println("starting embedded cassandra");
    EmbeddedCassandraServerHelper.startEmbeddedCassandra(60000);

    createKeyspaceAndTables();
    Runtime.getRuntime()
        .addShutdownHook(
            new Thread(
                () -> {
                  System.out.println("shutdownhook123");
                  EmbeddedCassandraServerHelper.cleanEmbeddedCassandra();
                }));

    System.out.println("Embedded cassandra started successfully!");
  }

  private static void createKeyspaceAndTables() {
    Yaml yaml = new Yaml();
    Map<String, String> cql =
        (Map<String, String>)
            yaml.load(
                SpringTestContextRAM.class
                    .getClassLoader()
                    .getResourceAsStream("cassandra-embedded-setup.yml"));
    EmbeddedCassandraServerHelper.getSession().execute(cql.get("keyspace"));
    for (String key : cql.keySet()) {
      if (key.startsWith("table")) {
        EmbeddedCassandraServerHelper.getSession().execute(cql.get(key));
      }
    }
  }
}
