package com.aexp.gms.risk.authmatch.test.rest;

import com.aexp.gms.risk.authmatch.model.RiskAssessmentRequest;
import com.aexp.gms.risk.authmatch.model.RiskAssessmentResponse;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

public class RiskAssesmentTestData {

  private Map<RiskAssessmentRequest, RiskAssessmentResponse> map = new HashMap<>();

  public Map<RiskAssessmentRequest, RiskAssessmentResponse> getReleaseResponse() {
    RiskAssessmentRequest request = new RiskAssessmentRequest();
    request.setMerchant_number("2060016086");
    request.setPrimary_account_number("372269713911007");
    request.setRequested_amount(new BigDecimal("300.20"));

    RiskAssessmentResponse riskAssessmentResponse = new RiskAssessmentResponse();
    riskAssessmentResponse.setResponse_code("200");
    riskAssessmentResponse.setResponse_message("Release");

    map = new HashMap<RiskAssessmentRequest, RiskAssessmentResponse>();
    map.put(request, riskAssessmentResponse);
    return map;
  }

  public Map<RiskAssessmentRequest, RiskAssessmentResponse> getRejectResponse() {
    RiskAssessmentRequest request = new RiskAssessmentRequest();
    request.setMerchant_number("2060016086");
    request.setPrimary_account_number("372269713911006");
    request.setRequested_amount(new BigDecimal("300.20"));

    RiskAssessmentResponse riskAssessmentResponse = new RiskAssessmentResponse();
    riskAssessmentResponse.setResponse_code("200");

    riskAssessmentResponse.setResponse_message("Reject");

    map = new HashMap<RiskAssessmentRequest, RiskAssessmentResponse>();
    map.put(request, riskAssessmentResponse);
    return map;
  }

  public Map<RiskAssessmentRequest, RiskAssessmentResponse> getIneligibleResponse() {
    RiskAssessmentRequest request = new RiskAssessmentRequest();
    request.setMerchant_number("2060016086");
    request.setPrimary_account_number("372269713911005");
    request.setRequested_amount(new BigDecimal("300.20"));

    RiskAssessmentResponse riskAssessmentResponse = new RiskAssessmentResponse();
    riskAssessmentResponse.setResponse_code("200");

    riskAssessmentResponse.setResponse_message("Ineligible");

    map = new HashMap<RiskAssessmentRequest, RiskAssessmentResponse>();
    map.put(request, riskAssessmentResponse);
    return map;
  }
}
