package com.aexp.gms.risk.authmatch.test.services;

import com.aexp.gms.imc.risk.rules.vo.values.CasAuthCardAccessCode2CacheBean;
import com.aexp.gms.imc.risk.rules.vo.values.CasAuthCardAccessCode6CacheBean;
import com.aexp.gms.imc.risk.rules.vo.values.CasAuthTransIdCardCacheBean2;
import com.aexp.gms.risk.authmatch.services.AuthMatchServiceImpl;
import com.aexp.gms.risk.authmatch.util.AuthMatchLog;
import com.aexp.gms.risk.authmatch.util.AuthMatchUtil;
import com.aexp.gms.risk.authmatch.util.ITier;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

public class TestData {
  public static final Map<String, String> unMatch = new HashMap<String, String>();
  public static final Map<String, String> loadInput1Map = new HashMap<String, String>();
  public static final Map<String, String> loadInput2Map = new HashMap<String, String>();
  public static final Map<String, String> loadInput2aMap = new HashMap<String, String>();

  public static final Map<String, String> loadInput2LocalAmountMap = new HashMap<String, String>();
  public static final Map<String, String> loadInput3aMap = new HashMap<String, String>();
  public static final Map<String, String> loadInput3b1Map = new HashMap<String, String>();
  public static final Map<String, String> loadInput3b2Map = new HashMap<String, String>();
  public static final Map<String, String> loadInput3c1Map = new HashMap<String, String>();
  public static final Map<String, String> loadInput3c2Map = new HashMap<String, String>();
  public static final Map<String, String> loadInput3c21Map = new HashMap<String, String>();
  public static final Map<String, String> loadInput4Map = new HashMap<String, String>();
  public static final Map<String, String> loadInput4aMap = new HashMap<String, String>();

  public static final Map<String, String> loadInput5Map = new HashMap<String, String>();
  public static final Map<String, String> loadInput6Map = new HashMap<String, String>();
  public static final Map<String, String> loadInput6aMap = new HashMap<String, String>();

  public static final Map<String, String> loadInput7Map = new HashMap<String, String>();
  public static final Map<String, String> loadInput81Map = new HashMap<String, String>();
  public static final Map<String, String> loadInput82Map = new HashMap<String, String>();
  public static final Map<String, String> loadInput83Map = new HashMap<String, String>();
  public static final Map<String, String> loadInput84Map = new HashMap<String, String>();
  public static final Map<String, String> loadInput9Map = new HashMap<String, String>();
  public static final Map<String, String> loadInput11Map = new HashMap<String, String>();

  private AuthMatchLog authMatchLog =
      new AuthMatchLog(AuthMatchServiceImpl.class.getPackage().getName());
  private final Logger LOGGER = LoggerFactory.getLogger(AuthMatchServiceImpl.class);
  private final SimpleDateFormat CAS_AUTHORIZATION_DATE_FORMAT =
      new SimpleDateFormat("MMddyy HHmmss");
  private final SimpleDateFormat defaultDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
  private final String CLASS_NAME = "TestData";
  CasAuthTransIdCardCacheBean2 transCardBean = null;
  CasAuthCardAccessCode6CacheBean cardDac6Bean = null;
  CasAuthCardAccessCode2CacheBean cardDac2Bean = null;

  static {
    unMatch.put("lwrcc_7kfrc", "200.44");
    unMatch.put("lwraw_frgnind", "1");
    unMatch.put("lwrcw_7etrid", "000000000012345");
    unMatch.put("lwrisocur", "USD");
    unMatch.put("cr41tcntry2", "US");
    unMatch.put("cr41wwic", "RET");
    unMatch.put("cr41mcc", "5555");
    unMatch.put("lwrdx_7ksep", "I");
    unMatch.put("lwrisoamt", "200.44");
    unMatch.put("lwrrr_kapc", "14");
    unMatch.put("lwrisoact", "370000000000221");
    unMatch.put("lwrcx_mgstrpcd", "1");
    unMatch.put("lwrcw_dadc", "8");
    unMatch.put("lwrrr_7dap6", "123456");
    unMatch.put("lwrcw_7dlog", "12345678");
    unMatch.put("lwrisoaid", "9429531213");
    unMatch.put("lwrdgod", "101112");
    unMatch.put("lwrgm_zprobfb", ": 0.657,");
    unMatch.put("lwrdtim", "100000");
    loadInput1Map.put("lwrcc_7kfrc", "200.44");
    loadInput1Map.put("lwraw_frgnind", "1");
    loadInput1Map.put("lwrcw_7etrid", "000000000000200");
    loadInput1Map.put("lwrisocur", "USD");
    loadInput1Map.put("cr41tcntry2", "US");
    loadInput1Map.put("cr41wwic", "RET");
    loadInput1Map.put("cr41mcc", "5555");
    loadInput1Map.put("lwrdx_7ksep", "I");
    loadInput1Map.put("lwrisoamt", "200.44");
    loadInput1Map.put("lwrrr_kapc", "14");
    loadInput1Map.put("lwrisoact", "370000000000200");
    loadInput1Map.put("lwrcx_mgstrpcd", "1");
    loadInput1Map.put("lwrcw_dadc", "8");
    loadInput1Map.put("lwrrr_7dap6", "123456");
    loadInput1Map.put("lwrcw_7dlog", "12345678");
    loadInput1Map.put("lwrisoaid", "9429531213");
    loadInput1Map.put("lwrdgod", "101112");
    loadInput1Map.put("lwrgm_zprobfb", ": 0.657,");
    loadInput1Map.put("lwrdtim", "100000");

    loadInput2aMap.put("lwrcc_7kfrc", "200.44");
    loadInput2aMap.put("lwraw_frgnind", "1");
    loadInput2aMap.put("lwrcw_7etrid", "000000000000200");
    loadInput2aMap.put("lwrisocur", "USD");
    loadInput2aMap.put("cr41tcntry2", "US");
    loadInput2aMap.put("cr41wwic", "RET");
    loadInput2aMap.put("cr41mcc", "5555");
    loadInput2aMap.put("lwrdx_7ksep", "I");
    loadInput2aMap.put("lwrisoamt", "200.44");
    loadInput2aMap.put("lwrrr_kapc", "14");
    loadInput2aMap.put("lwrisoact", "370000000000200");
    loadInput2aMap.put("lwrcx_mgstrpcd", "1");
    loadInput2aMap.put("lwrcw_dadc", "1");
    loadInput2aMap.put("lwrrr_7dap6", "123456");
    loadInput2aMap.put("lwrcw_7dlog", "12345678");
    loadInput2aMap.put("lwrisoaid", "9429531213");
    loadInput2aMap.put("lwrdgod", "101112");
    loadInput2aMap.put("lwrgm_zprobfb", ": 0.657,");
    loadInput2aMap.put("lwrdtim", "100000");

    loadInput2Map.put("lwrcc_7kfrc", "10.99");
    loadInput2Map.put("lwraw_frgnind", "1");
    loadInput2Map.put("lwrisocur", "USD");
    loadInput2Map.put("cr41tcntry2", "US");
    loadInput2Map.put("cr41wwic", "RET");
    loadInput2Map.put("cr41mcc", "5555");
    loadInput2Map.put("lwrdx_7ksep", "I");
    loadInput2Map.put("lwrisoamt", "200.44");
    loadInput2Map.put("lwrrr_kapc", "14");
    loadInput2Map.put("lwrisoact", "371000000000202");
    loadInput2Map.put("lwrcx_mgstrpcd", "1");
    loadInput2Map.put("lwrcw_dadc", "1");
    loadInput2Map.put("lwrrr_7dap6", "123456");
    loadInput2Map.put("lwrcw_7dlog", "12345679");
    loadInput2Map.put("lwrisoaid", "9429531213");
    loadInput2Map.put("lwrdgod", "101112");
    loadInput2Map.put("lwrgm_zprobfb", ": 0.657,");
    loadInput2Map.put("lwrdtim", "100000");
    loadInput2Map.put("lwrcw_7etrid", "001000000000202");

    loadInput2LocalAmountMap.put("lwrcc_7kfrc", "10.99");
    loadInput2LocalAmountMap.put("lwraw_frgnind", "1");
    loadInput2LocalAmountMap.put("lwrisocur", "USD");
    loadInput2LocalAmountMap.put("cr41tcntry2", "US");
    loadInput2LocalAmountMap.put("cr41wwic", "RET");
    loadInput2LocalAmountMap.put("cr41mcc", "5555");
    loadInput2LocalAmountMap.put("lwrdx_7ksep", "I");
    loadInput2LocalAmountMap.put("lwrisoamt", "200.44");
    loadInput2LocalAmountMap.put("lwrrr_kapc", "14");
    loadInput2LocalAmountMap.put("lwrisoact", "371700000000202");
    loadInput2LocalAmountMap.put("lwrcx_mgstrpcd", "1");
    loadInput2LocalAmountMap.put("lwrcw_dadc", "1");
    loadInput2LocalAmountMap.put("lwrrr_7dap6", "123456");
    loadInput2LocalAmountMap.put("lwrcw_7dlog", "12345679");
    loadInput2LocalAmountMap.put("lwrisoaid", "9429531213");
    loadInput2LocalAmountMap.put("lwrdgod", "101112");
    loadInput2LocalAmountMap.put("lwrgm_zprobfb", ": 0.657,");
    loadInput2LocalAmountMap.put("lwrdtim", "100000");
    loadInput2LocalAmountMap.put("lwrcw_7etrid", "001000000000202");

    loadInput3aMap.put("lwrcc_7kfrc", "10.99");
    loadInput3aMap.put("lwraw_frgnind", "1");
    loadInput3aMap.put("lwrisocur", "USD");
    loadInput3aMap.put("cr41tcntry2", "US");
    loadInput3aMap.put("cr41wwic", "RET");
    loadInput3aMap.put("cr41mcc", "5555");
    loadInput3aMap.put("lwrdx_7ksep", "I");
    loadInput3aMap.put("lwrisoamt", "200.44");
    loadInput3aMap.put("lwrrr_kapc", "14");
    loadInput3aMap.put("lwrisoact", "371000000000201");
    loadInput3aMap.put("lwrcx_mgstrpcd", "1");
    loadInput3aMap.put("lwrcw_dadc", "1");
    loadInput3aMap.put("lwrrr_7dap6", "123456");
    loadInput3aMap.put("lwrcw_7dlog", "12345679");
    loadInput3aMap.put("lwrisoaid", "9429531213");
    loadInput3aMap.put("lwrdgod", "101112");
    loadInput3aMap.put("lwrgm_zprobfb", ": 0.657,");
    loadInput3aMap.put("lwrdtim", "100000");
    loadInput3aMap.put("lwrcw_7etrid", "001000000000201");

    loadInput3b1Map.put("lwrcc_7kfrc", "10.99");
    loadInput3b1Map.put("lwraw_frgnind", "1");
    loadInput3b1Map.put("lwrisocur", "USD");
    loadInput3b1Map.put("cr41tcntry2", "US");
    loadInput3b1Map.put("cr41wwic", "RET");
    loadInput3b1Map.put("cr41mcc", "5555");
    loadInput3b1Map.put("lwrdx_7ksep", "I");
    loadInput3b1Map.put("lwrisoamt", "200.44");
    loadInput3b1Map.put("lwrrr_kapc", "14");
    loadInput3b1Map.put("lwrisoact", "371710000000543");
    loadInput3b1Map.put("lwrcx_mgstrpcd", "1");
    loadInput3b1Map.put("lwrcw_dadc", "1");
    loadInput3b1Map.put("lwrrr_7dap6", "123456");
    loadInput3b1Map.put("lwrcw_7dlog", "12345679");
    loadInput3b1Map.put("lwrisoaid", "9429531213");
    loadInput3b1Map.put("lwrdgod", "101112");
    loadInput3b1Map.put("lwrgm_zprobfb", ": 0.657,");
    loadInput3b1Map.put("lwrdtim", "100000");
    loadInput3b1Map.put("lwrcw_7etrid", "001100000000201");

    loadInput3b2Map.put("lwrcc_7kfrc", "10.99");
    loadInput3b2Map.put("lwraw_frgnind", "1");
    loadInput3b2Map.put("lwrisocur", "USD");
    loadInput3b2Map.put("cr41tcntry2", "US");
    loadInput3b2Map.put("cr41wwic", "RET");
    loadInput3b2Map.put("cr41mcc", "5555");
    loadInput3b2Map.put("lwrdx_7ksep", "I");
    loadInput3b2Map.put("lwrisoamt", "100.44");
    loadInput3b2Map.put("lwrrr_kapc", "14");
    loadInput3b2Map.put("lwrisoact", "371710000000543");
    loadInput3b2Map.put("lwrcx_mgstrpcd", "1");
    loadInput3b2Map.put("lwrcw_dadc", "1");
    loadInput3b2Map.put("lwrrr_7dap6", "123456");
    loadInput3b2Map.put("lwrcw_7dlog", "12345679");
    loadInput3b2Map.put("lwrisoaid", "9429531213");
    loadInput3b2Map.put("lwrdgod", "101112");
    loadInput3b2Map.put("lwrgm_zprobfb", ": 0.657,");
    loadInput3b2Map.put("lwrdtim", "100000");
    loadInput3b2Map.put("lwrcw_7etrid", "001200000000201");

    loadInput3c1Map.put("lwrcc_7kfrc", "10.99");
    loadInput3c1Map.put("lwraw_frgnind", "1");
    loadInput3c1Map.put("lwrisocur", "USD");
    loadInput3c1Map.put("cr41tcntry2", "US");
    loadInput3c1Map.put("cr41wwic", "RET");
    loadInput3c1Map.put("cr41mcc", "5555");
    loadInput3c1Map.put("lwrdx_7ksep", "I");
    loadInput3c1Map.put("lwrisoamt", "70");
    loadInput3c1Map.put("lwrrr_kapc", "14");
    loadInput3c1Map.put("lwrisoact", "375000000000201");
    loadInput3c1Map.put("lwrcx_mgstrpcd", "1");
    loadInput3c1Map.put("lwrcw_dadc", "1");
    loadInput3c1Map.put("lwrrr_7dap6", "123456");
    loadInput3c1Map.put("lwrcw_7dlog", "12345690");
    loadInput3c1Map.put("lwrisoaid", "9429531213");
    loadInput3c1Map.put("lwrdgod", "101112");
    loadInput3c1Map.put("lwrgm_zprobfb", ": 0.657,");
    loadInput3c1Map.put("lwrdtim", "102000");
    loadInput3c1Map.put("lwrcw_7etrid", "005000000000201");

    loadInput3c2Map.put("lwrcc_7kfrc", "10.99");
    loadInput3c2Map.put("lwraw_frgnind", "1");
    loadInput3c2Map.put("lwrisocur", "USD");
    loadInput3c2Map.put("cr41tcntry2", "US");
    loadInput3c2Map.put("cr41wwic", "RET");
    loadInput3c2Map.put("cr41mcc", "5555");
    loadInput3c2Map.put("lwrdx_7ksep", "I");
    loadInput3c2Map.put("lwrisoamt", "850");
    loadInput3c2Map.put("lwrrr_kapc", "14");
    loadInput3c2Map.put("lwrisoact", "376000000000201");
    loadInput3c2Map.put("lwrcx_mgstrpcd", "1");
    loadInput3c2Map.put("lwrcw_dadc", "1");
    loadInput3c2Map.put("lwrrr_7dap6", "123456");
    loadInput3c2Map.put("lwrcw_7dlog", "12345690");
    loadInput3c2Map.put("lwrisoaid", "9429531213");
    loadInput3c2Map.put("lwrdgod", "101112");
    loadInput3c2Map.put("lwrgm_zprobfb", ": 0.657,");
    loadInput3c2Map.put("lwrdtim", "102000");
    loadInput3c2Map.put("lwrcw_7etrid", "006000000000201");

    loadInput3c21Map.put("lwrcc_7kfrc", "850");
    loadInput3c21Map.put("lwraw_frgnind", "1");
    loadInput3c21Map.put("lwrisocur", "USD");
    loadInput3c21Map.put("cr41tcntry2", "US");
    loadInput3c21Map.put("cr41wwic", "RET");
    loadInput3c21Map.put("cr41mcc", "5555");
    loadInput3c21Map.put("lwrdx_7ksep", "I");
    loadInput3c21Map.put("lwrisoamt", "850");
    loadInput3c21Map.put("lwrrr_kapc", "14");
    loadInput3c21Map.put("lwrisoact", "376000000000201");
    loadInput3c21Map.put("lwrcx_mgstrpcd", "1");
    loadInput3c21Map.put("lwrcw_dadc", "1");
    loadInput3c21Map.put("lwrrr_7dap6", "123456");
    loadInput3c21Map.put("lwrcw_7dlog", "12345690");
    loadInput3c21Map.put("lwrisoaid", "9429531213");
    loadInput3c21Map.put("lwrdgod", "101112");
    loadInput3c21Map.put("lwrgm_zprobfb", ": 0.657,");
    loadInput3c21Map.put("lwrdtim", "102000");
    loadInput3c21Map.put("lwrcw_7etrid", "006100000000201");

    loadInput4Map.put("lwrcc_7kfrc", "0");
    loadInput4Map.put("lwraw_frgnind", "0");
    loadInput4Map.put("lwrcw_7etrid", "006145570697679");
    loadInput4Map.put("lwrisocur", "USD");
    loadInput4Map.put("cr41tcntry2", "US");
    loadInput4Map.put("cr41wwic", "561");
    loadInput4Map.put("cr41mcc", "5968");
    loadInput4Map.put("lwrdx_7ksep", "J");
    loadInput4Map.put("lwrisoamt", "96.00");
    loadInput4Map.put("lwrrr_kapc", "32");
    loadInput4Map.put("lwrisoact", "379803969091008");
    loadInput4Map.put("lwrcx_mgstrpcd", "0");
    loadInput4Map.put("lwrcw_dadc", "0");
    loadInput4Map.put("lwrrr_7dap6", "104962");
    loadInput4Map.put("lwrcw_7dlog", "2122100254");
    loadInput4Map.put("lwrisoaid", "2201535275");
    loadInput4Map.put("lwrdgod", "071818");
    loadInput4Map.put("lwrgm_zprobfb", "0");
    loadInput4Map.put("lwrdtim", "113904");

    loadInput4aMap.put("lwrcc_7kfrc", "0");
    loadInput4aMap.put("lwraw_frgnind", "0");
    loadInput4aMap.put("lwrcw_7etrid", "006145570697679");
    loadInput4aMap.put("lwrisocur", "USD");
    loadInput4aMap.put("cr41tcntry2", "US");
    loadInput4aMap.put("cr41wwic", "561");
    loadInput4aMap.put("cr41mcc", "5968");
    loadInput4aMap.put("lwrdx_7ksep", "J");
    loadInput4aMap.put("lwrisoamt", "96.00");
    loadInput4aMap.put("lwrrr_kapc", "32");
    loadInput4aMap.put("lwrisoact", "379803969091008");
    loadInput4aMap.put("lwrcx_mgstrpcd", "0");
    loadInput4aMap.put("lwrcw_dadc", "0");
    loadInput4aMap.put("lwrrr_7dap6", "104962");
    loadInput4aMap.put("lwrcw_7dlog", "2122100254");
    loadInput4aMap.put("lwrisoaid", "2201535275");
    loadInput4aMap.put("lwrdgod", "071818");
    loadInput4aMap.put("lwrgm_zprobfb", "0");
    loadInput4aMap.put("lwrdtim", "113904");

    loadInput5Map.put("lwrcc_7kfrc", "0");
    loadInput5Map.put("lwraw_frgnind", "0");
    loadInput5Map.put("lwrcw_7etrid", "006145570697680");
    loadInput5Map.put("lwrisocur", "USD");
    loadInput5Map.put("cr41tcntry2", "US");
    loadInput5Map.put("cr41wwic", "561");
    loadInput5Map.put("cr41mcc", "5968");
    loadInput5Map.put("lwrdx_7ksep", "J");
    loadInput5Map.put("lwrisoamt", "96.00");
    loadInput5Map.put("lwrrr_kapc", "32");
    loadInput5Map.put("lwrisoact", "379803969091099");
    loadInput5Map.put("lwrcx_mgstrpcd", "0");
    loadInput5Map.put("lwrcw_dadc", "0");
    loadInput5Map.put("lwrrr_7dap6", "104962");
    loadInput5Map.put("lwrcw_7dlog", "2122100254");
    loadInput5Map.put("lwrisoaid", "2201535619");
    loadInput5Map.put("lwrdgod", "071818");
    loadInput5Map.put("lwrgm_zprobfb", "0");
    loadInput5Map.put("lwrdtim", "113904");

    loadInput6Map.put("lwrcc_7kfrc", "0");
    loadInput6Map.put("lwraw_frgnind", "0");
    loadInput6Map.put("lwrcw_7etrid", "006145570697105");
    loadInput6Map.put("lwrisocur", "USD");
    loadInput6Map.put("cr41tcntry2", "US");
    loadInput6Map.put("cr41wwic", "561");
    loadInput6Map.put("cr41mcc", "5968");
    loadInput6Map.put("lwrdx_7ksep", "J");
    loadInput6Map.put("lwrisoamt", "96.00");
    loadInput6Map.put("lwrrr_kapc", "32");
    loadInput6Map.put("lwrisoact", "377000000000105");
    loadInput6Map.put("lwrcx_mgstrpcd", "0");
    loadInput6Map.put("lwrcw_dadc", "0");
    loadInput6Map.put("lwrrr_7dap6", "104962");
    loadInput6Map.put("lwrcw_7dlog", "2122100254");
    loadInput6Map.put("lwrisoaid", "2201535275");
    loadInput6Map.put("lwrdgod", "071818");
    loadInput6Map.put("lwrgm_zprobfb", "0");
    loadInput6Map.put("lwrdtim", "113904");

    loadInput6aMap.put("lwrcc_7kfrc", "0");
    loadInput6aMap.put("lwraw_frgnind", "0");
    loadInput6aMap.put("lwrcw_7etrid", "006145570697105");
    loadInput6aMap.put("lwrisocur", "USD");
    loadInput6aMap.put("cr41tcntry2", "US");
    loadInput6aMap.put("cr41wwic", "561");
    loadInput6aMap.put("cr41mcc", "5968");
    loadInput6aMap.put("lwrdx_7ksep", "J");
    loadInput6aMap.put("lwrisoamt", "96.00");
    loadInput6aMap.put("lwrrr_kapc", "32");
    loadInput6aMap.put("lwrisoact", "377000000000105");
    loadInput6aMap.put("lwrcx_mgstrpcd", "0");
    loadInput6aMap.put("lwrcw_dadc", "0");
    loadInput6aMap.put("lwrrr_7dap6", "104962");
    loadInput6aMap.put("lwrcw_7dlog", "2122100254");
    loadInput6aMap.put("lwrisoaid", "2201535275");
    loadInput6aMap.put("lwrdgod", "071818");
    loadInput6aMap.put("lwrgm_zprobfb", "0");
    loadInput6aMap.put("lwrdtim", "113904");

    loadInput7Map.put("lwrcc_7kfrc", "0");
    loadInput7Map.put("lwraw_frgnind", "0");
    loadInput7Map.put("lwrcw_7etrid", "006145570697680");
    loadInput7Map.put("lwrisocur", "USD");
    loadInput7Map.put("cr41tcntry2", "US");
    loadInput7Map.put("cr41wwic", "561");
    loadInput7Map.put("cr41mcc", "5968");
    loadInput7Map.put("lwrdx_7ksep", "J");
    loadInput7Map.put("lwrisoamt", "96.00");
    loadInput7Map.put("lwrrr_kapc", "32");
    loadInput7Map.put("lwrisoact", "379803969091680");
    loadInput7Map.put("lwrcx_mgstrpcd", "0");
    loadInput7Map.put("lwrcw_dadc", "0");
    loadInput7Map.put("lwrrr_7dap6", "104962");
    loadInput7Map.put("lwrcw_7dlog", "2122100254");
    loadInput7Map.put("lwrisoaid", "2201535625");
    loadInput7Map.put("lwrdgod", "071818");
    loadInput7Map.put("lwrgm_zprobfb", "0");
    loadInput7Map.put("lwrdtim", "113904");

    loadInput81Map.put("lwrcc_7kfrc", "10.99");
    loadInput81Map.put("lwraw_frgnind", "1");
    loadInput81Map.put("lwrisocur", "USD");
    loadInput81Map.put("cr41tcntry2", "US");
    loadInput81Map.put("cr41wwic", "RET");
    loadInput81Map.put("cr41mcc", "5555");
    loadInput81Map.put("lwrdx_7ksep", "I");
    loadInput81Map.put("lwrisoamt", "180.00");
    loadInput81Map.put("lwrrr_kapc", "14");
    loadInput81Map.put("lwrisoact", "371100000000722");
    loadInput81Map.put("lwrcx_mgstrpcd", "1");
    loadInput81Map.put("lwrcw_dadc", "1");
    loadInput81Map.put("lwrrr_7dap6", "123456");
    loadInput81Map.put("lwrcw_7dlog", "12345679");
    loadInput81Map.put("lwrisoaid", "9429531213");
    loadInput81Map.put("lwrdgod", "071818");
    loadInput81Map.put("lwrgm_zprobfb", ": 0.657,");
    loadInput81Map.put("lwrdtim", "100000");
    loadInput81Map.put("lwrcw_7etrid", "001100000000201");

    loadInput82Map.put("lwrcc_7kfrc", "10.99");
    loadInput82Map.put("lwraw_frgnind", "1");
    loadInput82Map.put("lwrisocur", "USD");
    loadInput82Map.put("cr41tcntry2", "US");
    loadInput82Map.put("cr41wwic", "RET");
    loadInput82Map.put("cr41mcc", "5555");
    loadInput82Map.put("lwrdx_7ksep", "I");
    loadInput82Map.put("lwrisoamt", "90.00");
    loadInput82Map.put("lwrrr_kapc", "14");
    loadInput82Map.put("lwrisoact", "371100000000722");
    loadInput82Map.put("lwrcx_mgstrpcd", "1");
    loadInput82Map.put("lwrcw_dadc", "1");
    loadInput82Map.put("lwrrr_7dap6", "123456");
    loadInput82Map.put("lwrcw_7dlog", "12345679");
    loadInput82Map.put("lwrisoaid", "9429531213");
    loadInput82Map.put("lwrdgod", "071818");
    loadInput82Map.put("lwrgm_zprobfb", ": 0.657,");
    loadInput82Map.put("lwrdtim", "100000");
    loadInput82Map.put("lwrcw_7etrid", "002200000000201");

    loadInput83Map.put("lwrcc_7kfrc", "10.99");
    loadInput83Map.put("lwraw_frgnind", "1");
    loadInput83Map.put("lwrisocur", "USD");
    loadInput83Map.put("cr41tcntry2", "US");
    loadInput83Map.put("cr41wwic", "RET");
    loadInput83Map.put("cr41mcc", "5555");
    loadInput83Map.put("lwrdx_7ksep", "I");
    loadInput83Map.put("lwrisoamt", "60.00");
    loadInput83Map.put("lwrrr_kapc", "14");
    loadInput83Map.put("lwrisoact", "371100000000722");
    loadInput83Map.put("lwrcx_mgstrpcd", "1");
    loadInput83Map.put("lwrcw_dadc", "1");
    loadInput83Map.put("lwrrr_7dap6", "123456");
    loadInput83Map.put("lwrcw_7dlog", "12345679");
    loadInput83Map.put("lwrisoaid", "9429531213");
    loadInput83Map.put("lwrdgod", "071818");
    loadInput83Map.put("lwrgm_zprobfb", ": 0.657,");
    loadInput83Map.put("lwrdtim", "100000");
    loadInput83Map.put("lwrcw_7etrid", "002300000000201");

    loadInput84Map.put("lwrcc_7kfrc", "10.99");
    loadInput84Map.put("lwraw_frgnind", "1");
    loadInput84Map.put("lwrisocur", "USD");
    loadInput84Map.put("cr41tcntry2", "US");
    loadInput84Map.put("cr41wwic", "RET");
    loadInput84Map.put("cr41mcc", "5555");
    loadInput84Map.put("lwrdx_7ksep", "I");
    loadInput84Map.put("lwrisoamt", "30.00");
    loadInput84Map.put("lwrrr_kapc", "14");
    loadInput84Map.put("lwrisoact", "371100000000722");
    loadInput84Map.put("lwrcx_mgstrpcd", "1");
    loadInput84Map.put("lwrcw_dadc", "1");
    loadInput84Map.put("lwrrr_7dap6", "123456");
    loadInput84Map.put("lwrcw_7dlog", "12345679");
    loadInput84Map.put("lwrisoaid", "9429531213");
    loadInput84Map.put("lwrdgod", "071818");
    loadInput84Map.put("lwrgm_zprobfb", ": 0.657,");
    loadInput84Map.put("lwrdtim", "100000");
    loadInput84Map.put("lwrcw_7etrid", "002400000000201");

    loadInput9Map.put("lwrcc_7kfrc", "10.99");
    loadInput9Map.put("lwraw_frgnind", "1");
    loadInput9Map.put("lwrisocur", "USD");
    loadInput9Map.put("cr41tcntry2", "US");
    loadInput9Map.put("cr41wwic", "RET");
    loadInput9Map.put("cr41mcc", "5555");
    loadInput9Map.put("lwrdx_7ksep", "I");
    loadInput9Map.put("lwrisoamt", "250.11");
    loadInput9Map.put("lwrrr_kapc", "00");
    loadInput9Map.put("lwrisoact", "372200000000516");
    loadInput9Map.put("lwrcx_mgstrpcd", "1");
    loadInput9Map.put("lwrcw_dadc", "1");
    loadInput9Map.put("lwrrr_7dap6", "000000");
    loadInput9Map.put("lwrcw_7dlog", "12345679");
    loadInput9Map.put("lwrisoaid", "9429531213");
    loadInput9Map.put("lwrdgod", "101112");
    loadInput9Map.put("lwrgm_zprobfb", ": 0.657,");
    loadInput9Map.put("lwrdtim", "100000");
    loadInput9Map.put("lwrcw_7etrid", "000000000000000");

    loadInput11Map.put("lwrcc_7kfrc", "10.99");
    loadInput11Map.put("lwraw_frgnind", "1");
    loadInput11Map.put("lwrisocur", "USD");
    loadInput11Map.put("cr41tcntry2", "US");
    loadInput11Map.put("cr41wwic", "RET");
    loadInput11Map.put("cr41mcc", "5555");
    loadInput11Map.put("lwrdx_7ksep", "I");
    loadInput11Map.put("lwrisoamt", "1000");
    loadInput11Map.put("lwrrr_kapc", "14");
    loadInput11Map.put("lwrisoact", "372200000000221");
    loadInput11Map.put("lwrcx_mgstrpcd", "1");
    loadInput11Map.put("lwrcw_dadc", "1");
    loadInput11Map.put("lwrrr_7dap6", "123456");
    loadInput11Map.put("lwrcw_7dlog", "12345679");
    loadInput11Map.put("lwrisoaid", "9429531213");
    loadInput11Map.put("lwrdgod", "111018");
    loadInput11Map.put("lwrgm_zprobfb", "0.657");
    loadInput11Map.put("lwrdtim", "090000");
    loadInput11Map.put("lwrcw_7etrid", "000000000000000");
  }

  public static String notMatch =
      "{\"rocSENumber\":\"9097865666 \",\"rocCardNumber\":\"370000000000221 \",\"rocAuthorizationTransactionId\":\"000000000012345 \",\"rocTransactionDate\":\"2017-12-31\",\"rocTransactionTime\":\"23:59:00\",\"rocAmountUSD\":\"200.44 \",\n"
          + "\"rocAuthDAC\":\"123456\",\"socSEIndustryCategoryCode\":\"4018\",\"socMerchantCategoryCode\":\"1234\",\n"
          + " \n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\n"
          + "\"transactionType\":\"SUBM\"\n"
          + "}\n"
          + "";

  public static String matchInput1 =
      "{\"rocSENumber\":\"9097865666 \",\"rocCardNumber\":\"370000000000200 \",\"rocAuthorizationTransactionId\":\"000000000000200 \",\"rocTransactionDate\":\"2017-12-31\",\"rocTransactionTime\":\"23:59:00\",\"rocAmountUSD\":\"200.44 \",\n"
          + "\"rocAuthDAC\":\"123456\",\"socSEIndustryCategoryCode\":\"4018\",\"socMerchantCategoryCode\":\"1234\",\n"
          + " \n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\n"
          + "\"transactionType\":\"SUBM\"\n"
          + "}\n"
          + "";

  public static String matchInput2 =
      "{\"rocSENumber\":\"9097865666 \",\"rocCardNumber\":\"371000000000202 \",\"rocAuthorizationTransactionId\":\"001000000000202 \","
          + "\"rocTransactionDate\":\"2017-12-31\",\"rocTransactionTime\":\"23:59:00\",\"rocAmountUSD\":\"200.44 \",\r\n"
          + "\"rocAuthDAC\":\"123456\",\"socSEIndustryCategoryCode\":\"4018\",\"socMerchantCategoryCode\":\"1234\",\r\n"
          + " \r\n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\r\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\r\n"
          + "\"transactionType\":\"SUBM\"\r\n"
          + "}";

  public static String matchInput2_localAmount =
      "{\"rocSENumber\":\"9097865666 \",\"rocCardNumber\":\"371700000000202 \",\"rocAuthorizationTransactionId\":\"001000000000202 \",\"rocAmountUSD\":\"200.44 \",\"rocTransactionDate\":\"2017-12-31\",\"rocTransactionTime\":\"23:59:00\",\"rocLocalAmount\":\"20044\",\n"
          + "\"rocAuthDAC\":\"123456\",\"socSEIndustryCategoryCode\":\"4018\",\"socMerchantCategoryCode\":\"1234\",\n"
          + " \n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\n"
          + "\"transactionType\":\"SUBM\",\n"
          + "\"rocNetworkGeneratedTID\":\"111111111111111\",\n"
          + "\"rocLocalAmountCurrency\":\"USD\",\n"
          + "\"rocLocalDecimalPlaces\":\"2\"\n"
          + "}";

  public static String matchInput3a =
      "{\"rocSENumber\":\"9097865666 \",\"rocCardNumber\":\"371000000000201 \",\"rocAuthorizationTransactionId\":\"001000000000201 \",\"rocTransactionDate\":\"2017-12-31\",\"rocTransactionTime\":\"23:59:00\",\"rocAmountUSD\":\"100.44 \",\n"
          + "\"rocAuthDAC\":\"123456\",\"socSEIndustryCategoryCode\":\"4018\",\"socMerchantCategoryCode\":\"1234\",\n"
          + " \n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\n"
          + "\"transactionType\":\"SUBM\"\n"
          + "}\n"
          + "";

  public static String matchInput3a_localAmount =
      "{\"rocSENumber\":\"9097865666 \",\"rocCardNumber\":\"371700000000201 \",\"rocAuthorizationTransactionId\":\"001000000000201 \",\"rocTransactionDate\":\"2017-12-31\",\"rocTransactionTime\":\"23:59:00\",\"rocLocalAmount\":\"599\",\r\n"
          + "\"rocAuthDAC\":\"123456\",\"socSEIndustryCategoryCode\":\"4018\",\"socMerchantCategoryCode\":\"1234\",\"rocAmountUSD\":\"200.44 \",\r\n"
          + " \r\n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\r\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\r\n"
          + "\"transactionType\":\"SUBM\",\r\n"
          + "\"rocNetworkGeneratedTID\":\"111111111111112\",\r\n"
          + "\"rocLocalAmountCurrency\":\"USD\",\r\n"
          + "\"rocLocalDecimalPlaces\":\"2\"\r\n"
          + "}";

  public static String matchInput3a_multipleRoc1 =
      "{\"rocSENumber\":\"9097865666 \",\"rocCardNumber\":\"371000000000201 \",\"rocAuthorizationTransactionId\":\"001000000000201 \",\"rocTransactionDate\":\"2017-12-31\",\"rocTransactionTime\":\"23:59:00\",\"rocAmountUSD\":\"100.44 \",\n"
          + "\"rocAuthDAC\":\"123456\",\"socSEIndustryCategoryCode\":\"4018\",\"socMerchantCategoryCode\":\"1234\",\n"
          + " \n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\n"
          + "\"transactionType\":\"SUBM\"\n"
          + "}\n"
          + "";

  public static String matchInput3a_multipleRoc2 =
      "{\"rocSENumber\":\"9097865666 \",\"rocCardNumber\":\"371000000000201 \",\"rocAuthorizationTransactionId\":\"001000000000201 \",\"rocTransactionDate\":\"2017-12-31\",\"rocTransactionTime\":\"23:59:00\",\"rocAmountUSD\":\"100.00 \",\n"
          + "\"rocAuthDAC\":\"123456\",\"socSEIndustryCategoryCode\":\"4018\",\"socMerchantCategoryCode\":\"1234\",\n"
          + " \n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\n"
          + "\"transactionType\":\"SUBM\"\n"
          + "}\n"
          + "";
  public static String matchInput3a_multipleRoc1_WithLocal =
      "{\"rocSENumber\":\"9097865666 \",\"rocCardNumber\":\"371000000000201 \",\"rocAuthorizationTransactionId\":\"001000000000201 \",\"rocTransactionDate\":\"2017-12-31\",\"rocTransactionTime\":\"23:59:00\",\"rocLocalAmount\":\"400\",\r\n"
          + "\"rocAuthDAC\":\"123456\",\"socSEIndustryCategoryCode\":\"4018\",\"socMerchantCategoryCode\":\"1234\",\"rocAmountUSD\":\"180.00 \",\r\n"
          + " \r\n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\r\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\r\n"
          + "\"transactionType\":\"SUBM\",\r\n"
          + "\"rocNetworkGeneratedTID\":\"111111111111112\",\r\n"
          + "\"rocLocalAmountCurrency\":\"USD\",\r\n"
          + "\"rocLocalDecimalPlaces\":\"2\"\r\n"
          + "}";
  public static String matchInput3a_multipleRoc2_WithLocal =
      "{\"rocSENumber\":\"9097865666 \",\"rocCardNumber\":\"371000000000201 \",\"rocAuthorizationTransactionId\":\"001000000000201 \",\"rocTransactionDate\":\"2017-12-31\",\"rocTransactionTime\":\"23:59:00\",\"rocLocalAmount\":\"199\",\r\n"
          + "\"rocAuthDAC\":\"123456\",\"socSEIndustryCategoryCode\":\"4018\",\"socMerchantCategoryCode\":\"1234\",\"rocAmountUSD\":\"20.44 \",\r\n"
          + " \r\n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\r\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\r\n"
          + "\"transactionType\":\"SUBM\",\r\n"
          + "\"rocNetworkGeneratedTID\":\"111111111111112\",\r\n"
          + "\"rocLocalAmountCurrency\":\"USD\",\r\n"
          + "\"rocLocalDecimalPlaces\":\"2\"\r\n"
          + "}";

  public static String matchInput3b =
      "{\"rocSENumber\":\"9429531213 \",\"rocCardNumber\":\"371710000000543 \",\"rocAuthorizationTransactionId\":\"001100000000201 \",\"rocTransactionDate\":\"2012-10-11\",\"rocTransactionTime\":\"23:59:00\",\"rocAmountUSD\":\"300.88 \",\n"
          + "\"rocAuthDAC\":\"123456\",\"socSEIndustryCategoryCode\":\"4018\",\"socMerchantCategoryCode\":\"1234\",\n"
          + " \n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\n"
          + "\"transactionType\":\"SUBM\"\n"
          + "}\n"
          + "";
  /*public static String matchInput3b = "{\"rocSENumber\":\"9429531213 \",\"rocCardNumber\":\"372000000000201\",\"rocAuthorizationTransactionId\":\"003000000000201\",\"rocTransactionDate\":\"2017-12-31\",\"rocTransactionTime\":\"23:59:00\",\"rocAmountUSD\":\"300.44\",\n" +
  "\"rocAuthDAC\":\"123456\",\"socSEIndustryCategoryCode\":\"4018\",\"socMerchantCategoryCode\":\"1234\",\n" +
  " \n" +
  "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006\",\n" +
  "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008\",\n" +
  "\"transactionType\":\"SUBM\"\n" +
  "}\n" +
  "";
  */

  public static String matchInput3c_1 =
      "{\"rocSENumber\":\"9429531213 \",\"rocCardNumber\":\"375000000000201 \",\"rocAuthorizationTransactionId\":\"005000000000201 \",\"rocTransactionDate\":\"2017-12-31\",\"rocTransactionTime\":\"23:59:00\",\"rocAmountUSD\":\"100 \",\n"
          + "\"rocAuthDAC\":\"123456\",\"socSEIndustryCategoryCode\":\"170\",\"socMerchantCategoryCode\":\"1234\",\n"
          + " \n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\n"
          + "\"transactionType\":\"SUBM\"\n"
          + "}";

  public static String matchInput3c_2 =
      "{\"rocSENumber\":\"9097865666 \",\"rocCardNumber\":\"376000000000201 \",\"rocAuthorizationTransactionId\":\"006000000000201 \",\"rocTransactionDate\":\"2017-12-31\",\"rocTransactionTime\":\"23:59:00\",\"rocAmountUSD\":\"1000\",\n"
          + "\"rocAuthDAC\":\"123456\",\"socSEIndustryCategoryCode\":\"170\",\"socMerchantCategoryCode\":\"1234\",\n"
          + " \n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\n"
          + "\"transactionType\":\"SUBM\"\n"
          + "}\n"
          + "";
  public static String matchInput3c_21 =
      "{\"rocSENumber\":\"9097865666 \",\"rocCardNumber\":\"376000000000201 \",\"rocAuthorizationTransactionId\":\"006100000000201 \",\"rocTransactionDate\":\"2017-12-31\",\"rocTransactionTime\":\"23:59:00\",\"rocAmountUSD\":\"750\",\n"
          + "\"rocAuthDAC\":\"123456\",\"socSEIndustryCategoryCode\":\"170\",\"socMerchantCategoryCode\":\"1234\",\n"
          + " \n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\n"
          + "\"transactionType\":\"SUBM\"\n"
          + "}\n"
          + "";

  public static String matchInput3c_localAmount =
      "{\"rocSENumber\":\"9429531213 \",\"rocCardNumber\":\"375700000000201 \",\"rocAuthorizationTransactionId\":\"005000000000201 \",\"rocTransactionDate\":\"2017-12-31\",\"rocTransactionTime\":\"23:59:00\",\"rocLocalAmount\":\"7599\",\r\n"
          + "\"rocAuthDAC\":\"123456\",\"socSEIndustryCategoryCode\":\"170\",\"socMerchantCategoryCode\":\"1234\",\r\n"
          + " \"rocAmountUSD\":\"100 \",\r\n"
          +
          // "\"rocInvoiceReferenceNumber\":\"123456123456123456123456 \",\r\n" +
          "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\r\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\r\n"
          + "\"transactionType\":\"SUBM\",\r\n"
          + "\"rocNetworkGeneratedTID\":\"111111111111116\",\r\n"
          + "\"rocLocalAmountCurrency\":\"USD\",\r\n"
          + "\"rocLocalDecimalPlaces\":\"2\"\r\n"
          + "}";

  public static String matchInput4 =
      "{\"rocSENumber\":\"2201535275 \",\"rocCardNumber\":\"379803969091008 \",\"rocAuthorizationTransactionId\":\"000000000000200 \",\"rocTransactionDate\":\"2018-07-18\",\"rocTransactionTime\":\"23:59:00\",\"rocAmountUSD\":\"100 \",\n"
          + "\"rocAuthDAC\":\"104962\",\"socSEIndustryCategoryCode\":\"170\",\"socMerchantCategoryCode\":\"1234\",\n"
          + " \n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\n"
          + "\"transactionType\":\"SUBM\"\n"
          + "}\n"
          + "\"rocNetworkGeneratedTID\":\"203456782300092\"\n"
          + "\n"
          + "";

  public static String matchInput4_TranIdZeroAndAuthDacNotZero =
      "{\"rocSENumber\":\"2201535275 \",\"rocCardNumber\":\"379803969091008 \",\"rocAuthorizationTransactionId\":\"000000000000000 \",\"rocTransactionDate\":\"2018-07-18\",\"rocTransactionTime\":\"23:59:00\",\"rocAmountUSD\":\"100 \",\n"
          + "\"rocAuthDAC\":\"104962\",\"socSEIndustryCategoryCode\":\"170\",\"socMerchantCategoryCode\":\"1234\",\n"
          + " \n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\n"
          + "\"transactionType\":\"SUBM\"\n"
          + "}\n"
          + "\"rocNetworkGeneratedTID\":\"203456782300092\"\n"
          + "\n"
          + "";

  public static String matchInput4_MultipleROC1 =
      "{\"rocSENumber\":\"2201535278 \",\"rocCardNumber\":\"379803969091008 \",\"rocAuthorizationTransactionId\":\"000000000000200 \",\"rocTransactionDate\":\"2018-07-18\",\"rocTransactionTime\":\"23:59:00\",\"rocAmountUSD\":\"30 \",\n"
          + "\"rocAuthDAC\":\"104962\",\"socSEIndustryCategoryCode\":\"170\",\"socMerchantCategoryCode\":\"1234\",\n"
          + " \n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\n"
          + "\"transactionType\":\"SUBM\"\n"
          + "}\n"
          + "\"rocNetworkGeneratedTID\":\"203456782300092\"\n"
          + "\n"
          + "";

  public static String matchInput4_MultipleROC2 =
      "{\"rocSENumber\":\"2201535278 \",\"rocCardNumber\":\"379803969091008 \",\"rocAuthorizationTransactionId\":\"000000000000200 \",\"rocTransactionDate\":\"2018-07-18\",\"rocTransactionTime\":\"23:59:00\",\"rocAmountUSD\":\"30 \",\n"
          + "\"rocAuthDAC\":\"104962\",\"socSEIndustryCategoryCode\":\"170\",\"socMerchantCategoryCode\":\"1234\",\n"
          + " \n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\n"
          + "\"transactionType\":\"SUBM\"\n"
          + "}\n"
          + "\"rocNetworkGeneratedTID\":\"203456782300092\"\n"
          + "\n"
          + "";

  public static String matchInput4_MultipleROC3 =
      "{\"rocSENumber\":\"2201535278 \",\"rocCardNumber\":\"379803969091008 \",\"rocAuthorizationTransactionId\":\"000000000000200 \",\"rocTransactionDate\":\"2018-07-18\",\"rocTransactionTime\":\"23:59:00\",\"rocAmountUSD\":\"40 \",\n"
          + "\"rocAuthDAC\":\"104962\",\"socSEIndustryCategoryCode\":\"170\",\"socMerchantCategoryCode\":\"1234\",\n"
          + " \n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\n"
          + "\"transactionType\":\"SUBM\"\n"
          + "}\n"
          + "\"rocNetworkGeneratedTID\":\"203456782300092\"\n"
          + "\n"
          + "";

  public static String matchInput4_WithTooc =
      "{\"rocSENumber\":\"2201535278 \",\"rocCardNumber\":\"379803969091008 \",\"rocAuthorizationTransactionId\":\"000000000000200 \",\"rocTransactionDate\":\"2018-07-18\",\"rocTransactionTime\":\"23:59:00\",\"rocAmountUSD\":\"100 \",\n"
          + "\"rocAuthDAC\":\"104962\",\"socSEIndustryCategoryCode\":\"170\",\"socMerchantCategoryCode\":\"1234\",\n"
          + " \n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\n"
          + "\"transactionType\":\"SUBM\"\n"
          + "}\n"
          + "\"rocNetworkGeneratedTID\":\"203456782300092\"\n"
          + "\n"
          + "";

  public static String matchInput4_localAmount =
      "{\"rocSENumber\":\"2201535275\",\"rocCardNumber\":\"377700000000201\",\"rocAuthorizationTransactionId\":\"000000000000200\",\"rocTransactionDate\":\"2018-07-18\",\"rocTransactionTime\":\"23:59:00\",\"rocLocalAmount\":\"10000\",\"rocAmountUSD\":\"70 \",\r\n"
          + "\"rocAuthDAC\":\"104962\",\"socSEIndustryCategoryCode\":\"170\",\"socMerchantCategoryCode\":\"1234\",\r\n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\r\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\r\n"
          + "\"transactionType\":\"SUBM\",\r\n"
          + "\"rocNetworkGeneratedTID\":\"111111111111119\",\r\n"
          + "\"rocLocalAmountCurrency\":\"USD\",\r\n"
          + "\"rocLocalDecimalPlaces\":\"2\"\r\n"
          + "}";

  public static String matchInput5 =
      "{\"rocSENumber\":\"3201535276 \",\"rocCardNumber\":\"379803969091099 \",\"rocAuthorizationTransactionId\":\"000000000000200 \",\"rocTransactionDate\":\"2018-07-18\",\"rocTransactionTime\":\"23:59:00\",\"rocAmountUSD\":\"100 \",\n"
          + "\"rocAuthDAC\":\"104962\",\"socSEIndustryCategoryCode\":\"170\",\"socMerchantCategoryCode\":\"1234\",\n"
          + " \n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\n"
          + "\"transactionType\":\"SUBM\"\n"
          + "}\n"
          + "";

  public static String matchInput5_localAmount =
      "{\"rocSENumber\":\"3201535276\",\"rocCardNumber\":\"379703969091099\",\"rocAuthorizationTransactionId\":\"000000000000200\",\"rocTransactionDate\":\"2018-07-18\",\"rocTransactionTime\":\"23:59:00\",\"rocLocalAmount\":\"10000\",\"rocAmountUSD\":\"130 \",\r\n"
          + "\"rocAuthDAC\":\"104962\",\"socSEIndustryCategoryCode\":\"170\",\"socMerchantCategoryCode\":\"1234\",\r\n"
          + " \r\n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\r\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\r\n"
          + "\"transactionType\":\"SUBM\",\r\n"
          + "\"rocNetworkGeneratedTID\":\"111111111111120\",\r\n"
          + "\"rocLocalAmountCurrency\":\"USD\",\r\n"
          + "\"rocLocalDecimalPlaces\":\"2\"\r\n"
          + "}";

  public static String input6 = "";
  public static String input7 = "";

  public static String matchInput6 =
      "{\"rocSENumber\":\"2201535275\",\"rocCardNumber\":\"377000000000105\",\"rocAuthorizationTransactionId\":\"000000000000200\",\"rocTransactionDate\":\"2018-07-18\",\"rocTransactionTime\":\"23:59:00\",\"rocAmountUSD\":\"100 \",\r\n"
          + "\"rocAuthDAC\":\"32\",\"socSEIndustryCategoryCode\":\"170\",\"socMerchantCategoryCode\":\"1234\",\r\n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\r\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\r\n"
          + "\"transactionType\":\"SUBM\"\r\n"
          + "}\r\n"
          + "";

  public static String matchInput6_MultipleROC1 =
      "{\"rocSENumber\":\"2201535275\",\"rocCardNumber\":\"377000000000105\",\"rocAuthorizationTransactionId\":\"000000000000200\",\"rocTransactionDate\":\"2018-07-18\",\"rocTransactionTime\":\"23:59:00\",\"rocAmountUSD\":\"30 \",\r\n"
          + "\"rocAuthDAC\":\"32\",\"socSEIndustryCategoryCode\":\"170\",\"socMerchantCategoryCode\":\"1234\",\r\n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\r\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\r\n"
          + "\"transactionType\":\"SUBM\"\r\n"
          + "}\r\n"
          + "";

  public static String matchInput6_MultipleROC2 =
      "{\"rocSENumber\":\"2201535275\",\"rocCardNumber\":\"377000000000105\",\"rocAuthorizationTransactionId\":\"000000000000200\",\"rocTransactionDate\":\"2018-07-18\",\"rocTransactionTime\":\"23:59:00\",\"rocAmountUSD\":\"30 \",\r\n"
          + "\"rocAuthDAC\":\"32\",\"socSEIndustryCategoryCode\":\"170\",\"socMerchantCategoryCode\":\"1234\",\r\n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\r\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\r\n"
          + "\"transactionType\":\"SUBM\"\r\n"
          + "}\r\n"
          + "";

  public static String matchInput6_MultipleROC3 =
      "{\"rocSENumber\":\"2201535275\",\"rocCardNumber\":\"377000000000105\",\"rocAuthorizationTransactionId\":\"000000000000200\",\"rocTransactionDate\":\"2018-07-18\",\"rocTransactionTime\":\"23:59:00\",\"rocAmountUSD\":\"40 \",\r\n"
          + "\"rocAuthDAC\":\"32\",\"socSEIndustryCategoryCode\":\"170\",\"socMerchantCategoryCode\":\"1234\",\r\n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\r\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\r\n"
          + "\"transactionType\":\"SUBM\"\r\n"
          + "}\r\n"
          + "";

  public static String matchInput6_localAmount =
      "{\"rocSENumber\":\"2201535275\",\"rocCardNumber\":\"378700000000201\",\"rocAuthorizationTransactionId\":\"000000000000200\",\"rocTransactionDate\":\"2018-07-18\",\"rocTransactionTime\":\"23:59:00\",\"rocLocalAmount\":\"10000\",\"rocAmountUSD\":\"70 \",\r\n"
          + "\"rocAuthDAC\":\"AA\",\"socSEIndustryCategoryCode\":\"170\",\"socMerchantCategoryCode\":\"1234\",\r\n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\r\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\r\n"
          + "\"transactionType\":\"SUBM\",\r\n"
          + "\"rocNetworkGeneratedTID\":\"111111111111119\",\r\n"
          + "\"rocLocalAmountCurrency\":\"USD\",\r\n"
          + "\"rocLocalDecimalPlaces\":\"2\"\r\n"
          + "}";

  public static String matchInput6_WithSubmissionHistory =
      "{\"rocSENumber\":\"2201535278\",\"rocCardNumber\":\"377000000000105\",\"rocAuthorizationTransactionId\":\"000000000000200\",\"rocTransactionDate\":\"2018-07-18\",\"rocTransactionTime\":\"23:59:00\",\"rocAmountUSD\":\"100 \",\r\n"
          + "\"rocAuthDAC\":\"32\",\"socSEIndustryCategoryCode\":\"170\",\"socMerchantCategoryCode\":\"1234\",\r\n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\r\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\r\n"
          + "\"transactionType\":\"SUBM\"\r\n"
          + "}\r\n"
          + "";

  public static String matchInput7 =
      "{\"rocSENumber\":\"3201535276\",\"rocCardNumber\":\"379803969091680\",\"rocAuthorizationTransactionId\":\"000000000000200\",\"rocTransactionDate\":\"2018-07-18\",\"rocTransactionTime\":\"23:59:00\",\"rocAmountUSD\":\"100 \",\r\n"
          + "\"rocAuthDAC\":\"32\",\"socSEIndustryCategoryCode\":\"170\",\"socMerchantCategoryCode\":\"1234\",\r\n"
          + " \r\n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\r\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\r\n"
          + "\"transactionType\":\"SUBM\"\r\n"
          + "}";

  public static String matchInput7_localAmount =
      "{\"rocSENumber\":\"3201535276\",\"rocCardNumber\":\"379803969091099\",\"rocAuthorizationTransactionId\":\"000000000000200\",\"rocTransactionDate\":\"2018-07-18\",\"rocTransactionTime\":\"23:59:00\",\"rocLocalAmount\":\"10000\",\"rocAmountUSD\":\"130 \",\r\n"
          + "\"rocAuthDAC\":\"AA\",\"socSEIndustryCategoryCode\":\"170\",\"socMerchantCategoryCode\":\"1234\",\r\n"
          + " \r\n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR3333 \",\r\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\r\n"
          + "\"transactionType\":\"SUBM\",\r\n"
          + "\"rocNetworkGeneratedTID\":\"111111111111120\",\r\n"
          + "\"rocLocalAmountCurrency\":\"USD\",\r\n"
          + "\"rocLocalDecimalPlaces\":\"2\"\r\n"
          + "}";

  public static String matchInput8 =
      "{\"rocSENumber\":\"9429531213 \",\"rocCardNumber\":\"371100000000722 \",\"rocAuthorizationTransactionId\":\"001100000000201 \",\"rocTransactionDate\":\"2018-07-18\",\"rocTransactionTime\":\"23:59:00\",\"rocAmountUSD\":\"360.00 \",\n"
          + "\"rocAuthDAC\":\"123456\",\"socSEIndustryCategoryCode\":\"4018\",\"socMerchantCategoryCode\":\"1234\",\n"
          + " \n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\n"
          + "\"transactionType\":\"SUBM\"\n"
          + "}\n"
          + "";

  public static String matchInput9 =
      "{\"rocSENumber\":\"9429531213 \",\"rocCardNumber\":\"372200000000516 \",\"rocAuthorizationTransactionId\":\"000000000000000 \",\"rocTransactionDate\":\"2012-10-11\",\"rocTransactionTime\":\"23:59:00\",\"rocAmountUSD\":\"250.44 \",\n"
          + "\"rocAuthDAC\":\"000000\",\"socSEIndustryCategoryCode\":\"4018\",\"socMerchantCategoryCode\":\"1234\",\n"
          + " \n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\n"
          + "\"transactionType\":\"SUBM\"\n"
          + "}\n"
          + "";

  public static String matchInput10 =
      "{\"rocSENumber\":\"9429531721 \",\"rocCardNumber\":\"372200000000554 \",\"rocAuthorizationTransactionId\":\"222400000000201 \",\"rocTransactionDate\":\"2012-10-11\",\"rocTransactionTime\":\"23:59:00\",\"rocAmountUSD\":\"250.44 \",\n"
          + "\"rocAuthDAC\":\"1111\",\"socSEIndustryCategoryCode\":\"4018\",\"socMerchantCategoryCode\":\"1234\",\n"
          + " \n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0721 \",\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\n"
          + "\"transactionType\":\"SUBM\"\n"
          + "}\n"
          + "";

  public static String matchInput11 =
      "{\"rocSENumber\":\"9429531213 \",\"rocCardNumber\":\"372200000000221 \",\"rocAuthorizationTransactionId\":\"000000000000000 \","
          + "\"rocTransactionDate\":\"2018-11-10\",\"rocTransactionTime\":\"18:00:00\",\"rocAmountUSD\":\"1200 \",\n"
          + "\"rocAuthDAC\":\"000000\",\"socSEIndustryCategoryCode\":\"4018\",\"socMerchantCategoryCode\":\"1234\",\n"
          + " \n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\n"
          + "\"transactionType\":\"SUBM\"\n"
          + "}\n"
          + "";

  public static String matchInput11_WithZeros_And_Spaces =
      "{\"rocSENumber\":\"9429531213 \",\"rocCardNumber\":\"372200000000221 \",\"rocAuthorizationTransactionId\":\"   000000000000 \","
          + "\"rocTransactionDate\":\"2018-11-10\",\"rocTransactionTime\":\"18:00:00\",\"rocAmountUSD\":\"1200 \",\n"
          + "\"rocAuthDAC\":\"    00\",\"socSEIndustryCategoryCode\":\"4018\",\"socMerchantCategoryCode\":\"1234\",\n"
          + " \n"
          + "\"rocAcquirerReferenceNumber\":\"A855283220SUBR0006 \",\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR0008 \",\n"
          + "\"transactionType\":\"SUBM\"\n"
          + "}\n"
          + "";

  public static String loadInput2WithRTFData_1 =
      "{\"rocSENumber\":\"1010346435 \",\"rocCardNumber\":\"376661014351230 \",\"rocAuthorizationTransactionId\":\"   005608580204571 \","
          + "\"rocTransactionDate\":\"2020-01-02\",\"rocTransactionTime\":\"09:48:34\",\"rocAmountUSD\":\"363.21 \",\n"
          + "\"rocAuthDAC\":\"DAC98\",\"socSEIndustryCategoryCode\":\"170\",\"socMerchantCategoryCode\":\"1234\",\n"
          + " \n"
          + "\"rocAcquirerReferenceNumber\":\"A297189131SUBR1016 \",\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR1018 \",\n"
          + "\"transactionType\":\"SUBM\",\n"
          + "\"rocISOProcessingCode\":\"000000\"\n"
          + "}\n"
          + "";

  public static String loadInput2WithRTFData_2 =
      "{\"rocSENumber\":\"1010346435 \",\"rocCardNumber\":\"376661014351230 \",\"rocAuthorizationTransactionId\":\"   005608580204571 \","
          + "\"rocTransactionDate\":\"2020-01-02\",\"rocTransactionTime\":\"09:48:34\",\"rocAmountUSD\":\"363.21 \",\n"
          + "\"rocAuthDAC\":\"DAC98\",\"socSEIndustryCategoryCode\":\"170\",\"socMerchantCategoryCode\":\"1234\",\n"
          + " \n"
          + "\"rocAcquirerReferenceNumber\":\"A297189131SUBR1016 \",\n"
          + "\"socAcquirerReferenceNumber\":\"A855283220SUBR1018 \",\n"
          + "\"transactionType\":\"SUBM\",\n"
          + "\"rocISOProcessingCode\":\"020000\"\n"
          + "}\n"
          + "";

  public void setDataForCache(String ramTier) {
    HashMap<String, String> dataMap = null;

    if (ramTier.equals("1")) {
      dataMap = new HashMap(TestData.loadInput1Map);

    } else if (ramTier.equals("2a")) {
      dataMap = new HashMap(TestData.loadInput2aMap);
    } else if (ramTier.equals("2")) {
      dataMap = new HashMap(TestData.loadInput2Map);
    } else if (ramTier.equals("3a")) {
      dataMap = new HashMap(TestData.loadInput3aMap);
    } else if (ramTier.equals("3b1")) {
      dataMap = new HashMap(TestData.loadInput3b1Map);
    } else if (ramTier.equals("3b2")) {
      dataMap = new HashMap(TestData.loadInput3b2Map);
    } else if (ramTier.equals("3c1")) {
      dataMap = new HashMap(TestData.loadInput3c1Map);
    } else if (ramTier.equals("3c2")) {
      dataMap = new HashMap(TestData.loadInput3c2Map);
    } else if (ramTier.equals("3c21")) {
      dataMap = new HashMap(TestData.loadInput3c21Map);
    } else if (ramTier.equals("4")) {
      dataMap = new HashMap(TestData.loadInput4Map);
    } else if (ramTier.equals("4a")) {
      dataMap = new HashMap(TestData.loadInput4aMap);
    } else if (ramTier.equals("5")) {
      dataMap = new HashMap(TestData.loadInput5Map);
    } else if (ramTier.equals("6")) {
      dataMap = new HashMap(TestData.loadInput6Map);
    } else if (ramTier.equals("6a")) {
      dataMap = new HashMap(TestData.loadInput6aMap);
    } else if (ramTier.equals("7")) {
      dataMap = new HashMap(TestData.loadInput7Map);
    } else if (ramTier.equals("81")) {
      dataMap = new HashMap(TestData.loadInput81Map);
    } else if (ramTier.equals("82")) {
      dataMap = new HashMap(TestData.loadInput82Map);
    } else if (ramTier.equals("83")) {
      dataMap = new HashMap(TestData.loadInput83Map);
    } else if (ramTier.equals("84")) {
      dataMap = new HashMap(TestData.loadInput84Map);
    } else if (ramTier.equals("9")) {
      dataMap = new HashMap(TestData.loadInput9Map);
    } else if (ramTier.equals("11")) {
      dataMap = new HashMap(TestData.loadInput11Map);
    }

    try {
      transCardBean = getTidBean(dataMap);
      cardDac6Bean = getCardDac6Bean(dataMap);
      cardDac2Bean = getCardDac2Bean(dataMap);

      transCardBean.setCardDac2PrimaryKey(
          cardDac2Bean.getCardNumber() + "|" + cardDac2Bean.getAuth2Dac() + "|A");
      transCardBean.setCardDac6PrimaryKey(
          cardDac6Bean.getCardNumber() + "|" + cardDac6Bean.getAuth6Dac() + "|A");

      cardDac6Bean.setTidCMPrimaryKey(
          transCardBean.getTransactionId() + "|" + transCardBean.getCardNumber() + "|A");
      cardDac6Bean.setCardDac2PrimaryKey(
          cardDac2Bean.getCardNumber() + "|" + cardDac2Bean.getAuth2Dac() + "|A");

      cardDac2Bean.setCardDac6PrimaryKey(
          cardDac6Bean.getCardNumber() + "|" + cardDac6Bean.getAuth6Dac() + "|A");
      cardDac2Bean.setTidCMPrimaryKey(
          transCardBean.getTransactionId() + "|" + transCardBean.getCardNumber() + "|A");
    } catch (Exception ex) {
      System.out.println("Exception occurred " + ex.getMessage());
    }
  }

  public CasAuthTransIdCardCacheBean2 getTransCardBeanInstance() {
    return transCardBean;
  }

  public CasAuthCardAccessCode2CacheBean getCardDac2BeanInstance() {
    return cardDac2Bean;
  }

  public CasAuthCardAccessCode6CacheBean getCardDac6BeanInstance() {
    return cardDac6Bean;
  }

  private CasAuthCardAccessCode2CacheBean getCardDac2Bean(HashMap<String, String> dataMap) {
    Date date = null;
    StringBuffer authorizationDate = new StringBuffer(15);

    CasAuthCardAccessCode2CacheBean cacheBean = new CasAuthCardAccessCode2CacheBean();
    cacheBean.setCardNumber(dataMap.get("lwrisoact").trim());
    cacheBean.setAuth2Dac(dataMap.get("lwrrr_kapc"));
    String approveDenyCode = "D";
    String dadc = dataMap.get("lwrcw_dadc").trim();
    if (dadc.equals("0") || dadc.equals("1") || dadc.equals("6")) approveDenyCode = "A";
    cacheBean.setApproveDenyCode(approveDenyCode);

    cacheBean.setAuthAmountUSD(
        new BigDecimal(
                StringUtils.isEmpty(dataMap.get("lwrisoamt").trim())
                    ? "0.0"
                    : dataMap.get("lwrisoamt"))
            .setScale(2, RoundingMode.CEILING));
    authorizationDate.append(
        StringUtils.isEmpty(dataMap.get("lwrdgod").trim()) ? "123199" : dataMap.get("lwrdgod"));
    authorizationDate.append(" ");
    authorizationDate.append(
        StringUtils.isEmpty(dataMap.get("lwrdtim").trim()) ? "000000" : dataMap.get("lwrdtim"));

    try {
      CAS_AUTHORIZATION_DATE_FORMAT.setLenient(false);
      date = CAS_AUTHORIZATION_DATE_FORMAT.parse(authorizationDate.toString());
    } catch (Exception e) {
      LOGGER.info(
          "{}\"Message\":\"Invalid date\",\\\"TID\" :\"{}\"}",
          authMatchLog.getCommonLogAttributes("S", "GR5019"),
          dataMap.get("lwrcw_7etrid"),
          ITier.REQUESTHANDLER,
          CLASS_NAME,
          "AuthLoadServiceImpl");
      try {
        date = defaultDateFormat.parse("1900-01-01 00:00:00");
      } catch (ParseException e1) {
      }
    }
    cacheBean.setAuthTransactionDateTime(date);
    cacheBean.setSeNumber(dataMap.get("lwrisoaid").trim());
    cacheBean.setAuthUniqueIdentifier(AuthMatchUtil.getCASPKey(date, dataMap.get("lwrcw_7dlog")));
    return cacheBean;
  }

  private CasAuthTransIdCardCacheBean2 getTidBean(HashMap<String, String> dataMap) {
    Date date = null;
    StringBuffer authorizationDate = new StringBuffer(15);
    CasAuthTransIdCardCacheBean2 cacheBean = new CasAuthTransIdCardCacheBean2();

    cacheBean.setCardNumber(dataMap.get("lwrisoact").trim());
    cacheBean.setTransactionId(dataMap.get("lwrcw_7etrid").trim());
    cacheBean.setAuthAmountUSD(
        new BigDecimal(
                StringUtils.isEmpty(dataMap.get("lwrisoamt").trim())
                    ? "0.0"
                    : dataMap.get("lwrisoamt"))
            .setScale(2, RoundingMode.CEILING));
    cacheBean.setRocAuthMatchedFlag("N");
    String approveDenyCode = "D";
    String dadc = dataMap.get("lwrcw_dadc").trim();
    if (dadc.equals("0") || dadc.equals("1") || dadc.equals("6")) approveDenyCode = "A";
    cacheBean.setApproveDenyCode(approveDenyCode);
    authorizationDate.append(
        StringUtils.isEmpty(dataMap.get("lwrdgod").trim()) ? "123199" : dataMap.get("lwrdgod"));
    authorizationDate.append(" ");
    authorizationDate.append(
        StringUtils.isEmpty(dataMap.get("lwrdtim").trim()) ? "000000" : dataMap.get("lwrdtim"));

    try {
      CAS_AUTHORIZATION_DATE_FORMAT.setLenient(false);
      date = CAS_AUTHORIZATION_DATE_FORMAT.parse(authorizationDate.toString());
    } catch (Exception e) {
      LOGGER.info(
          "{}\"Message\":\"Invalid date\",\"TID\" :\"{}\"}",
          authMatchLog.getCommonLogAttributes("S", "GR5017"),
          dataMap.get("lwrcw_7etrid"),
          ITier.REQUESTHANDLER,
          CLASS_NAME,
          "AuthMatchServiceImpl");
      try {
        date = defaultDateFormat.parse("1900-01-01 00:00:00");
      } catch (ParseException e1) {
      }
    }
    cacheBean.setAuthTransactionDateTime(date);
    cacheBean.setSeNumber(dataMap.get("lwrisoaid").trim());
    cacheBean.setAuthUniqueIdentifier(AuthMatchUtil.getCASPKey(date, dataMap.get("lwrcw_7dlog")));
    return cacheBean;
  }

  private CasAuthCardAccessCode6CacheBean getCardDac6Bean(HashMap<String, String> dataMap) {
    Date date = null;

    StringBuffer authorizationDate = new StringBuffer(15);
    CasAuthCardAccessCode6CacheBean cacheBean = new CasAuthCardAccessCode6CacheBean();
    cacheBean.setCardNumber(dataMap.get("lwrisoact").trim());
    cacheBean.setAuth6Dac(dataMap.get("lwrrr_7dap6").trim());
    String approveDenyCode = "D";
    String dadc = dataMap.get("lwrcw_dadc").trim();
    if (dadc.equals("0") || dadc.equals("1") || dadc.equals("6")) approveDenyCode = "A";
    cacheBean.setApproveDenyCode(approveDenyCode);
    cacheBean.setAuthAmountUSD(
        new BigDecimal(
                StringUtils.isEmpty(dataMap.get("lwrisoamt").trim())
                    ? "0.0"
                    : dataMap.get("lwrisoamt"))
            .setScale(2, RoundingMode.CEILING));
    authorizationDate.append(
        StringUtils.isEmpty(dataMap.get("lwrdgod").trim()) ? "123199" : dataMap.get("lwrdgod"));
    authorizationDate.append(" ");
    authorizationDate.append(
        StringUtils.isEmpty(dataMap.get("lwrdtim").trim()) ? "000000" : dataMap.get("lwrdtim"));

    try {
      CAS_AUTHORIZATION_DATE_FORMAT.setLenient(false);
      date = CAS_AUTHORIZATION_DATE_FORMAT.parse(authorizationDate.toString());
    } catch (Exception e) {
      LOGGER.info(
          "{}\"Message\":\"Invalid date\",\"TID\" :\"{}\"} ",
          authMatchLog.getCommonLogAttributes("S", "GR5018"),
          dataMap.get("lwrcw_7etrid"),
          ITier.REQUESTHANDLER,
          CLASS_NAME,
          "AuthLoadServiceImpl");
      try {
        date = defaultDateFormat.parse("1900-01-01 00:00:00");
      } catch (ParseException e1) {
      }
    }
    cacheBean.setAuthTransactionDateTime(date);
    cacheBean.setSeNumber(dataMap.get("lwrisoaid").trim());
    cacheBean.setAuthUniqueIdentifier(AuthMatchUtil.getCASPKey(date, dataMap.get("lwrcw_7dlog")));
    return cacheBean;
  }
}
