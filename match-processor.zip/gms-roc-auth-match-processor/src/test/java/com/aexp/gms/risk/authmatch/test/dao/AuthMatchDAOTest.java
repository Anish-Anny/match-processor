package com.aexp.gms.risk.authmatch.test.dao;

import com.aexp.gmnt.imc.vo.SECharacteristics501Data;
import com.aexp.gms.imc.metadata.vo.RiskThresholdKey;
import com.aexp.gms.imc.metadata.vo.RiskThresholdValue;
import com.aexp.gms.imc.risk.rules.vo.keys.CasAuthCardAccessCode2CacheKey;
import com.aexp.gms.imc.risk.rules.vo.keys.CasAuthCardAccessCode6CacheKey;
import com.aexp.gms.imc.risk.rules.vo.keys.CasAuthTransIdCardCacheKey;
import com.aexp.gms.imc.risk.rules.vo.values.CasAuthCardAccessCode2CacheBean;
import com.aexp.gms.imc.risk.rules.vo.values.CasAuthCardAccessCode6CacheBean;
import com.aexp.gms.imc.risk.rules.vo.values.CasAuthTransIdCardCacheBean2;
import com.aexp.gms.imc.risk.rules.vo.values.ICacheBean;
import com.aexp.gms.imc.risk.rules.vo.values.IndustryLeverageBean;
import com.aexp.gms.risk.authmatch.controller.AuthMatchController;
import com.aexp.gms.risk.authmatch.dao.AuthMatchDAOImpl;
import com.aexp.gms.risk.authmatch.dao.IgniteProvider;
import com.aexp.gms.risk.authmatch.dao.RocAuthSEHistoryDao;
import com.aexp.gms.risk.authmatch.dao.RocAuthSeHistoryIgniteImpl;
import com.aexp.gms.risk.authmatch.dao.SeChar501Dao;
import com.aexp.gms.risk.authmatch.dao.SeChar501IgniteImpl;
import com.aexp.gms.risk.authmatch.exception.AuthMatchSystemException;
import com.aexp.gms.risk.authmatch.model.ResponseMetaData;
import com.aexp.gms.risk.authmatch.model.RocMatchRequest;
import com.aexp.gms.risk.authmatch.model.SubmissionMatchResponse;
import com.aexp.gms.risk.authmatch.model.ignite.key.RocAuthSEHistoryKey;
import com.aexp.gms.risk.authmatch.model.ignite.value.RocAuthSEHistoryValue;
import com.aexp.gms.risk.authmatch.rest.client.AuthMatchClusterUpdateAPI;
import com.aexp.gms.risk.authmatch.rtf.RtfConfiguration;
import com.aexp.gms.risk.authmatch.services.AuthMatchServiceImpl;
import com.aexp.gms.risk.authmatch.services.ComputeJobProcess;
import com.aexp.gms.risk.authmatch.test.services.TestData;
import com.aexp.gms.risk.authmatch.util.AuthMatchConstants;
import com.aexp.gms.risk.authmatch.util.AuthMatchUtil;
import com.aexp.gms.risk.authmatch.util.PropertyLoaderUtils;
import com.aexp.gms.risk.data.CassandraMatchResultDAOImpl;
import com.aexp.rtf.client.RtfClient;
import com.aexp.subscriptions.dto.Resource;
import com.aexp.subscriptions.dto.Subscription;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import javax.cache.expiry.CreatedExpiryPolicy;
import javax.cache.expiry.Duration;
import javax.cache.expiry.ExpiryPolicy;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.Ignition;
import org.apache.ignite.cache.CacheAtomicityMode;
import org.apache.ignite.cache.CacheMode;
import org.apache.ignite.configuration.CacheConfiguration;
import org.junit.*;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.ResponseEntity;

public class AuthMatchDAOTest {

  private static IgniteProvider authMatchIgniteProvider;
  static ComputeJobProcess job = new ComputeJobProcess();

  private static AuthMatchDAOImpl authMatchDAO;

  @Mock
  private static CassandraMatchResultDAOImpl cassandraMatchResultDAO =
      Mockito.mock(CassandraMatchResultDAOImpl.class);

  private static AuthMatchServiceImpl authMatchServiceImpl;
  private static Ignite clientIgnite = null;
  private static Ignite serverIgnite = null;

  private static TestData testData;
  private static final String LOCATION_FOR_CAS_POST = "/location/for/cas/post";

  @SuppressWarnings("restriction")
  private static com.sun.net.httpserver.HttpServer server;

  private static RtfClient rtfClientBean;
  private static String[] eventTypes = {"/gmsrisk/submissions/ipc1"};
  private AuthMatchClusterUpdateAPI clusterUpdate;

  @After
  public void clearCache() {
    authMatchIgniteProvider.getIgnite().cache(AuthMatchConstants.CAS_AUTH_TID_CM_CACHE).clear();
    authMatchIgniteProvider.getIgnite().cache(AuthMatchConstants.CAS_AUTH_CM_DAC2_CACHE).clear();
    authMatchIgniteProvider.getIgnite().cache(AuthMatchConstants.CAS_AUTH_CM_DAC6_CACHE).clear();
  }

  @BeforeClass
  public static void testSetupMock() throws AuthMatchSystemException {
    System.setProperty("env", "test");
    System.setProperty("spring.profiles.active", "e0");
    System.setProperty("data-center", "test");
    System.setProperty("AIM_ID", "41140955");
    System.out.println("Starting Ignite server");
    serverIgnite = new IgniteServerNode("ignite-config-server.xml").getIgnite();
    String igniteConfigFile =
        PropertyLoaderUtils.resolveFileName("imc-ignite-client-config-${env}.xml");
    clientIgnite =
        Ignition.getOrStart(
            Ignition.loadSpringBean(
                AuthMatchDAOTest.class.getClassLoader().getResourceAsStream(igniteConfigFile),
                "ignite.cfg"));

    authMatchIgniteProvider = new IgniteProvider(false);
    authMatchIgniteProvider.setIgnite(clientIgnite);
    authMatchDAO = new AuthMatchDAOImpl();
    authMatchDAO.setCacheProvider(authMatchIgniteProvider);
    authMatchServiceImpl =
        new AuthMatchServiceImpl(
            authMatchDAO, null, cassandraMatchResultDAO, null, null, null, null, null, null, null);
    testData = new TestData();
    createIndustryLeverageCache("SE_INDUSTRY_LEVERAGE_CACHE_V2");
    createThresholdCache();
    createSe501Cache("SeChar501Data");
    createRocAuthSeHistoryCache();
    createRiskAssesmentThreshold();
  }

  @AfterClass
  public static void testTeardown() {
    try {
      Ignition.stopAll(false);
    } catch (Exception e) {
    }
    System.out.println("Stopped Ignite");
  }

  private static void createSe501Cache(String cacheName) {
    CacheConfiguration<Long, SECharacteristics501Data> seChar501CacheCfg =
        new CacheConfiguration<>(cacheName);
    seChar501CacheCfg.setIndexedTypes(Long.class, SECharacteristics501Data.class);
    seChar501CacheCfg
        .setAtomicityMode(CacheAtomicityMode.ATOMIC)
        .setBackups(1)
        .setCacheMode(CacheMode.PARTITIONED);
    clientIgnite.getOrCreateCache(seChar501CacheCfg);
  }

  private static void createThresholdCache() {
    CacheConfiguration<RiskThresholdKey, RiskThresholdValue>
        riskThresholdKeyRiskThresholdValueCacheConfiguration =
            new CacheConfiguration<>("RAM_RISK_ASSESSMENT_THRESHOLD_CACHE_V1");
    riskThresholdKeyRiskThresholdValueCacheConfiguration
        .setAtomicityMode(CacheAtomicityMode.ATOMIC)
        .setBackups(1)
        .setCacheMode(CacheMode.PARTITIONED);
    clientIgnite.getOrCreateCache(riskThresholdKeyRiskThresholdValueCacheConfiguration);
  }

  private static void createRocAuthSeHistoryCache() {
    CacheConfiguration<RocAuthSEHistoryKey, RocAuthSEHistoryValue>
        rocAuthSEHistoryValueCacheConfiguration =
            new CacheConfiguration<>(RocAuthSeHistoryIgniteImpl.CACHE_ROC_AUTH_HISTORY);
    rocAuthSEHistoryValueCacheConfiguration.setIndexedTypes(
        RocAuthSEHistoryKey.class, RocAuthSEHistoryValue.class);
    rocAuthSEHistoryValueCacheConfiguration
        .setAtomicityMode(CacheAtomicityMode.ATOMIC)
        .setBackups(1)
        .setCacheMode(CacheMode.PARTITIONED);
    clientIgnite.getOrCreateCache(rocAuthSEHistoryValueCacheConfiguration);
  }

  private static void createRiskAssesmentThreshold() {
    CacheConfiguration riskAssesmentThresholdConfig =
        new CacheConfiguration<>("RAM_RISK_ASSESSMENT_THRESHOLD_CACHE_V1");
    riskAssesmentThresholdConfig
        .setAtomicityMode(CacheAtomicityMode.ATOMIC)
        .setBackups(1)
        .setCacheMode(CacheMode.PARTITIONED);
    clientIgnite.getOrCreateCache(riskAssesmentThresholdConfig);
  }

  private static void loadTestData() {
    String[] matchTiers = {
      "2", "3a", "3b1", "3b2", "3c1", "3c2", "3c21", "4", "4a", "5", "6", "6a", "7", "81", "82",
      "83", "84", "9", "11"
    };
    for (String matchTier : matchTiers) {
      setTestData(matchTier);
    }
  }

  public static void setTestData(String matchTier) {
    ObjectMapper mapper = new ObjectMapper();
    mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
    try {
      testData.setDataForCache(matchTier);
      CasAuthTransIdCardCacheBean2 casAuthTransIdCardCacheBean =
          testData.getTransCardBeanInstance();
      CasAuthCardAccessCode6CacheBean casAuthCardAccessCode6CacheBean =
          testData.getCardDac6BeanInstance();
      CasAuthCardAccessCode2CacheBean casAuthCardAccessCode2CacheBean =
          testData.getCardDac2BeanInstance();
      String approveDevyCode = matchTier.equals("1") ? "D" : "A";
      authMatchDAO.putCache(
          AuthMatchConstants.CAS_AUTH_TID_CM_CACHE,
          new CasAuthTransIdCardCacheKey(
              casAuthTransIdCardCacheBean.getTransactionId()
                  + "|"
                  + casAuthTransIdCardCacheBean.getCardNumber()
                  + "|"
                  + approveDevyCode),
          casAuthTransIdCardCacheBean);
      authMatchDAO.loadCache(
          new CasAuthCardAccessCode6CacheKey(
              casAuthCardAccessCode6CacheBean.getCardNumber()
                  + "|"
                  + casAuthCardAccessCode6CacheBean.getAuth6Dac()
                  + "|"
                  + approveDevyCode),
          casAuthCardAccessCode6CacheBean);
      authMatchDAO.loadCache(
          new CasAuthCardAccessCode2CacheKey(
              casAuthCardAccessCode2CacheBean.getCardNumber()
                  + "|"
                  + casAuthCardAccessCode2CacheBean.getAuth2Dac()
                  + "|"
                  + approveDevyCode),
          casAuthCardAccessCode2CacheBean);
      System.out.println("Loaded test data for tier " + matchTier);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @Test
  public void testMatchLogic_tier_2() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      setTestData("2");
      rocMatchRequest =
          (RocMatchRequest) mapper.readValue(TestData.matchInput2, RocMatchRequest.class);
      authMatchServiceImpl.populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = job.process(rocMatchRequest);
      System.out.println("Match tier 2 : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T02"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));
    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_1() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      try {
        setTestData("1");

        rocMatchRequest =
            (RocMatchRequest) mapper.readValue(TestData.matchInput1, RocMatchRequest.class);
        authMatchServiceImpl.populateEligibleMatchTiersList(rocMatchRequest);
        System.out.println(
            "RocMatch Request, Trans id : " + rocMatchRequest.getRocAuthorizationTransactionId());

      } catch (IOException e) {
        e.printStackTrace();
      }
      SubmissionMatchResponse submissionMatchResponse = job.process(rocMatchRequest);
      System.out.println("Match tier 1 : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T01"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("2"));

    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void test_swapMatchLevels_1_And_2() {
    try {
      int cacheCountBeforeInsert =
          authMatchDAO.getCacheCount(AuthMatchConstants.CAS_AUTH_TID_CM_CACHE);
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      try {
        setTestData("1");
        setTestData("2a");

        int cacheCountAfterInsert =
            authMatchDAO.getCacheCount(AuthMatchConstants.CAS_AUTH_TID_CM_CACHE);

        Assert.assertTrue(cacheCountAfterInsert == 2);

        rocMatchRequest =
            (RocMatchRequest) mapper.readValue(TestData.matchInput1, RocMatchRequest.class);
        System.out.println(
            "RocMatch Request, Trans id : " + rocMatchRequest.getRocAuthorizationTransactionId());
        authMatchServiceImpl.populateEligibleMatchTiersList(rocMatchRequest);

      } catch (IOException e) {
        e.printStackTrace();
      }
      SubmissionMatchResponse submissionMatchResponse = job.process(rocMatchRequest);
      int cacheCountAfterMatch =
          authMatchDAO.getCacheCount(AuthMatchConstants.CAS_AUTH_TID_CM_CACHE);
      Assert.assertTrue(cacheCountAfterMatch == 2);
      System.out.println("Match tier 2 : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T02"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));

    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_3a() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      setTestData("3a");
      rocMatchRequest =
          (RocMatchRequest) mapper.readValue(TestData.matchInput3a, RocMatchRequest.class);
      authMatchServiceImpl.populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = job.process(rocMatchRequest);
      System.out.println("Match tier 3a : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T03"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));
    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_3a_multipleRocs() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest1 = null;
      RocMatchRequest rocMatchRequest2 = null;
      setTestData("3a");
      rocMatchRequest1 =
          (RocMatchRequest)
              mapper.readValue(TestData.matchInput3a_multipleRoc1, RocMatchRequest.class);
      authMatchServiceImpl.populateEligibleMatchTiersList(rocMatchRequest1);
      SubmissionMatchResponse submissionMatchResponse = job.process(rocMatchRequest1);
      rocMatchRequest2 =
          (RocMatchRequest)
              mapper.readValue(TestData.matchInput3a_multipleRoc2, RocMatchRequest.class);
      authMatchServiceImpl.populateEligibleMatchTiersList(rocMatchRequest2);
      SubmissionMatchResponse submissionMatchResponse2 = job.process(rocMatchRequest2);

      System.out.println("Match tier 3a : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T03"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));
    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_3a_multipleRocs_WithLocalAmount() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest1 = null;
      RocMatchRequest rocMatchRequest2 = null;
      setTestData("3a");
      rocMatchRequest1 =
          (RocMatchRequest)
              mapper.readValue(TestData.matchInput3a_multipleRoc1_WithLocal, RocMatchRequest.class);
      authMatchServiceImpl.populateEligibleMatchTiersList(rocMatchRequest1);
      SubmissionMatchResponse submissionMatchResponse = job.process(rocMatchRequest1);
      rocMatchRequest2 =
          (RocMatchRequest)
              mapper.readValue(TestData.matchInput3a_multipleRoc2_WithLocal, RocMatchRequest.class);
      authMatchServiceImpl.populateEligibleMatchTiersList(rocMatchRequest2);
      SubmissionMatchResponse submissionMatchResponse2 = job.process(rocMatchRequest2);

      System.out.println("Match tier 3a : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T03"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));
    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_3b() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      setTestData("3b1");
      setTestData("3b2");
      rocMatchRequest =
          (RocMatchRequest) mapper.readValue(TestData.matchInput3b, RocMatchRequest.class);
      authMatchServiceImpl.populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = job.process(rocMatchRequest);
      System.out.println("Match tier 3b : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T03"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));
    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_3c_1() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      setTestData("3c1");
      rocMatchRequest =
          (RocMatchRequest) mapper.readValue(TestData.matchInput3c_1, RocMatchRequest.class);
      authMatchServiceImpl.populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = job.process(rocMatchRequest);
      System.out.println("Match tier 3c.1 : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T03"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));
    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_3c_2() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      setTestData("3c2");
      rocMatchRequest =
          (RocMatchRequest) mapper.readValue(TestData.matchInput3c_2, RocMatchRequest.class);
      authMatchServiceImpl.populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = job.process(rocMatchRequest);
      System.out.println("Match tier 3c.2 : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T03"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));
    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_3c_2_ExactAmount100() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      setTestData("3c21");
      rocMatchRequest =
          (RocMatchRequest) mapper.readValue(TestData.matchInput3c_21, RocMatchRequest.class);
      authMatchServiceImpl.populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = job.process(rocMatchRequest);
      System.out.println(
          "Match tier 3c.2 Exact 100 Amount : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T03"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));
    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_4() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      setTestData("4");
      rocMatchRequest =
          (RocMatchRequest) mapper.readValue(TestData.matchInput4, RocMatchRequest.class);
      authMatchServiceImpl.populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = job.process(rocMatchRequest);
      System.out.println("Match tier 4 : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T04"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));
    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_4_TranIdAllZerosAndAuthDacNotZero() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      setTestData("4");
      rocMatchRequest =
          (RocMatchRequest)
              mapper.readValue(
                  TestData.matchInput4_TranIdZeroAndAuthDacNotZero, RocMatchRequest.class);
      authMatchServiceImpl.populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = job.process(rocMatchRequest);
      System.out.println(
          "Match tier 4 with TranIdAllZerosAndAuthDacNotZero : "
              + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T04"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));
    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_4_WithTooc() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      setTestData("4");
      SeChar501Dao seChar501Ignite = new SeChar501IgniteImpl(authMatchIgniteProvider);
      SECharacteristics501Data SECharacteristics501DataRocRequest = new SECharacteristics501Data();
      SECharacteristics501Data SECharacteristics501DataCache = new SECharacteristics501Data();

      rocMatchRequest =
          (RocMatchRequest) mapper.readValue(TestData.matchInput4_WithTooc, RocMatchRequest.class);

      SECharacteristics501DataCache.setTopOfChain("986082");
      seChar501Ignite.put("2201535275", SECharacteristics501DataCache);

      SECharacteristics501DataRocRequest.setTopOfChain("986082");
      seChar501Ignite.put(rocMatchRequest.getRocSENumber(), SECharacteristics501DataRocRequest);
      authMatchServiceImpl.populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = job.process(rocMatchRequest);
      System.out.println("Match tier 4 with Tooc : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T04"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));
    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_4_MultipleRoc() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest, rocMatchRequest1, rocMatchRequest2 = null;

      setTestData("4");
      SeChar501Dao seChar501Ignite = new SeChar501IgniteImpl(authMatchIgniteProvider);
      SECharacteristics501Data SECharacteristics501DataRocRequest = new SECharacteristics501Data();
      SECharacteristics501Data SECharacteristics501DataCache = new SECharacteristics501Data();

      rocMatchRequest =
          (RocMatchRequest)
              mapper.readValue(TestData.matchInput4_MultipleROC1, RocMatchRequest.class);
      rocMatchRequest1 =
          (RocMatchRequest)
              mapper.readValue(TestData.matchInput4_MultipleROC2, RocMatchRequest.class);

      rocMatchRequest2 =
          (RocMatchRequest)
              mapper.readValue(TestData.matchInput4_MultipleROC3, RocMatchRequest.class);

      SECharacteristics501DataCache.setTopOfChain("986082");
      seChar501Ignite.put("2201535275", SECharacteristics501DataCache);

      SECharacteristics501DataRocRequest.setTopOfChain("986082");
      seChar501Ignite.put(rocMatchRequest.getRocSENumber(), SECharacteristics501DataRocRequest);

      setTestData("4");
      authMatchServiceImpl.populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = job.process(rocMatchRequest);
      System.out.println(
          "Match tier 4 with Multiple ROC : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T04"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));
      authMatchServiceImpl.populateEligibleMatchTiersList(rocMatchRequest1);
      submissionMatchResponse = job.process(rocMatchRequest1);
      System.out.println(
          "Match tier 4 with Multiple ROC : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T04"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));
      authMatchServiceImpl.populateEligibleMatchTiersList(rocMatchRequest2);
      submissionMatchResponse = job.process(rocMatchRequest2);
      System.out.println(
          "Match tier 4 with Multiple ROC : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T04"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));

    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_4_With_Tid() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      setTestData("4");

      rocMatchRequest =
          (RocMatchRequest) mapper.readValue(TestData.matchInput4, RocMatchRequest.class);
      rocMatchRequest.setAmexConsumerAppName("Nemo");
      authMatchServiceImpl.populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = job.process(rocMatchRequest);
      System.out.println("Match tier 4 with Tid:" + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T04"));
      Assert.assertEquals("006145570697679", submissionMatchResponse.getTransactionId());
    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_5() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      setTestData("5");

      rocMatchRequest =
          (RocMatchRequest) mapper.readValue(TestData.matchInput5, RocMatchRequest.class);
      authMatchServiceImpl.populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = job.process(rocMatchRequest);
      System.out.println("Match tier 5 : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T05"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));
    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_6() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      setTestData("6");

      rocMatchRequest =
          (RocMatchRequest) mapper.readValue(TestData.matchInput6, RocMatchRequest.class);
      authMatchServiceImpl.populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = job.process(rocMatchRequest);
      System.out.println("Match tier 6 : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T06"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));
    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_6_MultipleROC() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest, rocMatchRequest1, rocMatchRequest2 = null;
      setTestData("6");

      rocMatchRequest =
          (RocMatchRequest)
              mapper.readValue(TestData.matchInput6_MultipleROC1, RocMatchRequest.class);
      rocMatchRequest1 =
          (RocMatchRequest)
              mapper.readValue(TestData.matchInput6_MultipleROC2, RocMatchRequest.class);

      rocMatchRequest2 =
          (RocMatchRequest)
              mapper.readValue(TestData.matchInput6_MultipleROC3, RocMatchRequest.class);

      // setTestData("06");
      authMatchServiceImpl.populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = job.process(rocMatchRequest);
      System.out.println(
          "Match tier 6 with Multiple ROC : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T06"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));
      authMatchServiceImpl.populateEligibleMatchTiersList(rocMatchRequest1);
      submissionMatchResponse = job.process(rocMatchRequest1);
      System.out.println(
          "Match tier 6 with Multiple ROC : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T06"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));
      authMatchServiceImpl.populateEligibleMatchTiersList(rocMatchRequest2);
      submissionMatchResponse = job.process(rocMatchRequest2);
      System.out.println(
          "Match tier 6 with Multiple ROC : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T06"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));

    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_6_WithSeSubmissionHistory() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      SeChar501Dao seChar501Ignite = new SeChar501IgniteImpl(authMatchIgniteProvider);
      SECharacteristics501Data SECharacteristics501DataRocRequest = new SECharacteristics501Data();
      SECharacteristics501Data SECharacteristics501DataCache = new SECharacteristics501Data();
      setTestData("6");

      rocMatchRequest =
          (RocMatchRequest)
              mapper.readValue(TestData.matchInput6_WithSubmissionHistory, RocMatchRequest.class);

      SECharacteristics501DataCache.setTopOfChain("986083");
      seChar501Ignite.put("2201535275", SECharacteristics501DataCache);

      SECharacteristics501DataRocRequest.setTopOfChain("986082");
      seChar501Ignite.put(rocMatchRequest.getRocSENumber(), SECharacteristics501DataRocRequest);

      RocAuthSEHistoryDao rocAuthSEHistoryDao =
          new RocAuthSeHistoryIgniteImpl(authMatchIgniteProvider);
      RocAuthSEHistoryKey rocAuthSEHistoryKey =
          new RocAuthSEHistoryKey(rocMatchRequest.getRocSENumber(), "2201535275");
      RocAuthSEHistoryValue rocAuthSEHistoryValue =
          new RocAuthSEHistoryValue(
              rocMatchRequest.getRocSENumber(),
              "2201535275",
              rocMatchRequest.getRocTransactionDate());
      rocAuthSEHistoryDao.put(rocAuthSEHistoryKey, rocAuthSEHistoryValue);
      authMatchServiceImpl.populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = job.process(rocMatchRequest);
      System.out.println(
          "Match tier 6 with Submission history : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T06"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));
    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_7() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      setTestData("7");
      rocMatchRequest =
          (RocMatchRequest) mapper.readValue(TestData.matchInput7, RocMatchRequest.class);
      authMatchServiceImpl.populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = job.process(rocMatchRequest);
      System.out.println("Match tier 7 : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T07"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));
    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_8() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      setTestData("81");
      setTestData("82");
      setTestData("83");
      setTestData("84");
      rocMatchRequest =
          (RocMatchRequest) mapper.readValue(TestData.matchInput8, RocMatchRequest.class);
      authMatchServiceImpl.populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = job.process(rocMatchRequest);
      System.out.println("Match tier 8 : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T08"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));
    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_9() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      setTestData("9");
      rocMatchRequest =
          (RocMatchRequest) mapper.readValue(TestData.matchInput9, RocMatchRequest.class);
      authMatchServiceImpl.populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = job.process(rocMatchRequest);
      System.out.println("Match tier 9 : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T09"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));
    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_11() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      setTestData("11");
      rocMatchRequest =
          (RocMatchRequest) mapper.readValue(TestData.matchInput11, RocMatchRequest.class);
      authMatchServiceImpl.populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = job.process(rocMatchRequest);
      System.out.println("Match tier 11 : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T11"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));
    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_11_WithZeroAndSpaces() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      setTestData("11");
      rocMatchRequest =
          (RocMatchRequest)
              mapper.readValue(TestData.matchInput11_WithZeros_And_Spaces, RocMatchRequest.class);
      authMatchServiceImpl.populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = job.process(rocMatchRequest);
      System.out.println("Match tier 11 : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T11"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));
    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testGetCacheCount() throws AuthMatchSystemException {
    System.out.println(
        "Cache count from AuthMatch = "
            + authMatchServiceImpl
                .getAuthMatchDAOImpl()
                .getCacheCount(AuthMatchConstants.CAS_AUTH_TID_CM_CACHE));
    Assert.assertTrue(
        authMatchServiceImpl
                .getAuthMatchDAOImpl()
                .getCacheCount(AuthMatchConstants.CAS_AUTH_TID_CM_CACHE)
            >= 0);
  }

  @Test
  public void testCheckIgniteHealth() {
    authMatchDAO.checkIgniteHealth();
  }

  public static void createIndustryLeverageCache(String cacheName) {

    IgniteCache<String, ICacheBean> casAuthCache;
    ICacheBean bean = new IndustryLeverageBean();

    CacheConfiguration<String, ICacheBean> cacheConfig = new CacheConfiguration<>(cacheName);

    cacheConfig.setIndexedTypes(String.class, IndustryLeverageBean.class);
    cacheConfig.setCacheMode(CacheMode.REPLICATED);
    cacheConfig.setAtomicityMode(CacheAtomicityMode.ATOMIC);
    cacheConfig.setBackups(1);

    try {
      casAuthCache = clientIgnite.getOrCreateCache(cacheConfig);
    } catch (Exception igniteException) {
      System.out.println(igniteException.getMessage());
    }
    IndustryLeverageBean leverageBean = new IndustryLeverageBean();
    leverageBean.setIndustryCategoryCode("Others");
    leverageBean.setKey("Others");
    leverageBean.setHigherMultiplier(new BigDecimal("1.05"));
    leverageBean.setLowerMultiplier(new BigDecimal("0.85"));
    loadCache("Others", cacheName, leverageBean);
  }

  public static boolean loadCache(String key, String cacheName, IndustryLeverageBean bean) {
    // Expiry policy.
    ExpiryPolicy expiryPolicy = new CreatedExpiryPolicy(Duration.ETERNAL);
    IgniteCache<String, IndustryLeverageBean> cache = null;

    try {
      cache = clientIgnite.cache(cacheName);
      cache.withExpiryPolicy(expiryPolicy).put(key, bean);
    } catch (Exception e) {
      System.out.println("Error loading into cache : " + e);
    }
    return true;
  }

  @Test
  public void testMatchLogic_tier_3a_RTF() {
    try {
      clusterUpdate = new AuthMatchClusterUpdateAPI(rtfClientBean, "/gmsrisk/submissions/ipc1");
      List<String> elibigleTiersList = new ArrayList<String>();
      elibigleTiersList.add(AuthMatchUtil.MatchTiers.TIER_3.getValue());
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest1 = null;
      AuthMatchDAOTest.setTestData("3a");
      rocMatchRequest1 =
          (RocMatchRequest)
              mapper.readValue(TestData.matchInput3a_multipleRoc1, RocMatchRequest.class);
      rocMatchRequest1.setEligibleTiersList(elibigleTiersList);
      SubmissionMatchResponse submissionMatchResponse = job.process(rocMatchRequest1);
      clusterUpdate.cacheSynchUpCall(submissionMatchResponse);
      System.out.println("Match tier 3a RTF: " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T03"));
    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_3a_CacheSynchUp() {
    try {
      AuthMatchController ctl = new AuthMatchController(authMatchServiceImpl);
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      List<String> elibigleTiersList = new ArrayList<String>();
      elibigleTiersList.add(AuthMatchUtil.MatchTiers.TIER_3.getValue());
      AuthMatchDAOTest.setTestData("3a");
      ResponseEntity<ResponseMetaData> resp =
          ctl.cacheSynchUpProcess(
              "{\"cacheKey\":\"371000000000201|DAC98|A\",\"cacheName\":\"GMS_CAS_AUTH_CM_DAC6_CACHE_V1\",\"tidCardKey\":\"001000000000201|371000000000201|A\",\"dac6CardKey\":\"371000000000201|DAC98|A\",\"dac2CardKey\":\"371000000000201|DA|A\",\"tidCardKeysList\":null,\"dac6CardKeysList\":null,\"dac2CardKeysList\":null,\"rocSENumber\":\"1028526663\",\"rocCardNumber\":\"371000000000201\",\"donotDeleteFlag\":false,\"ramTier\":\"T03\",\"authUniqueIdentifer\":\"20193660000000406\",\"transactionId\":\"001000000000201\",\"rocAuthDAC\":\"DAC98\",\"matchedAmountUSD\":100.00}",
              "",
              "");
      RocMatchRequest rocMatchRequest1 =
          (RocMatchRequest)
              mapper.readValue(TestData.matchInput3a_multipleRoc1, RocMatchRequest.class);
      rocMatchRequest1.setEligibleTiersList(elibigleTiersList);
      SubmissionMatchResponse submissionMatchResponse = job.process(rocMatchRequest1);
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T00"));
      Assert.assertTrue(resp.getBody().getCode().equals("200"));
      System.out.println("Match tier 3a Cache SynchUp Delete Checked:");
    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_3a_CacheSynchUpUpdate() {
    try {
      AuthMatchController ctl = new AuthMatchController(authMatchServiceImpl);
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      List<String> elibigleTiersList = new ArrayList<String>();
      elibigleTiersList.add(AuthMatchUtil.MatchTiers.TIER_3.getValue());
      AuthMatchDAOTest.setTestData("3a");
      ResponseEntity<ResponseMetaData> resp =
          ctl.cacheSynchUpProcess(
              "{\"cacheKey\":\"001000000000201|371000000000201|A\",\"cacheName\":\"GMS_CAS_AUTH_TID_CM_CACHE_V3\",\"tidCardKey\":\"001000000000201|371000000000201|A\",\"dac6CardKey\":\"371000000000201|DAC98|A\",\"dac2CardKey\":\"371000000000201|DA|A\",\"tidCardKeysList\":null,\"dac6CardKeysList\":null,\"dac2CardKeysList\":null,\"rocSENumber\":\"1028526663\",\"rocCardNumber\":\"371000000000201\",\"donotDeleteFlag\":true,\"ramTier\":\"T03\",\"authUniqueIdentifer\":\"20193660000000406\",\"transactionId\":\"001000000000201\",\"rocAuthDAC\":\"DAC98\",\"matchedAmountUSD\":50.00}",
              "",
              "");
      RocMatchRequest rocMatchRequest1 =
          (RocMatchRequest)
              mapper.readValue(TestData.matchInput3a_multipleRoc1, RocMatchRequest.class);
      rocMatchRequest1.setEligibleTiersList(elibigleTiersList);
      rocMatchRequest1.setRocAmountUSD("50");
      SubmissionMatchResponse submissionMatchResponse = job.process(rocMatchRequest1);
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T03"));
      Assert.assertTrue(resp.getBody().getCode().equals("200"));
      System.out.println("Match tier 3a Cache SynchUp Update Checked:");
    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  private static Resource newResource(String id) {
    Resource r = new Resource();
    r.setId(id);
    r.setSlaTimeout(60000L);
    return r;
  }

  @SuppressWarnings("restriction")
  private static Subscription newSubscription(String input) {
    Subscription s = new Subscription();
    s.setId(UUID.randomUUID());
    s.setInputEventType(input);
    s.setOutputEventType("204NoContent");
    s.setService("http://localhost:" + server.getAddress().getPort());
    s.setDestination(LOCATION_FOR_CAS_POST);
    return s;
  }

  @SuppressWarnings("restriction")
  private static int createSubscriptions() {
    try {
      InetSocketAddress address = new InetSocketAddress(0);
      server = com.sun.net.httpserver.HttpServer.create(address, 5);
      server.createContext(LOCATION_FOR_CAS_POST);
      server.createContext(
          LOCATION_FOR_CAS_POST,
          (t) -> {
            byte[] data = "success".getBytes();
            t.sendResponseHeaders(HttpURLConnection.HTTP_NO_CONTENT, data.length);
          });
      server.start();
      List<Resource> resources = new ArrayList<>(eventTypes.length);
      List<Subscription> subscriptions = new ArrayList<>(eventTypes.length);
      for (String path : eventTypes) {
        resources.add(newResource(path));
        subscriptions.add(newSubscription(path));
      }
      addContext("/resources", resources);
      addContext("/subscriptions", subscriptions);
      return server.getAddress().getPort();
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  @SuppressWarnings("restriction")
  private static void addContext(String path, List<?> content) {
    server.createContext(
        path,
        e -> {
          byte body[] = new ObjectMapper().writeValueAsBytes(content);
          e.sendResponseHeaders(HttpURLConnection.HTTP_OK, body.length);
          e.getResponseBody().write(body);
        });
  }

  @SuppressWarnings("restriction")
  @AfterClass
  public static void shutdown() {
    if (server != null) {
      server.stop(0);
    }
  }

  @BeforeClass
  public static void setup() {
    int regPort = createSubscriptions();
    System.setProperty("CAR_ID", "41140955"); // ELF
    System.setProperty(
        "rtf_registry_endpoint" /* RtfClientConfig.RTF_REGISTRY_ENDPOINT */,
        "http://localhost:" + regPort);
    rtfClientBean = new RtfConfiguration().rtfClient("e0");
  }
}
