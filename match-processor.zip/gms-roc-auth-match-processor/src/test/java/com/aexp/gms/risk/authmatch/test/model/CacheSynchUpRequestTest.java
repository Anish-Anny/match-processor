package com.aexp.gms.risk.authmatch.test.model;

import com.aexp.gms.risk.authmatch.model.CacheSynchUpRequest;
import nl.jqno.equalsverifier.EqualsVerifier;
import nl.jqno.equalsverifier.Warning;
import org.junit.Test;

public class CacheSynchUpRequestTest {
  @Test
  public void testEqualsAndHashCode() {
    EqualsVerifier.forClass(CacheSynchUpRequest.class)
        .suppress(Warning.STRICT_INHERITANCE, Warning.NONFINAL_FIELDS)
        .verify();
  }
}
