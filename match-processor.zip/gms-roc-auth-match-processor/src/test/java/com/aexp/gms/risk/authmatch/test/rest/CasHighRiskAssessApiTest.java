/*
package com.aexp.gms.risk.authmatch.test.rest;

import static org.junit.Assert.*;

import com.aexp.gms.risk.authmatch.exception.AuthMatchSystemException;
import com.aexp.gms.risk.authmatch.model.HighRiskAssesmentRequest;
import com.aexp.gms.risk.authmatch.model.RiskAssessmentRequest;
import com.aexp.gms.risk.authmatch.model.RiskAssessmentResponse;
import com.aexp.gms.risk.authmatch.rest.client.BackoffJitter;
import com.aexp.gms.risk.authmatch.rest.client.CasHighRiskAssessApi;
import com.aexp.gms.risk.authmatch.rest.client.RestClientBackoff;
import com.aexp.gms.risk.authmatch.rest.client.RiskRestClientErrorHandler;
import java.util.Map;
import org.junit.BeforeClass;
import org.junit.Test;

public class CasHighRiskAssessApiTest {

  private static CasHighRiskAssessApi casHighRiskApi;
  private static RiskAssesmentTestData riskAssesmentTestData;
  private static BackoffJitter backoffJitter;
  private static RestClientBackoff restClientBackoff;
  private static RiskRestClientErrorHandler riskRestClientErrorHandler;

  @BeforeClass
  public static void testSetupMock() throws AuthMatchSystemException {
    System.setProperty("env", "test");
    System.setProperty("spring.profiles.active", "e0");
    System.setProperty("data-center", "test");
    System.out.println("Starting Ignite server");
    riskAssesmentTestData = new RiskAssesmentTestData();
    backoffJitter = new BackoffJitter();
    restClientBackoff = new RestClientBackoff();
    riskRestClientErrorHandler = new RiskRestClientErrorHandler();
    casHighRiskApi = new CasHighRiskAssessApi(riskRestClientErrorHandler, backoffJitter);

    String url =
        "http://CASMVLPE1UAS02.phx.aexp.com:8080/authorizations/v3/charges/authorize_submission";
    System.out.println("cas risk assessment api url = {}" + url);
    System.out.println("connectTimeout = {}" + 1000);
    System.out.println("socketTimeout = {}" + 180000);
    System.out.println("backoffMs = {}" + 125);
    System.out.println("waitCapMs = {}" + 2000);
  }

  @Test
  public void canItConstruct() {
    assertNotNull(casHighRiskApi);
  }

  @Test
  public void releaseResponse() {
    Map.Entry<RiskAssessmentRequest, RiskAssessmentResponse> responseMap =
        riskAssesmentTestData.getReleaseResponse().entrySet().iterator().next();

    RiskAssessmentResponse response =
        casHighRiskApi
            .callApi(new HighRiskAssesmentRequest(responseMap.getKey()))
            .getRisk_assesment();

    assertNotNull(response);
  }
}
*/
