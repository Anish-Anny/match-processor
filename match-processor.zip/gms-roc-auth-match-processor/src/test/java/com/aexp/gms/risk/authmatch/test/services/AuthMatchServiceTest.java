package com.aexp.gms.risk.authmatch.test.services;

import static org.junit.Assert.*;

import com.aexp.gmnt.imc.vo.SECharacteristics501Data;
import com.aexp.gms.imc.risk.rules.vo.keys.CasAuthCardAccessCode2CacheKey;
import com.aexp.gms.imc.risk.rules.vo.keys.CasAuthCardAccessCode6CacheKey;
import com.aexp.gms.imc.risk.rules.vo.keys.CasAuthTransIdCardCacheKey;
import com.aexp.gms.imc.risk.rules.vo.values.CasAuthCardAccessCode2CacheBean;
import com.aexp.gms.imc.risk.rules.vo.values.CasAuthCardAccessCode6CacheBean;
import com.aexp.gms.imc.risk.rules.vo.values.CasAuthTransIdCardCacheBean2;
import com.aexp.gms.imc.risk.rules.vo.values.RamTempRocValue;
import com.aexp.gms.risk.authmatch.controller.AuthMatchController;
import com.aexp.gms.risk.authmatch.dao.*;
import com.aexp.gms.risk.authmatch.exception.AuthMatchSystemException;
import com.aexp.gms.risk.authmatch.model.RocAuthMatchResult;
import com.aexp.gms.risk.authmatch.model.RocMatchRequest;
import com.aexp.gms.risk.authmatch.model.SubmissionMatchResponse;
import com.aexp.gms.risk.authmatch.model.ignite.key.RocAuthSEHistoryKey;
import com.aexp.gms.risk.authmatch.model.ignite.value.RocAuthSEHistoryValue;
import com.aexp.gms.risk.authmatch.rest.client.BackoffJitter;
import com.aexp.gms.risk.authmatch.rest.client.CasHighRiskAssessApi;
import com.aexp.gms.risk.authmatch.rest.client.RestClientBackoff;
import com.aexp.gms.risk.authmatch.rest.client.RiskRestClientErrorHandler;
import com.aexp.gms.risk.authmatch.services.AuthMatchCassBL;
import com.aexp.gms.risk.authmatch.services.AuthMatchServiceImpl;
import com.aexp.gms.risk.authmatch.test.dao.AuthMatchDAOTest;
import com.aexp.gms.risk.authmatch.test.dao.IgniteServerNode;
import com.aexp.gms.risk.authmatch.test.rest.RiskAssesmentTestData;
import com.aexp.gms.risk.authmatch.util.AuthMatchConstants;
import com.aexp.gms.risk.authmatch.util.KafkaProducerConfig;
import com.aexp.gms.risk.authmatch.util.PropertyLoaderUtils;
import com.aexp.gms.risk.data.AuthMatchDatabaseDAOImpl;
import com.aexp.gms.risk.data.CassandraMatchResultDAOImpl;
import com.aexp.gms.risk.data.RocAuthSeSubmissionHistoryDAOImpl;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.math.BigDecimal;
import org.apache.ignite.Ignite;
import org.apache.ignite.Ignition;
import org.apache.ignite.cache.CacheAtomicityMode;
import org.apache.ignite.cache.CacheMode;
import org.apache.ignite.configuration.CacheConfiguration;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.util.ReflectionTestUtils;

public class AuthMatchServiceTest {

  private static AuthMatchServiceImpl authMatchServiceImpl;
  private static Ignite clientIgnite = null;
  private static Ignite serverIgnite = null;
  private static TestData testData;
  private static AuthMatchDAOImpl authMatchDAO;
  private static SeChar501IgniteImpl seChar501Ignite;
  private static RocAuthSeHistoryIgniteImpl rocAuthSEHistoryIgnite;

  private static CassandraMatchResultDAOImpl cassandraMatchResultDAO =
      Mockito.mock(CassandraMatchResultDAOImpl.class);

  private static RocAuthSeSubmissionHistoryDAOImpl rocAuthSeSubmissionHistoryDAO =
      Mockito.mock(RocAuthSeSubmissionHistoryDAOImpl.class);
  private static IgniteProvider authMatchIgniteProvider;

  private static CasHighRiskAssessApi casHighRiskApi;
  private static RiskAssesmentTestData riskAssesmentTestData;
  private static BackoffJitter backoffJitter;
  private static final RocMatchRequest RocMatchRequest = null;
  private static final RocAuthMatchResult RocAuthMatchResult = null;
  private static final String Authorization = null;
  private static final com.aexp.gms.risk.authmatch.model.RocMatchRequest rocMatchRequest = null;
  private static RestClientBackoff restClientBackoff;
  private static RiskRestClientErrorHandler riskRestClientErrorHandler;
  private static RiskAssessmentThresholdDao riskAssessmentThresholdDao;
  private static AuthMatchDatabaseDAOImpl authMatchDatabaseDAOImpl;
  private static AuthMatchCassBL authMatchCassBL;
  /*  private static KafkaProducerConfig kafkaProducerConfig1;*/
  private static KafkaProducerConfig kafkaProducerConfig;
  private static AuthMatchCassBL matchCass;

  @BeforeClass
  public static void testSetupMock() throws AuthMatchSystemException {
    System.setProperty("env", "test");
    System.setProperty("spring.profiles.active", "e0");
    System.setProperty("data-center", "test");
    System.setProperty("AIM_ID", "41140955");

    System.out.println("Starting Ignite server");
    serverIgnite = new IgniteServerNode("ignite-config-server.xml").getIgnite();
    String igniteConfigFile =
        PropertyLoaderUtils.resolveFileName("imc-ignite-client-config-${env}.xml");
    clientIgnite =
        Ignition.getOrStart(
            Ignition.loadSpringBean(
                AuthMatchDAOTest.class.getClassLoader().getResourceAsStream(igniteConfigFile),
                "ignite.cfg"));

    authMatchIgniteProvider = new IgniteProvider(false);
    authMatchIgniteProvider.setIgnite(clientIgnite);
    authMatchDAO = new AuthMatchDAOImpl();
    authMatchDAO.setCacheProvider(authMatchIgniteProvider);
    rocAuthSEHistoryIgnite = new RocAuthSeHistoryIgniteImpl();
    rocAuthSEHistoryIgnite.setIgniteProvider(authMatchIgniteProvider);
    new RamTempRocValue(null, null, null, null, null);
    createSe501Cache("SeChar501Data");
    backoffJitter = new BackoffJitter();
    restClientBackoff = new RestClientBackoff();
    riskRestClientErrorHandler = new RiskRestClientErrorHandler();
    casHighRiskApi = new CasHighRiskAssessApi(riskRestClientErrorHandler, backoffJitter);
    riskAssessmentThresholdDao = new RiskAssessmentThresholdIgniteImpl();
    riskAssessmentThresholdDao.setIgniteProvider(authMatchIgniteProvider);
    new ClassPathXmlApplicationContext("test-authmatch-processor-spring-config.xml");
    authMatchDatabaseDAOImpl = new AuthMatchDatabaseDAOImpl();
    authMatchDatabaseDAOImpl.updateDataForLocalCassandra();
    authMatchCassBL = new AuthMatchCassBL(authMatchDatabaseDAOImpl, rocAuthSeSubmissionHistoryDAO);
    AuthMatchDatabaseDAOImpl authMatchDAOImpl = null;
    matchCass = new AuthMatchCassBL(authMatchDAOImpl, rocAuthSeSubmissionHistoryDAO);

    authMatchServiceImpl =
        new AuthMatchServiceImpl(
            authMatchDAO,
            new SeChar501IgniteImpl(authMatchIgniteProvider),
            cassandraMatchResultDAO,
            authMatchCassBL,
            rocAuthSEHistoryIgnite,
            rocAuthSeSubmissionHistoryDAO,
            casHighRiskApi,
            riskAssessmentThresholdDao,
            null,
            null);
    testData = new TestData();
    createRocAuthSeHistoryCache();
    createRiskAssesmentThreshold();
  }

  private static void createRocAuthSeHistoryCache() {
    CacheConfiguration<RocAuthSEHistoryKey, RocAuthSEHistoryValue>
        rocAuthSEHistoryValueCacheConfiguration =
            new CacheConfiguration<>(RocAuthSeHistoryIgniteImpl.CACHE_ROC_AUTH_HISTORY);
    rocAuthSEHistoryValueCacheConfiguration.setIndexedTypes(
        RocAuthSEHistoryKey.class, RocAuthSEHistoryValue.class);
    rocAuthSEHistoryValueCacheConfiguration
        .setAtomicityMode(CacheAtomicityMode.ATOMIC)
        .setBackups(1)
        .setCacheMode(CacheMode.PARTITIONED);
    clientIgnite.getOrCreateCache(rocAuthSEHistoryValueCacheConfiguration);
  }

  private static void createRiskAssesmentThreshold() {
    CacheConfiguration riskAssesmentThresholdConfig =
        new CacheConfiguration<>("RAM_RISK_ASSESSMENT_THRESHOLD_CACHE_V1");
    riskAssesmentThresholdConfig
        .setAtomicityMode(CacheAtomicityMode.ATOMIC)
        .setBackups(1)
        .setCacheMode(CacheMode.PARTITIONED);
    clientIgnite.getOrCreateCache(riskAssesmentThresholdConfig);
  }

  private static void createSe501Cache(String cacheName) {
    CacheConfiguration<Long, SECharacteristics501Data> seChar501CacheCfg =
        new CacheConfiguration<>(cacheName);
    seChar501CacheCfg.setIndexedTypes(Long.class, SECharacteristics501Data.class);
    seChar501CacheCfg
        .setAtomicityMode(CacheAtomicityMode.ATOMIC)
        .setBackups(1)
        .setCacheMode(CacheMode.PARTITIONED);
    clientIgnite.getOrCreateCache(seChar501CacheCfg);
  }

  @Test
  public void testMatchLogic_tier_1() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      testData.setDataForCache("1");
      CasAuthTransIdCardCacheBean2 casAuthTransIdCardCacheBean =
          testData.getTransCardBeanInstance();
      CasAuthCardAccessCode6CacheBean casAuthCardAccessCode6CacheBean =
          testData.getCardDac6BeanInstance();
      CasAuthCardAccessCode2CacheBean casAuthCardAccessCode2CacheBean =
          testData.getCardDac2BeanInstance();
      CasAuthTransIdCardCacheKey key =
          new CasAuthTransIdCardCacheKey(
              casAuthTransIdCardCacheBean.getTransactionId()
                  + "|"
                  + casAuthTransIdCardCacheBean.getCardNumber()
                  + "|D");
      authMatchDAO.putCache(
          AuthMatchConstants.CAS_AUTH_TID_CM_CACHE, key, casAuthTransIdCardCacheBean);
      authMatchDAO.loadCache(
          new CasAuthCardAccessCode6CacheKey(
              casAuthCardAccessCode6CacheBean.getCardNumber()
                  + "|"
                  + casAuthCardAccessCode6CacheBean.getAuth6Dac()
                  + "|D"),
          casAuthCardAccessCode6CacheBean);
      authMatchDAO.loadCache(
          new CasAuthCardAccessCode2CacheKey(
              casAuthCardAccessCode2CacheBean.getCardNumber()
                  + "|"
                  + casAuthCardAccessCode2CacheBean.getAuth2Dac()
                  + "|D"),
          casAuthCardAccessCode2CacheBean);
      rocMatchRequest =
          (RocMatchRequest) mapper.readValue(TestData.matchInput1, RocMatchRequest.class);
      System.out.println(
          "RocMatch Request, Trans id : " + rocMatchRequest.getRocAuthorizationTransactionId());

      ReflectionTestUtils.setField(authMatchServiceImpl, "igniteTimeOut", 6000L);

      SubmissionMatchResponse submissionMatchResponse =
          authMatchServiceImpl.matchRequest(rocMatchRequest);
      System.out.println("Match tier 1 : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T01"));

    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testpublishROCResult() throws JsonProcessingException {

    String producerBootstrapServers = "ecpkafka-dev.aexp.com:4492";
    String kafkaTopic = "SharedKafka2_41140955_RocAuthMatchResults";
    String keySerializer = "org.apache.kafka.common.serialization.StringSerializer";
    String valueSerializer = "org.apache.kafka.common.serialization.StringSerializer";
    String keystore = "src/test/resources/svc.41140955.dev.aexp.jks";
    String keystorePassword = "amex100";
    KafkaProducerConfig kafkaProducerConfig =
        new KafkaProducerConfig(
            producerBootstrapServers,
            kafkaTopic,
            keySerializer,
            valueSerializer,
            keystore,
            keystorePassword);

    RocAuthMatchResult message = new RocAuthMatchResult();

    message.setAprv_cd("DAC98");
    message.setChrg_dt("2019-08-11");
    message.setEciIndicator(null);
    message.setRoc_arn("A297189131SUBR1018");
    message.setRoc_auth_dac_cd("123456");
    message.setRoc_cm15("376661014352006");
    message.setRoc_loc_am(new BigDecimal("36321"));
    message.setRoc_loc_am_curr_cd("USD");
    message.setRoc_loc_am_dcml_plce_no(2);
    message.setRoc_se10("1010346435");
    message.setRoc_trans_dt("2017-12-31");
    message.setRoc_trans_tm("09:48:34");
    message.setRoc_usd_am(new BigDecimal("363.21"));
    message.setSoc_arn("A855283220SUBR1018");
    message.setSoc_mcc_cd("1234");
    message.setSoc_se_indus_ctgy_cd("170");
    message.setTrans_id("005608580204571");
    message.setTrans_type_tx("SUBM");
    kafkaProducerConfig.init();
    kafkaProducerConfig.publishROCResult(message);
  }

  @Test
  public void testunmatch() {

    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      rocMatchRequest =
          (RocMatchRequest) mapper.readValue(TestData.notMatch, RocMatchRequest.class);
      System.out.println(
          "RocMatch Request, Trans id : " + rocMatchRequest.getRocAuthorizationTransactionId());
      SubmissionMatchResponse submissionMatchResponse =
          authMatchServiceImpl.matchRequest(rocMatchRequest);
      System.out.println(submissionMatchResponse);
      System.out.println("Match tier 00 : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T00"));
    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testsubmissionROCMatchRequestV2() throws AuthMatchSystemException {
    ObjectMapper mapper = new ObjectMapper();
    mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
    RocMatchRequest rocMatchRequest = null;
    testData.setDataForCache("1");
    CasAuthTransIdCardCacheBean2 casAuthTransIdCardCacheBean = testData.getTransCardBeanInstance();
    CasAuthCardAccessCode6CacheBean casAuthCardAccessCode6CacheBean =
        testData.getCardDac6BeanInstance();
    CasAuthCardAccessCode2CacheBean casAuthCardAccessCode2CacheBean =
        testData.getCardDac2BeanInstance();
    CasAuthTransIdCardCacheKey key =
        new CasAuthTransIdCardCacheKey(
            casAuthTransIdCardCacheBean.getTransactionId()
                + "|"
                + casAuthTransIdCardCacheBean.getCardNumber()
                + "|D");

    authMatchDAO.putCache(
        AuthMatchConstants.CAS_AUTH_TID_CM_CACHE, key, casAuthTransIdCardCacheBean);
    authMatchDAO.loadCache(
        new CasAuthCardAccessCode6CacheKey(
            casAuthCardAccessCode6CacheBean.getCardNumber()
                + "|"
                + casAuthCardAccessCode6CacheBean.getAuth6Dac()
                + "|D"),
        casAuthCardAccessCode6CacheBean);
    authMatchDAO.loadCache(
        new CasAuthCardAccessCode2CacheKey(
            casAuthCardAccessCode2CacheBean.getCardNumber()
                + "|"
                + casAuthCardAccessCode2CacheBean.getAuth2Dac()
                + "|D"),
        casAuthCardAccessCode2CacheBean);
    SubmissionMatchResponse submissionMatchResponse = new SubmissionMatchResponse();
    RocMatchRequest matchRequest = new RocMatchRequest();
    // matchRequest.setReversalTimeStamp("2017-12-31 23:59:00");
    matchRequest.setRocAcquirerReferenceNumber("A855283220SUBR0006");
    matchRequest.setRocAmountUSD("200.44");
    matchRequest.setRocAuthDAC("123456");
    matchRequest.setRocAuthorizationTransactionId("000000000000200");
    matchRequest.setRocCardNumber("370000000000200");
    matchRequest.setRocSENumber("9097865666");
    matchRequest.setRocTransactionDate("2017-12-31");
    matchRequest.setRocTransactionTime("23:59:00");
    matchRequest.setSocAcquirerReferenceNumber("A855283220SUBR0008");
    matchRequest.setSocMerchantCategoryCode("1234");
    matchRequest.setSocSEIndustryCategoryCode("4018");
    matchRequest.setTransactionType("SUBM");

    AuthMatchController authMatchController = new AuthMatchController(authMatchServiceImpl);
    authMatchController.submissionROCMatchRequestV2(matchRequest);

    System.out.println("authMatchServiceImpl" + authMatchServiceImpl);
  }
}
