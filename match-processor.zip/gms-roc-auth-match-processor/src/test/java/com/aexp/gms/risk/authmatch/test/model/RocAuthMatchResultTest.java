package com.aexp.gms.risk.authmatch.test.model;

import com.aexp.gms.risk.authmatch.model.RocAuthMatchResult;
import com.jparams.verifier.tostring.NameStyle;
import com.jparams.verifier.tostring.ToStringVerifier;
import nl.jqno.equalsverifier.EqualsVerifier;
import nl.jqno.equalsverifier.Warning;
import org.junit.Test;

public class RocAuthMatchResultTest {
  @Test
  public void testEqualsAndHashCode() {
    EqualsVerifier.forClass(RocAuthMatchResult.class)
        .suppress(Warning.STRICT_INHERITANCE, Warning.NONFINAL_FIELDS)
        .verify();
  }

  @Test
  public void testToString() {
    ToStringVerifier.forClass(RocAuthMatchResult.class)
        .withClassName(NameStyle.SIMPLE_NAME)
        .verify();
  }
}
