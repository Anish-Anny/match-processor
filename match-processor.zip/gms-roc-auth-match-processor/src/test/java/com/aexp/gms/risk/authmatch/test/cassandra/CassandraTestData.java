package com.aexp.gms.risk.authmatch.test.cassandra;

import com.aexp.gms.risk.authmatch.exception.AuthMatchSystemException;
import com.aexp.gms.risk.data.CassandraConnectionFactory;
import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.Session;
import com.datastax.driver.core.Statement;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CassandraTestData {

  private Statement insertAuth = null;
  private static PreparedStatement insertAuthQry = null;
  private static PreparedStatement insertAuthCacheByTransIDPS = null;
  private static PreparedStatement insertAuthCacheByCardAndSe = null;
  private static PreparedStatement insertAuthCacheBy2DACPS = null;
  private static PreparedStatement insertAuthCacheBy6DACPS = null;

  public static final String insert_Auth_Qry =
      "insert into auth (trans_id,cm15, aprv_deny_cd, auth2dac_appr_cd, auth6dac_appr_cd, auth_am_in_local_curr, auth_am_in_usd, auth_curr, auth_dt, cas_pkey, frd_loss_prbl_score, frgn_sepnd_in, lwrcw_7dlog_tx, mag_swipe_in, mcc, se10, se_ctry_cd, se_indus_ctgy_cd, se_type_cd,auth_ts,sourceid) "
          + " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) USING TTL 864000 ";
  public static final String insertAuthCache_ByTransId_Qry =
      "insert into auth_by_trans_id (trans_id,cm_15,aprv_deny_cd,auth_loc_am,auth_usd_am,auth_se_no,auth_ts,card_2dac_cache_key, card_6dac_cache_key,cas_pkey,sourceid,auth_loc_am_curr_cd,voice_auth_in,pos_da_cd,eci_cd,mer_prvd_mcc_cd,cr_deny_rsn_cd,frd_deny_rsn_cd) "
          + " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) USING TTL 864000";
  public static final String insertAuthCache_ByCardAndSe_Qry =
      "insert into auth_by_card_and_se (trans_id,cm_15,aprv_deny_cd,auth_loc_am,auth_usd_am,auth_se_no,auth_ts,card_2dac_cache_key, card_6dac_cache_key,cas_pkey,sourceid,auth_loc_am_curr_cd,voice_auth_in,pos_da_cd,eci_cd,mer_prvd_mcc_cd,cr_deny_rsn_cd,frd_deny_rsn_cd,auth_mtch_in,uuid_id) "
          + " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) USING TTL 864000";
  public static final String insertAuthCache_ByDac6_Qry =
      "insert into auth_by_6dac_and_se (cm15,six_dgt_aprv_cde,aprv_deny_cd,cas_pkey,auth_se_no,auth_usd_am,auth_loc_am,card_2dac_cache_key, trans_id,auth_ts,auth_pref_am) "
          + " values (?,?,?,?,?,?,?,?,?,?,?) USING TTL 864000";
  public static final String insertAuthCache_ByDac2_Qry =
      "insert into auth_by_2dac_and_se  (cm15,two_dgt_aprv_cde,aprv_deny_cd,cas_pkey,auth_se_no,auth_usd_am,auth_loc_am,card_6dac_cache_key, trans_id,auth_ts,auth_pref_am) "
          + " values (?,?,?,?,?,?,?,?,?,?,?) USING TTL 864000";
  private static ApplicationContext applicationContext;

  public static final Map<String, Object> loadInput1Map = new HashMap<String, Object>();
  public static final Map<String, Object> loadInput2Map = new HashMap<String, Object>();
  public static final Map<String, Object> loadInput2LocalAmountMap = new HashMap<String, Object>();
  public static final Map<String, Object> loadInput3aMap = new HashMap<String, Object>();
  public static final Map<String, Object> loadInput3aLocalAmountMap = new HashMap<String, Object>();
  public static final Map<String, Object> loadInput3b1Map = new HashMap<String, Object>();
  public static final Map<String, Object> loadInput3b2Map = new HashMap<String, Object>();
  public static final Map<String, Object> loadInput3c1Map = new HashMap<String, Object>();
  public static final Map<String, Object> loadInput3c2Map = new HashMap<String, Object>();
  public static final Map<String, Object> loadInput3cLocalAmountMap = new HashMap<String, Object>();
  public static final Map<String, Object> loadInput4Map = new HashMap<String, Object>();
  public static final Map<String, Object> loadInput4LocalAmountMap = new HashMap<String, Object>();
  public static final Map<String, Object> loadInput5Map = new HashMap<String, Object>();
  public static final Map<String, Object> loadInput5LocalAmountMap = new HashMap<String, Object>();
  public static final Map<String, Object> loadInput6Map = new HashMap<String, Object>();
  public static final Map<String, Object> loadInput6LocalAmountMap = new HashMap<String, Object>();
  public static final Map<String, Object> loadInput7Map = new HashMap<String, Object>();
  public static final Map<String, Object> loadInput7LocalAmountMap = new HashMap<String, Object>();
  public static final Map<String, Object> loadInput81Map = new HashMap<String, Object>();
  public static final Map<String, Object> loadInput82Map = new HashMap<String, Object>();
  public static final Map<String, Object> loadInput83Map = new HashMap<String, Object>();
  public static final Map<String, Object> loadInput9Map = new HashMap<String, Object>();
  public static final Map<String, Object> loadInput11Map = new HashMap<String, Object>();
  public static final Map<String, Object> loadInput2WithRTFData = new HashMap<String, Object>();

  //	@BeforeClass
  public static void testSetupMock() throws AuthMatchSystemException {
    System.setProperty("env", "e0");
    System.setProperty("spring.profiles.active", "e0");
    System.setProperty("data-center", "test");
    System.out.println("Starting Ignite server");
    applicationContext =
        new ClassPathXmlApplicationContext("test-authmatch-processor-spring-config.xml");

    loadInput1Map.put("trans_id", "000000000000200");
    loadInput1Map.put("cm_15", "370000000000200");
    loadInput1Map.put("aprv_deny_cd", "D");
    loadInput1Map.put("auth_loc_am", new BigDecimal("10.99"));
    loadInput1Map.put("auth_usd_am", new BigDecimal("10.99"));
    loadInput1Map.put("auth_se_no", "9097865666");
    loadInput1Map.put("auth_ts", "071818 000000");
    loadInput1Map.put("card_2dac_cache_key", "370000000000200|D");
    loadInput1Map.put("card_6dac_cache_key", "370000000000200|D");
    loadInput1Map.put("cas_pkey", "000000000000200");
    loadInput1Map.put("sourceid", "SUBM");
    loadInput1Map.put("auth_loc_am_curr_cd", "CAD");
    loadInput1Map.put("voice_auth_in", "V");
    loadInput1Map.put("pos_da_cd", "POS");
    loadInput1Map.put("eci_cd", "ECI");
    loadInput1Map.put("mer_prvd_mcc_cd", "MCC");
    loadInput1Map.put("cr_deny_rsn_cd", "DN");
    loadInput1Map.put("frd_deny_rsn_cd", "FRD");
    loadInput1Map.put("two_dgt_aprv_cde", "AA");
    loadInput1Map.put("six_dgt_aprv_cde", "BBBBBB");
    loadInput1Map.put("auth_pref_am", new BigDecimal("0.00"));
    loadInput1Map.put("auth_mtch_in", "");
    loadInput1Map.put("uuid_id", UUID.randomUUID());

    loadInput2Map.put("trans_id", "001000000000202");
    loadInput2Map.put("cm_15", "371000000000202");
    loadInput2Map.put("aprv_deny_cd", "A");
    loadInput2Map.put("auth_loc_am", new BigDecimal("200.44"));
    loadInput2Map.put("auth_usd_am", new BigDecimal("200.44"));
    loadInput2Map.put("auth_se_no", "9429531213");
    loadInput2Map.put("auth_ts", "101112 000000");
    loadInput2Map.put("card_2dac_cache_key", "371000000000202|AA|A");
    loadInput2Map.put("card_6dac_cache_key", "371000000000202|BBBBBB|A");
    loadInput2Map.put("cas_pkey", "001000000000202");
    loadInput2Map.put("sourceid", "SUBM");
    loadInput2Map.put("auth_loc_am_curr_cd", "CAD");
    loadInput2Map.put("voice_auth_in", "V");
    loadInput2Map.put("pos_da_cd", "POS");
    loadInput2Map.put("eci_cd", "ECI");
    loadInput2Map.put("mer_prvd_mcc_cd", "MCC");
    loadInput2Map.put("cr_deny_rsn_cd", "DN");
    loadInput2Map.put("frd_deny_rsn_cd", "FRD");
    loadInput2Map.put("two_dgt_aprv_cde", "AA");
    loadInput2Map.put("six_dgt_aprv_cde", "BBBBBB");
    loadInput2Map.put("auth_pref_am", new BigDecimal("0.00"));
    loadInput2Map.put("auth_mtch_in", "");
    loadInput2Map.put("uuid_id", UUID.randomUUID());

    loadInput2LocalAmountMap.put("trans_id", "001000000000202");
    loadInput2LocalAmountMap.put("cm_15", "371700000000202");
    loadInput2LocalAmountMap.put("aprv_deny_cd", "A");
    loadInput2LocalAmountMap.put("auth_loc_am", new BigDecimal("200.44"));
    loadInput2LocalAmountMap.put("auth_usd_am", new BigDecimal("200.44"));
    loadInput2LocalAmountMap.put("auth_se_no", "9097865666");
    loadInput2LocalAmountMap.put("auth_ts", "123117 000000");
    loadInput2LocalAmountMap.put("card_2dac_cache_key", "371700000000202|AA|A");
    loadInput2LocalAmountMap.put("card_6dac_cache_key", "371700000000202|BBBBBB|A");
    loadInput2LocalAmountMap.put("cas_pkey", "001000000000202");
    loadInput2LocalAmountMap.put("sourceid", "SUBM");
    loadInput2LocalAmountMap.put("auth_loc_am_curr_cd", "CAD");
    loadInput2LocalAmountMap.put("voice_auth_in", "V");
    loadInput2LocalAmountMap.put("pos_da_cd", "POS");
    loadInput2LocalAmountMap.put("eci_cd", "ECI");
    loadInput2LocalAmountMap.put("mer_prvd_mcc_cd", "MCC");
    loadInput2LocalAmountMap.put("cr_deny_rsn_cd", "DN");
    loadInput2LocalAmountMap.put("frd_deny_rsn_cd", "FRD");
    loadInput2LocalAmountMap.put("two_dgt_aprv_cde", "AA");
    loadInput2LocalAmountMap.put("six_dgt_aprv_cde", "BBBBBB");
    loadInput2LocalAmountMap.put("auth_pref_am", new BigDecimal("0.00"));
    loadInput2LocalAmountMap.put("auth_mtch_in", "");
    loadInput2LocalAmountMap.put("uuid_id", UUID.randomUUID());

    loadInput3aMap.put("trans_id", "001000000000201");
    loadInput3aMap.put("cm_15", "371000000000201");
    loadInput3aMap.put("aprv_deny_cd", "A");
    loadInput3aMap.put("auth_loc_am", new BigDecimal("200.44"));
    loadInput3aMap.put("auth_usd_am", new BigDecimal("200.44"));
    loadInput3aMap.put("auth_se_no", "9429531213");
    loadInput3aMap.put("auth_ts", "101112 000000");
    loadInput3aMap.put("card_2dac_cache_key", "371000000000202|AA|A");
    loadInput3aMap.put("card_6dac_cache_key", "371000000000202|123456|A");
    loadInput3aMap.put("cas_pkey", "001000000000202");
    loadInput3aMap.put("sourceid", "SUBM");
    loadInput3aMap.put("auth_loc_am_curr_cd", "CAD");
    loadInput3aMap.put("voice_auth_in", "V");
    loadInput3aMap.put("pos_da_cd", "POS");
    loadInput3aMap.put("eci_cd", "ECI");
    loadInput3aMap.put("mer_prvd_mcc_cd", "MCC");
    loadInput3aMap.put("cr_deny_rsn_cd", "DN");
    loadInput3aMap.put("frd_deny_rsn_cd", "FRD");
    loadInput3aMap.put("two_dgt_aprv_cde", "AA");
    loadInput3aMap.put("six_dgt_aprv_cde", "123456");
    loadInput3aMap.put("auth_pref_am", new BigDecimal("0.00"));
    loadInput3aMap.put("auth_mtch_in", "");
    loadInput3aMap.put("uuid_id", UUID.randomUUID());

    loadInput3aLocalAmountMap.put("trans_id", "001000000000201");
    loadInput3aLocalAmountMap.put("cm_15", "371700000000201");
    loadInput3aLocalAmountMap.put("aprv_deny_cd", "A");
    loadInput3aLocalAmountMap.put("auth_loc_am", new BigDecimal("200.44"));
    loadInput3aLocalAmountMap.put("auth_usd_am", new BigDecimal("10.99"));
    loadInput3aLocalAmountMap.put("auth_se_no", "9429531213");
    loadInput3aLocalAmountMap.put("auth_ts", "123117 000000");
    loadInput3aLocalAmountMap.put("card_2dac_cache_key", "371700000000201|AA|A");
    loadInput3aLocalAmountMap.put("card_6dac_cache_key", "371700000000201|BBBBBB|A");
    loadInput3aLocalAmountMap.put("cas_pkey", "001000000000201");
    loadInput3aLocalAmountMap.put("sourceid", "SUBM");
    loadInput3aLocalAmountMap.put("auth_loc_am_curr_cd", "CAD");
    loadInput3aLocalAmountMap.put("voice_auth_in", "V");
    loadInput3aLocalAmountMap.put("pos_da_cd", "POS");
    loadInput3aLocalAmountMap.put("eci_cd", "ECI");
    loadInput3aLocalAmountMap.put("mer_prvd_mcc_cd", "MCC");
    loadInput3aLocalAmountMap.put("cr_deny_rsn_cd", "DN");
    loadInput3aLocalAmountMap.put("frd_deny_rsn_cd", "FRD");
    loadInput3aLocalAmountMap.put("two_dgt_aprv_cde", "AA");
    loadInput3aLocalAmountMap.put("six_dgt_aprv_cde", "BBBBBB");
    loadInput3aLocalAmountMap.put("auth_pref_am", new BigDecimal("0.00"));
    loadInput3aLocalAmountMap.put("auth_mtch_in", "");
    loadInput3aLocalAmountMap.put("uuid_id", UUID.randomUUID());

    loadInput3b1Map.put("trans_id", "001100000000201");
    loadInput3b1Map.put("cm_15", "371710000000543");
    loadInput3b1Map.put("aprv_deny_cd", "A");
    loadInput3b1Map.put("auth_loc_am", new BigDecimal("200.44"));
    loadInput3b1Map.put("auth_usd_am", new BigDecimal("200.44"));
    loadInput3b1Map.put("auth_se_no", "9429531213");
    loadInput3b1Map.put("auth_ts", "101112 000000");
    loadInput3b1Map.put("card_2dac_cache_key", "371000000000202|AA|A");
    loadInput3b1Map.put("card_6dac_cache_key", "371000000000202|123456|A");
    loadInput3b1Map.put("cas_pkey", "001000000000202");
    loadInput3b1Map.put("sourceid", "SUBM");
    loadInput3b1Map.put("auth_loc_am_curr_cd", "CAD");
    loadInput3b1Map.put("voice_auth_in", "V");
    loadInput3b1Map.put("pos_da_cd", "POS");
    loadInput3b1Map.put("eci_cd", "ECI");
    loadInput3b1Map.put("mer_prvd_mcc_cd", "MCC");
    loadInput3b1Map.put("cr_deny_rsn_cd", "DN");
    loadInput3b1Map.put("frd_deny_rsn_cd", "FRD");
    loadInput3b1Map.put("two_dgt_aprv_cde", "AA");
    loadInput3b1Map.put("six_dgt_aprv_cde", "123456");
    loadInput3b1Map.put("auth_pref_am", new BigDecimal("0.00"));
    loadInput3b1Map.put("auth_mtch_in", "");
    loadInput3b1Map.put("uuid_id", UUID.randomUUID());

    loadInput3b2Map.put("trans_id", "001200000000201");
    loadInput3b2Map.put("cm_15", "371710000000543");
    loadInput3b2Map.put("aprv_deny_cd", "A");
    loadInput3b2Map.put("auth_loc_am", new BigDecimal("100.44"));
    loadInput3b2Map.put("auth_usd_am", new BigDecimal("100.44"));
    loadInput3b2Map.put("auth_se_no", "9429531213");
    loadInput3b2Map.put("auth_ts", "101112 000000");
    loadInput3b2Map.put("card_2dac_cache_key", "371000000000202|AA|A");
    loadInput3b2Map.put("card_6dac_cache_key", "371000000000202|123456|A");
    loadInput3b2Map.put("cas_pkey", "001000000000202");
    loadInput3b2Map.put("sourceid", "SUBM");
    loadInput3b2Map.put("auth_loc_am_curr_cd", "CAD");
    loadInput3b2Map.put("voice_auth_in", "V");
    loadInput3b2Map.put("pos_da_cd", "POS");
    loadInput3b2Map.put("eci_cd", "ECI");
    loadInput3b2Map.put("mer_prvd_mcc_cd", "MCC");
    loadInput3b2Map.put("cr_deny_rsn_cd", "DN");
    loadInput3b2Map.put("frd_deny_rsn_cd", "FRD");
    loadInput3b2Map.put("two_dgt_aprv_cde", "AA");
    loadInput3b2Map.put("six_dgt_aprv_cde", "123456");
    loadInput3b2Map.put("auth_pref_am", new BigDecimal("0.00"));
    loadInput3b2Map.put("auth_mtch_in", "");
    loadInput3b2Map.put("uuid_id", UUID.randomUUID());

    loadInput3c1Map.put("trans_id", "005000000000201");
    loadInput3c1Map.put("cm_15", "375000000000201");
    loadInput3c1Map.put("aprv_deny_cd", "A");
    loadInput3c1Map.put("auth_loc_am", new BigDecimal("70.00"));
    loadInput3c1Map.put("auth_usd_am", new BigDecimal("70.00"));
    loadInput3c1Map.put("auth_se_no", "9429531213");
    loadInput3c1Map.put("auth_ts", "123117 000000");
    loadInput3c1Map.put("card_2dac_cache_key", "371000000000202|AA|A");
    loadInput3c1Map.put("card_6dac_cache_key", "371000000000202|123456|A");
    loadInput3c1Map.put("cas_pkey", "001000000000202");
    loadInput3c1Map.put("sourceid", "SUBM");
    loadInput3c1Map.put("auth_loc_am_curr_cd", "CAD");
    loadInput3c1Map.put("voice_auth_in", "V");
    loadInput3c1Map.put("pos_da_cd", "POS");
    loadInput3c1Map.put("eci_cd", "ECI");
    loadInput3c1Map.put("mer_prvd_mcc_cd", "MCC");
    loadInput3c1Map.put("cr_deny_rsn_cd", "DN");
    loadInput3c1Map.put("frd_deny_rsn_cd", "FRD");
    loadInput3c1Map.put("two_dgt_aprv_cde", "AA");
    loadInput3c1Map.put("six_dgt_aprv_cde", "123456");
    loadInput3c1Map.put("auth_pref_am", new BigDecimal("0.00"));
    loadInput3c1Map.put("auth_mtch_in", "");
    loadInput3c1Map.put("uuid_id", UUID.randomUUID());

    loadInput3c2Map.put("trans_id", "006000000000201");
    loadInput3c2Map.put("cm_15", "376000000000201");
    loadInput3c2Map.put("aprv_deny_cd", "A");
    loadInput3c2Map.put("auth_loc_am", new BigDecimal("850.00"));
    loadInput3c2Map.put("auth_usd_am", new BigDecimal("850.00"));
    loadInput3c2Map.put("auth_se_no", "9429531213");
    loadInput3c2Map.put("auth_ts", "101112 000000");
    loadInput3c2Map.put("card_2dac_cache_key", "371000000000202|AA|A");
    loadInput3c2Map.put("card_6dac_cache_key", "371000000000202|123456|A");
    loadInput3c2Map.put("cas_pkey", "001000000000202");
    loadInput3c2Map.put("sourceid", "SUBM");
    loadInput3c2Map.put("auth_loc_am_curr_cd", "CAD");
    loadInput3c2Map.put("voice_auth_in", "V");
    loadInput3c2Map.put("pos_da_cd", "POS");
    loadInput3c2Map.put("eci_cd", "ECI");
    loadInput3c2Map.put("mer_prvd_mcc_cd", "MCC");
    loadInput3c2Map.put("cr_deny_rsn_cd", "DN");
    loadInput3c2Map.put("frd_deny_rsn_cd", "FRD");
    loadInput3c2Map.put("two_dgt_aprv_cde", "AA");
    loadInput3c2Map.put("six_dgt_aprv_cde", "123456");
    loadInput3c2Map.put("auth_pref_am", new BigDecimal("0.00"));
    loadInput3c2Map.put("auth_mtch_in", "");
    loadInput3c2Map.put("uuid_id", UUID.randomUUID());

    loadInput3cLocalAmountMap.put("trans_id", "005000000000201");
    loadInput3cLocalAmountMap.put("cm_15", "375700000000201");
    loadInput3cLocalAmountMap.put("aprv_deny_cd", "A");
    loadInput3cLocalAmountMap.put("auth_loc_am", new BigDecimal("70.00"));
    loadInput3cLocalAmountMap.put("auth_usd_am", new BigDecimal("70.00"));
    loadInput3cLocalAmountMap.put("auth_se_no", "9429531213");
    loadInput3cLocalAmountMap.put("auth_ts", "123117 000000");
    loadInput3cLocalAmountMap.put("card_2dac_cache_key", "375700000000201|AA|A");
    loadInput3cLocalAmountMap.put("card_6dac_cache_key", "375700000000201|BBBBBB|A");
    loadInput3cLocalAmountMap.put("cas_pkey", "001000000000202");
    loadInput3cLocalAmountMap.put("sourceid", "SUBM");
    loadInput3cLocalAmountMap.put("auth_loc_am_curr_cd", "CAD");
    loadInput3cLocalAmountMap.put("voice_auth_in", "V");
    loadInput3cLocalAmountMap.put("pos_da_cd", "POS");
    loadInput3cLocalAmountMap.put("eci_cd", "ECI");
    loadInput3cLocalAmountMap.put("mer_prvd_mcc_cd", "MCC");
    loadInput3cLocalAmountMap.put("cr_deny_rsn_cd", "DN");
    loadInput3cLocalAmountMap.put("frd_deny_rsn_cd", "FRD");
    loadInput3cLocalAmountMap.put("two_dgt_aprv_cde", "AA");
    loadInput3cLocalAmountMap.put("six_dgt_aprv_cde", "BBBBBB");
    loadInput3cLocalAmountMap.put("auth_pref_am", new BigDecimal("0.00"));
    loadInput3cLocalAmountMap.put("auth_mtch_in", "");
    loadInput3cLocalAmountMap.put("uuid_id", UUID.randomUUID());

    loadInput4Map.put("trans_id", "006145570697679");
    loadInput4Map.put("cm_15", "379803969091008");
    loadInput4Map.put("aprv_deny_cd", "A");
    loadInput4Map.put("auth_loc_am", new BigDecimal("96.00"));
    loadInput4Map.put("auth_usd_am", new BigDecimal("96.00"));
    loadInput4Map.put("auth_se_no", "2201535275");
    loadInput4Map.put("auth_ts", "071818 000000");
    loadInput4Map.put("card_2dac_cache_key", "371000000000202|32|A");
    loadInput4Map.put("card_6dac_cache_key", "371000000000202|104962|A");
    loadInput4Map.put("cas_pkey", "001000000000202");
    loadInput4Map.put("sourceid", "SUBM");
    loadInput4Map.put("auth_loc_am_curr_cd", "CAD");
    loadInput4Map.put("voice_auth_in", "V");
    loadInput4Map.put("pos_da_cd", "POS");
    loadInput4Map.put("eci_cd", "ECI");
    loadInput4Map.put("mer_prvd_mcc_cd", "MCC");
    loadInput4Map.put("cr_deny_rsn_cd", "DN");
    loadInput4Map.put("frd_deny_rsn_cd", "FRD");
    loadInput4Map.put("two_dgt_aprv_cde", "32");
    loadInput4Map.put("six_dgt_aprv_cde", "104962");
    loadInput4Map.put("auth_pref_am", new BigDecimal("0.00"));
    loadInput4Map.put("auth_mtch_in", "");
    loadInput4Map.put("uuid_id", UUID.randomUUID());

    loadInput4LocalAmountMap.put("trans_id", "005000000000201");
    loadInput4LocalAmountMap.put("cm_15", "377700000000201");
    loadInput4LocalAmountMap.put("aprv_deny_cd", "A");
    loadInput4LocalAmountMap.put("auth_loc_am", new BigDecimal("96.00"));
    loadInput4LocalAmountMap.put("auth_usd_am", new BigDecimal("96.00"));
    loadInput4LocalAmountMap.put("auth_se_no", "2201535275");
    loadInput4LocalAmountMap.put("auth_ts", "071818 000000");
    loadInput4LocalAmountMap.put("card_2dac_cache_key", "377700000000201|AA|A");
    loadInput4LocalAmountMap.put("card_6dac_cache_key", "377700000000201|104962|A");
    loadInput4LocalAmountMap.put("cas_pkey", "001000000000202");
    loadInput4LocalAmountMap.put("sourceid", "SUBM");
    loadInput4LocalAmountMap.put("auth_loc_am_curr_cd", "CAD");
    loadInput4LocalAmountMap.put("voice_auth_in", "V");
    loadInput4LocalAmountMap.put("pos_da_cd", "POS");
    loadInput4LocalAmountMap.put("eci_cd", "ECI");
    loadInput4LocalAmountMap.put("mer_prvd_mcc_cd", "MCC");
    loadInput4LocalAmountMap.put("cr_deny_rsn_cd", "DN");
    loadInput4LocalAmountMap.put("frd_deny_rsn_cd", "FRD");
    loadInput4LocalAmountMap.put("two_dgt_aprv_cde", "AA");
    loadInput4LocalAmountMap.put("six_dgt_aprv_cde", "104962");
    loadInput4LocalAmountMap.put("auth_pref_am", new BigDecimal("0.00"));
    loadInput4LocalAmountMap.put("auth_mtch_in", "");
    loadInput4LocalAmountMap.put("uuid_id", UUID.randomUUID());

    loadInput5Map.put("trans_id", "006145570697680");
    loadInput5Map.put("cm_15", "379803969091099");
    loadInput5Map.put("aprv_deny_cd", "A");
    loadInput5Map.put("auth_loc_am", new BigDecimal("96.00"));
    loadInput5Map.put("auth_usd_am", new BigDecimal("96.00"));
    loadInput5Map.put("auth_se_no", "2201535275");
    loadInput5Map.put("auth_ts", "071818 000000");
    loadInput5Map.put("card_2dac_cache_key", "379803969091099|32|A");
    loadInput5Map.put("card_6dac_cache_key", "379803969091099|104962|A");
    loadInput5Map.put("cas_pkey", "001000000000202");
    loadInput5Map.put("sourceid", "SUBM");
    loadInput5Map.put("auth_loc_am_curr_cd", "CAD");
    loadInput5Map.put("voice_auth_in", "V");
    loadInput5Map.put("pos_da_cd", "POS");
    loadInput5Map.put("eci_cd", "ECI");
    loadInput5Map.put("mer_prvd_mcc_cd", "MCC");
    loadInput5Map.put("cr_deny_rsn_cd", "DN");
    loadInput5Map.put("frd_deny_rsn_cd", "FRD");
    loadInput5Map.put("two_dgt_aprv_cde", "32");
    loadInput5Map.put("six_dgt_aprv_cde", "104962");
    loadInput5Map.put("auth_pref_am", new BigDecimal("0.00"));
    loadInput5Map.put("auth_mtch_in", "");
    loadInput5Map.put("uuid_id", UUID.randomUUID());

    loadInput5LocalAmountMap.put("trans_id", "006145570697680");
    loadInput5LocalAmountMap.put("cm_15", "379703969091099");
    loadInput5LocalAmountMap.put("aprv_deny_cd", "A");
    loadInput5LocalAmountMap.put("auth_loc_am", new BigDecimal("96.00"));
    loadInput5LocalAmountMap.put("auth_usd_am", new BigDecimal("96.00"));
    loadInput5LocalAmountMap.put("auth_se_no", "2201535275");
    loadInput5LocalAmountMap.put("auth_ts", "071818 000000");
    loadInput5LocalAmountMap.put("card_2dac_cache_key", "379703969091099|AA|A");
    loadInput5LocalAmountMap.put("card_6dac_cache_key", "379703969091099|104962|A");
    loadInput5LocalAmountMap.put("cas_pkey", "001000000000202");
    loadInput5LocalAmountMap.put("sourceid", "SUBM");
    loadInput5LocalAmountMap.put("auth_loc_am_curr_cd", "CAD");
    loadInput5LocalAmountMap.put("voice_auth_in", "V");
    loadInput5LocalAmountMap.put("pos_da_cd", "POS");
    loadInput5LocalAmountMap.put("eci_cd", "ECI");
    loadInput5LocalAmountMap.put("mer_prvd_mcc_cd", "MCC");
    loadInput5LocalAmountMap.put("cr_deny_rsn_cd", "DN");
    loadInput5LocalAmountMap.put("frd_deny_rsn_cd", "FRD");
    loadInput5LocalAmountMap.put("two_dgt_aprv_cde", "AA");
    loadInput5LocalAmountMap.put("six_dgt_aprv_cde", "104962");
    loadInput5LocalAmountMap.put("auth_pref_am", new BigDecimal("0.00"));
    loadInput5LocalAmountMap.put("auth_mtch_in", "");
    loadInput5LocalAmountMap.put("uuid_id", UUID.randomUUID());

    loadInput6Map.put("trans_id", "006145570697679");
    loadInput6Map.put("cm_15", "377000000000105");
    loadInput6Map.put("aprv_deny_cd", "A");
    loadInput6Map.put("auth_loc_am", new BigDecimal("96.00"));
    loadInput6Map.put("auth_usd_am", new BigDecimal("96.00"));
    loadInput6Map.put("auth_se_no", "2201535275");
    loadInput6Map.put("auth_ts", "071818 000000");
    loadInput6Map.put("card_2dac_cache_key", "371000000000202|32|A");
    loadInput6Map.put("card_6dac_cache_key", "371000000000202|104962|A");
    loadInput6Map.put("cas_pkey", "001000000000202");
    loadInput6Map.put("sourceid", "SUBM");
    loadInput6Map.put("auth_loc_am_curr_cd", "CAD");
    loadInput6Map.put("voice_auth_in", "V");
    loadInput6Map.put("pos_da_cd", "POS");
    loadInput6Map.put("eci_cd", "ECI");
    loadInput6Map.put("mer_prvd_mcc_cd", "MCC");
    loadInput6Map.put("cr_deny_rsn_cd", "DN");
    loadInput6Map.put("frd_deny_rsn_cd", "FRD");
    loadInput6Map.put("two_dgt_aprv_cde", "32");
    loadInput6Map.put("six_dgt_aprv_cde", "104962");
    loadInput6Map.put("auth_pref_am", new BigDecimal("0.00"));
    loadInput6Map.put("auth_mtch_in", "");
    loadInput6Map.put("uuid_id", UUID.randomUUID());

    loadInput6LocalAmountMap.put("trans_id", "006145570697679");
    loadInput6LocalAmountMap.put("cm_15", "378700000000201");
    loadInput6LocalAmountMap.put("aprv_deny_cd", "A");
    loadInput6LocalAmountMap.put("auth_loc_am", new BigDecimal("96.00"));
    loadInput6LocalAmountMap.put("auth_usd_am", new BigDecimal("96.00"));
    loadInput6LocalAmountMap.put("auth_se_no", "2201535275");
    loadInput6LocalAmountMap.put("auth_ts", "071818 000000");
    loadInput6LocalAmountMap.put("card_2dac_cache_key", "378700000000201|32|A");
    loadInput6LocalAmountMap.put("card_6dac_cache_key", "378700000000201|104962|A");
    loadInput6LocalAmountMap.put("cas_pkey", "001000000000202");
    loadInput6LocalAmountMap.put("sourceid", "SUBM");
    loadInput6LocalAmountMap.put("auth_loc_am_curr_cd", "CAD");
    loadInput6LocalAmountMap.put("voice_auth_in", "V");
    loadInput6LocalAmountMap.put("pos_da_cd", "POS");
    loadInput6LocalAmountMap.put("eci_cd", "ECI");
    loadInput6LocalAmountMap.put("mer_prvd_mcc_cd", "MCC");
    loadInput6LocalAmountMap.put("cr_deny_rsn_cd", "DN");
    loadInput6LocalAmountMap.put("frd_deny_rsn_cd", "FRD");
    loadInput6LocalAmountMap.put("two_dgt_aprv_cde", "AA");
    loadInput6LocalAmountMap.put("six_dgt_aprv_cde", "104962");
    loadInput6LocalAmountMap.put("auth_pref_am", new BigDecimal("0.00"));
    loadInput6LocalAmountMap.put("auth_mtch_in", "");
    loadInput6LocalAmountMap.put("uuid_id", UUID.randomUUID());

    loadInput7Map.put("trans_id", "006145570697679");
    loadInput7Map.put("cm_15", "379803969091680");
    loadInput7Map.put("aprv_deny_cd", "A");
    loadInput7Map.put("auth_loc_am", new BigDecimal("96.00"));
    loadInput7Map.put("auth_usd_am", new BigDecimal("96.00"));
    loadInput7Map.put("auth_se_no", "2201535275");
    loadInput7Map.put("auth_ts", "071818 000000");
    loadInput7Map.put("card_2dac_cache_key", "371000000000202|32|A");
    loadInput7Map.put("card_6dac_cache_key", "371000000000202|104962|A");
    loadInput7Map.put("cas_pkey", "001000000000202");
    loadInput7Map.put("sourceid", "SUBM");
    loadInput7Map.put("auth_loc_am_curr_cd", "CAD");
    loadInput7Map.put("voice_auth_in", "V");
    loadInput7Map.put("pos_da_cd", "POS");
    loadInput7Map.put("eci_cd", "ECI");
    loadInput7Map.put("mer_prvd_mcc_cd", "MCC");
    loadInput7Map.put("cr_deny_rsn_cd", "DN");
    loadInput7Map.put("frd_deny_rsn_cd", "FRD");
    loadInput7Map.put("two_dgt_aprv_cde", "32");
    loadInput7Map.put("six_dgt_aprv_cde", "104962");
    loadInput7Map.put("auth_pref_am", new BigDecimal("0.00"));
    loadInput7Map.put("auth_mtch_in", "");
    loadInput7Map.put("uuid_id", UUID.randomUUID());

    loadInput7LocalAmountMap.put("trans_id", "006145570697680");
    loadInput7LocalAmountMap.put("cm_15", "379803969091099");
    loadInput7LocalAmountMap.put("aprv_deny_cd", "A");
    loadInput7LocalAmountMap.put("auth_loc_am", new BigDecimal("96.00"));
    loadInput7LocalAmountMap.put("auth_usd_am", new BigDecimal("96.00"));
    loadInput7LocalAmountMap.put("auth_se_no", "2201535275");
    loadInput7LocalAmountMap.put("auth_ts", "071818 000000");
    loadInput7LocalAmountMap.put("card_2dac_cache_key", "371000000000202|32|A");
    loadInput7LocalAmountMap.put("card_6dac_cache_key", "371000000000202|104962|A");
    loadInput7LocalAmountMap.put("cas_pkey", "001000000000202");
    loadInput7LocalAmountMap.put("sourceid", "SUBM");
    loadInput7LocalAmountMap.put("auth_loc_am_curr_cd", "CAD");
    loadInput7LocalAmountMap.put("voice_auth_in", "V");
    loadInput7LocalAmountMap.put("pos_da_cd", "POS");
    loadInput7LocalAmountMap.put("eci_cd", "ECI");
    loadInput7LocalAmountMap.put("mer_prvd_mcc_cd", "MCC");
    loadInput7LocalAmountMap.put("cr_deny_rsn_cd", "DN");
    loadInput7LocalAmountMap.put("frd_deny_rsn_cd", "FRD");
    loadInput7LocalAmountMap.put("two_dgt_aprv_cde", "AA");
    loadInput7LocalAmountMap.put("six_dgt_aprv_cde", "104962");
    loadInput7LocalAmountMap.put("auth_pref_am", new BigDecimal("0.00"));
    loadInput7LocalAmountMap.put("auth_mtch_in", "");
    loadInput7LocalAmountMap.put("uuid_id", UUID.randomUUID());

    loadInput81Map.put("trans_id", "001100000000201");
    loadInput81Map.put("cm_15", "371100000000722");
    loadInput81Map.put("aprv_deny_cd", "A");
    loadInput81Map.put("auth_loc_am", new BigDecimal("220.00"));
    loadInput81Map.put("auth_usd_am", new BigDecimal("220.00"));
    loadInput81Map.put("auth_se_no", "9429531213");
    loadInput81Map.put("auth_ts", "071818 000000");
    loadInput81Map.put("card_2dac_cache_key", "371000000000202|32|A");
    loadInput81Map.put("card_6dac_cache_key", "371000000000202|104962|A");
    loadInput81Map.put("cas_pkey", "001000000000202");
    loadInput81Map.put("sourceid", "SUBM");
    loadInput81Map.put("auth_loc_am_curr_cd", "CAD");
    loadInput81Map.put("voice_auth_in", "V");
    loadInput81Map.put("pos_da_cd", "POS");
    loadInput81Map.put("eci_cd", "ECI");
    loadInput81Map.put("mer_prvd_mcc_cd", "MCC");
    loadInput81Map.put("cr_deny_rsn_cd", "DN");
    loadInput81Map.put("frd_deny_rsn_cd", "FRD");
    loadInput81Map.put("two_dgt_aprv_cde", "32");
    loadInput81Map.put("six_dgt_aprv_cde", "104962");
    loadInput81Map.put("auth_pref_am", new BigDecimal("0.00"));
    loadInput81Map.put("auth_mtch_in", "");
    loadInput81Map.put("uuid_id", UUID.randomUUID());

    loadInput82Map.put("trans_id", "001200000000201");
    loadInput82Map.put("cm_15", "371100000000722");
    loadInput82Map.put("aprv_deny_cd", "A");
    loadInput82Map.put("auth_loc_am", new BigDecimal("90.00"));
    loadInput82Map.put("auth_usd_am", new BigDecimal("90.00"));
    loadInput82Map.put("auth_se_no", "9429531213");
    loadInput82Map.put("auth_ts", "071818 000000");
    loadInput82Map.put("card_2dac_cache_key", "371000000000202|32|A");
    loadInput82Map.put("card_6dac_cache_key", "371000000000202|104962|A");
    loadInput82Map.put("cas_pkey", "001000000000202");
    loadInput82Map.put("sourceid", "SUBM");
    loadInput82Map.put("auth_loc_am_curr_cd", "CAD");
    loadInput82Map.put("voice_auth_in", "V");
    loadInput82Map.put("pos_da_cd", "POS");
    loadInput82Map.put("eci_cd", "ECI");
    loadInput82Map.put("mer_prvd_mcc_cd", "MCC");
    loadInput82Map.put("cr_deny_rsn_cd", "DN");
    loadInput82Map.put("frd_deny_rsn_cd", "FRD");
    loadInput82Map.put("two_dgt_aprv_cde", "32");
    loadInput82Map.put("six_dgt_aprv_cde", "104962");
    loadInput82Map.put("auth_pref_am", new BigDecimal("0.00"));
    loadInput82Map.put("auth_mtch_in", "");
    loadInput82Map.put("uuid_id", UUID.randomUUID());

    loadInput83Map.put("trans_id", "001300000000201");
    loadInput83Map.put("cm_15", "371100000000722");
    loadInput83Map.put("aprv_deny_cd", "A");
    loadInput83Map.put("auth_loc_am", new BigDecimal("50.00"));
    loadInput83Map.put("auth_usd_am", new BigDecimal("50.00"));
    loadInput83Map.put("auth_se_no", "9429531213");
    loadInput83Map.put("auth_ts", "071818 000000");
    loadInput83Map.put("card_2dac_cache_key", "371000000000202|32|A");
    loadInput83Map.put("card_6dac_cache_key", "371000000000202|104962|A");
    loadInput83Map.put("cas_pkey", "001000000000202");
    loadInput83Map.put("sourceid", "SUBM");
    loadInput83Map.put("auth_loc_am_curr_cd", "CAD");
    loadInput83Map.put("voice_auth_in", "V");
    loadInput83Map.put("pos_da_cd", "POS");
    loadInput83Map.put("eci_cd", "ECI");
    loadInput83Map.put("mer_prvd_mcc_cd", "MCC");
    loadInput83Map.put("cr_deny_rsn_cd", "DN");
    loadInput83Map.put("frd_deny_rsn_cd", "FRD");
    loadInput83Map.put("two_dgt_aprv_cde", "32");
    loadInput83Map.put("six_dgt_aprv_cde", "104962");
    loadInput83Map.put("auth_pref_am", new BigDecimal("0.00"));
    loadInput83Map.put("auth_mtch_in", "");
    loadInput83Map.put("uuid_id", UUID.randomUUID());

    loadInput9Map.put("trans_id", "000000000000000");
    loadInput9Map.put("cm_15", "372200000000516");
    loadInput9Map.put("aprv_deny_cd", "A");
    loadInput9Map.put("auth_loc_am", new BigDecimal("250.11"));
    loadInput9Map.put("auth_usd_am", new BigDecimal("250.11"));
    loadInput9Map.put("auth_se_no", "9429531213");
    loadInput9Map.put("auth_ts", "101112 000000");
    loadInput9Map.put("card_2dac_cache_key", "371000000000202|00|A");
    loadInput9Map.put("card_6dac_cache_key", "371000000000202|000000|A");
    loadInput9Map.put("cas_pkey", "001000000000202");
    loadInput9Map.put("sourceid", "SUBM");
    loadInput9Map.put("auth_loc_am_curr_cd", "CAD");
    loadInput9Map.put("voice_auth_in", "V");
    loadInput9Map.put("pos_da_cd", "POS");
    loadInput9Map.put("eci_cd", "ECI");
    loadInput9Map.put("mer_prvd_mcc_cd", "MCC");
    loadInput9Map.put("cr_deny_rsn_cd", "DN");
    loadInput9Map.put("frd_deny_rsn_cd", "FRD");
    loadInput9Map.put("two_dgt_aprv_cde", "00");
    loadInput9Map.put("six_dgt_aprv_cde", "000000");
    loadInput9Map.put("auth_pref_am", new BigDecimal("0.00"));
    loadInput9Map.put("auth_mtch_in", "");
    loadInput9Map.put("uuid_id", UUID.randomUUID());

    loadInput11Map.put("trans_id", "000000000000000");
    loadInput11Map.put("cm_15", "372200000000221");
    loadInput11Map.put("aprv_deny_cd", "A");
    loadInput11Map.put("auth_loc_am", new BigDecimal("1000"));
    loadInput11Map.put("auth_usd_am", new BigDecimal("1000"));
    loadInput11Map.put("auth_se_no", "9429531213");
    loadInput11Map.put("auth_ts", "111018 000000");
    loadInput11Map.put("card_2dac_cache_key", "371000000000202|00|A");
    loadInput11Map.put("card_6dac_cache_key", "371000000000202|000000|A");
    loadInput11Map.put("cas_pkey", "001000000000202");
    loadInput11Map.put("sourceid", "SUBM");
    loadInput11Map.put("auth_loc_am_curr_cd", "CAD");
    loadInput11Map.put("voice_auth_in", "V");
    loadInput11Map.put("pos_da_cd", "POS");
    loadInput11Map.put("eci_cd", "ECI");
    loadInput11Map.put("mer_prvd_mcc_cd", "MCC");
    loadInput11Map.put("cr_deny_rsn_cd", "DN");
    loadInput11Map.put("frd_deny_rsn_cd", "FRD");
    loadInput11Map.put("two_dgt_aprv_cde", "00");
    loadInput11Map.put("six_dgt_aprv_cde", "000000");
    loadInput11Map.put("auth_pref_am", new BigDecimal("0.00"));
    loadInput11Map.put("auth_mtch_in", "");
    loadInput11Map.put("uuid_id", UUID.randomUUID());

    loadInput2WithRTFData.put("trans_id", "005608580204571");
    loadInput2WithRTFData.put("cm_15", "376661014351230");
    loadInput2WithRTFData.put("aprv_deny_cd", "D");
    loadInput2WithRTFData.put("auth_loc_am", new BigDecimal("363.21"));
    loadInput2WithRTFData.put("auth_usd_am", new BigDecimal("363.21"));
    loadInput2WithRTFData.put("auth_se_no", "6318724044");
    loadInput2WithRTFData.put("auth_ts", "020219 094834");
    loadInput2WithRTFData.put("card_2dac_cache_key", "376661014351230|D");
    loadInput2WithRTFData.put("card_6dac_cache_key", "376661014351230|D");
    loadInput2WithRTFData.put("cas_pkey", "005608580204571");
    loadInput2WithRTFData.put("sourceid", "SUBM");
    loadInput2WithRTFData.put("auth_loc_am_curr_cd", "USD");
    loadInput2WithRTFData.put("voice_auth_in", "V");
    loadInput2WithRTFData.put("pos_da_cd", "POS");
    loadInput2WithRTFData.put("eci_cd", "ECI");
    loadInput2WithRTFData.put("mer_prvd_mcc_cd", "MCC");
    loadInput2WithRTFData.put("cr_deny_rsn_cd", "DN");
    loadInput2WithRTFData.put("frd_deny_rsn_cd", "FRD");
    loadInput2WithRTFData.put("two_dgt_aprv_cde", "DA");
    loadInput2WithRTFData.put("six_dgt_aprv_cde", "DAC98");
    loadInput2WithRTFData.put("auth_pref_am", new BigDecimal("0.00"));
    loadInput2WithRTFData.put("auth_mtch_in", "");
    loadInput2WithRTFData.put("uuid_id", UUID.randomUUID());
  }

  public void setDataForCache(String ramTier) {
    HashMap<String, Object> dataMap = null;
    SimpleDateFormat CAS_AUTHORIZATION_DATE_FORMAT = new SimpleDateFormat("MMddyy HHmmss");

    Session session = CassandraConnectionFactory.getInstance().getCassandraSession();

    switch (ramTier) {
      case "1":
        dataMap = new HashMap<String, Object>(loadInput1Map);
        break;
      case "2":
        dataMap = new HashMap<String, Object>(loadInput2Map);
        break;
      case "Tier_2_localAmount":
        dataMap = new HashMap<String, Object>(loadInput2LocalAmountMap);
        break;
      case "3a":
        dataMap = new HashMap<String, Object>(loadInput3aMap);
        break;
      case "Tier_3a_localAmount":
        dataMap = new HashMap<String, Object>(loadInput3aLocalAmountMap);
        break;
      case "3b1":
        dataMap = new HashMap<String, Object>(loadInput3b1Map);
        break;
      case "3b2":
        dataMap = new HashMap<String, Object>(loadInput3b2Map);
        break;
      case "3c1":
        dataMap = new HashMap<String, Object>(loadInput3c1Map);
        break;
      case "3c2":
        dataMap = new HashMap<String, Object>(loadInput3c2Map);
        break;
      case "Tier_3c_localAmount":
        dataMap = new HashMap<String, Object>(loadInput3cLocalAmountMap);
        break;
      case "4":
        dataMap = new HashMap<String, Object>(loadInput4Map);
        break;
      case "Tier_4_localAmount":
        dataMap = new HashMap<String, Object>(loadInput4LocalAmountMap);
        break;
      case "5":
        dataMap = new HashMap<String, Object>(loadInput5Map);
        break;
      case "Tier_5_localAmount":
        dataMap = new HashMap<String, Object>(loadInput5LocalAmountMap);
        break;
      case "6":
        dataMap = new HashMap<String, Object>(loadInput6Map);
        break;
      case "Tier_6_localAmount":
        dataMap = new HashMap<String, Object>(loadInput6LocalAmountMap);
        break;
      case "7":
        dataMap = new HashMap<String, Object>(loadInput7Map);
        break;
      case "Tier_7_localAmount":
        dataMap = new HashMap<String, Object>(loadInput7LocalAmountMap);
        break;
      case "81":
        dataMap = new HashMap<String, Object>(loadInput81Map);
        break;
      case "82":
        dataMap = new HashMap<String, Object>(loadInput82Map);
        break;
      case "83":
        dataMap = new HashMap<String, Object>(loadInput83Map);
        break;
      case "9":
        dataMap = new HashMap<String, Object>(loadInput9Map);
        break;
      case "11":
        dataMap = new HashMap<String, Object>(loadInput11Map);
        break;
      case "loadInput2WithRTFData":
        dataMap = new HashMap<String, Object>(loadInput2WithRTFData);
        break;
    }

    try {
      insertAuthQry = session.prepare(insert_Auth_Qry);
      insertAuthCacheByTransIDPS = session.prepare(insertAuthCache_ByTransId_Qry);
      insertAuthCacheBy2DACPS = session.prepare(insertAuthCache_ByDac2_Qry);
      insertAuthCacheBy6DACPS = session.prepare(insertAuthCache_ByDac6_Qry);
      insertAuthCacheByCardAndSe = session.prepare(insertAuthCache_ByCardAndSe_Qry);

      Date date = null;
      LocalTime time = null;

      CAS_AUTHORIZATION_DATE_FORMAT.setLenient(false);
      date = CAS_AUTHORIZATION_DATE_FORMAT.parse(dataMap.get("auth_ts").toString());
      String authTime = dataMap.get("auth_ts").toString();
      String authDate = authTime.substring(0, authTime.indexOf(" "));

      LocalDate localDate = null;

      try {
        localDate = localDate.parse(authDate, DateTimeFormatter.ofPattern("MMddyy"));
      } catch (Exception e) {
        localDate = LocalDate.parse("1900-01-01");
      }

      try {
        time = LocalTime.parse(authTime, DateTimeFormatter.ofPattern("MMddyy HHmmss"));
      } catch (Exception e) {
        time = LocalTime.parse("00:00");
      }

      insertAuth =
          insertAuthQry.bind(
              dataMap.get("trans_id"),
              dataMap.get("cm_15"),
              dataMap.get("aprv_deny_cd"),
              dataMap.get("auth2dac_appr_cd"),
              dataMap.get("auth6dac_appr_cd"),
              dataMap.get("auth_am_in_local_curr"),
              dataMap.get("auth_am_in_usd"),
              dataMap.get("auth_curr"),
              localDate,
              dataMap.get("cas_pkey"),
              dataMap.get("frd_loss_prbl_score"),
              dataMap.get("frgn_sepnd_in"),
              dataMap.get("lwrcw_7dlog_tx"),
              dataMap.get("mag_swipe_in"),
              dataMap.get("mcc"),
              dataMap.get("se10"),
              dataMap.get("se_ctry_cd"),
              dataMap.get("se_indus_ctgy_cd"),
              dataMap.get("se_type_cd"),
              time,
              dataMap.get("sourceid"));
      session.execute(insertAuth);

      insertAuth =
          insertAuthCacheByTransIDPS.bind(
              dataMap.get("trans_id"),
              dataMap.get("cm_15"),
              dataMap.get("aprv_deny_cd"),
              dataMap.get("auth_loc_am"),
              dataMap.get("auth_usd_am"),
              dataMap.get("auth_se_no"),
              date,
              dataMap.get("card_2dac_cache_key"),
              dataMap.get("card_6dac_cache_key"),
              dataMap.get("cas_pkey"),
              "CAS",
              dataMap.get("auth_loc_am_curr_cd"),
              dataMap.get("voice_auth_in"),
              dataMap.get("pos_da_cd"),
              dataMap.get("eci_cd"),
              dataMap.get("mer_prvd_mcc_cd"),
              dataMap.get("cr_deny_rsn_cd"),
              dataMap.get("frd_deny_rsn_cd"));
      session.execute(insertAuth);

      insertAuth =
          insertAuthCacheByCardAndSe.bind(
              dataMap.get("trans_id"),
              dataMap.get("cm_15"),
              dataMap.get("aprv_deny_cd"),
              dataMap.get("auth_loc_am"),
              dataMap.get("auth_usd_am"),
              dataMap.get("auth_se_no"),
              date,
              dataMap.get("card_2dac_cache_key"),
              dataMap.get("card_6dac_cache_key"),
              dataMap.get("cas_pkey"),
              "CAS",
              dataMap.get("auth_loc_am_curr_cd"),
              dataMap.get("voice_auth_in"),
              dataMap.get("pos_da_cd"),
              dataMap.get("eci_cd"),
              dataMap.get("mer_prvd_mcc_cd"),
              dataMap.get("cr_deny_rsn_cd"),
              dataMap.get("frd_deny_rsn_cd"),
              dataMap.get("auth_mtch_in"),
              dataMap.get("uuid_id"));

      session.execute(insertAuth);

      insertAuth =
          insertAuthCacheBy2DACPS.bind(
              dataMap.get("cm_15"),
              dataMap.get("two_dgt_aprv_cde"),
              dataMap.get("aprv_deny_cd"),
              dataMap.get("cas_pkey"),
              dataMap.get("auth_se_no"),
              dataMap.get("auth_usd_am"),
              dataMap.get("auth_loc_am"),
              dataMap.get("card_6dac_cache_key"),
              dataMap.get("trans_id"),
              date,
              dataMap.get("auth_pref_am"));
      session.execute(insertAuth);

      insertAuth =
          insertAuthCacheBy6DACPS.bind(
              dataMap.get("cm_15"),
              dataMap.get("six_dgt_aprv_cde"),
              dataMap.get("aprv_deny_cd"),
              dataMap.get("cas_pkey"),
              dataMap.get("auth_se_no"),
              dataMap.get("auth_usd_am"),
              dataMap.get("auth_loc_am"),
              dataMap.get("card_2dac_cache_key"),
              dataMap.get("trans_id"),
              date,
              dataMap.get("auth_pref_am"));
      session.execute(insertAuth);

    } catch (Exception ex) {
      System.out.println("Exception occurred " + ex.getMessage());
    }
  }
}
