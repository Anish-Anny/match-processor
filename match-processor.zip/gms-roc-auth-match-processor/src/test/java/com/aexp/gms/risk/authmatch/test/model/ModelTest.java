package com.aexp.gms.risk.authmatch.test.model;

import static org.junit.Assert.*;

import com.aexp.gms.risk.authmatch.model.CasAuthTransIdCardCacheBean;
import org.junit.Test;

public class ModelTest {

  @Test
  public void Should_Pass_All_Pojo_Tests_Using_All_Testers() {
    // given
    final Class<?> classUnderTest = CasAuthTransIdCardCacheBean.class;

    // when

    // then
  }
}
