package com.aexp.gms.risk.authmatch.test.cassandra;

import com.aexp.gmnt.imc.vo.SECharacteristics501Data;
import com.aexp.gms.risk.authmatch.dao.IgniteProvider;
import com.aexp.gms.risk.authmatch.dao.SeChar501Dao;
import com.aexp.gms.risk.authmatch.dao.SeChar501IgniteImpl;
import com.aexp.gms.risk.authmatch.exception.AuthMatchSystemException;
import com.aexp.gms.risk.authmatch.model.RocMatchRequest;
import com.aexp.gms.risk.authmatch.model.SubmissionMatchResponse;
import com.aexp.gms.risk.authmatch.rest.client.AuthLoadClient;
import com.aexp.gms.risk.authmatch.rtf.RtfConfiguration;
import com.aexp.gms.risk.authmatch.services.AuthMatchCassBL;
import com.aexp.gms.risk.authmatch.test.dao.AuthMatchDAOTest;
import com.aexp.gms.risk.authmatch.test.services.TestData;
import com.aexp.gms.risk.authmatch.util.PropertyLoaderUtils;
import com.aexp.gms.risk.data.AuthMatchDatabaseDAOImpl;
import com.aexp.gms.risk.data.CassandraMatchResultDAOImpl;
import com.aexp.gms.risk.data.RocAuthSeSubmissionHistoryDAOImpl;
import com.aexp.rtf.client.RtfClient;
import com.datastax.driver.core.*;
import com.datastax.shaded.codehaus.jackson.JsonProcessingException;
import com.datastax.shaded.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.airlift.command.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang.StringUtils;
import org.apache.ignite.Ignite;
import org.apache.ignite.Ignition;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CassandraMatchResultDAOTest {
  RtfClient authLoadClientBean = new RtfConfiguration().rtfClient("e1");
  Session session = null;
  private static AuthMatchCassBL matchCass;
  private static AuthMatchDatabaseDAOImpl authMatchDAOImpl;
  CassandraTestData testData = new CassandraTestData();

  @BeforeClass
  public static void testSetupMock() throws AuthMatchSystemException {
    System.setProperty("env", "e0");
    System.setProperty("spring.profiles.active", "e0");
    System.setProperty("data-center", "test");
    System.setProperty("AIM_ID", "41140955");
    System.out.println("Starting Ignite server");
    new ClassPathXmlApplicationContext("test-authmatch-processor-spring-config.xml");
    authMatchDAOImpl = new AuthMatchDatabaseDAOImpl();
    authMatchDAOImpl.updateDataForLocalCassandra();
    RocAuthSeSubmissionHistoryDAOImpl rocAuthSeSubmissionHistoryDAO =
        new RocAuthSeSubmissionHistoryDAOImpl();
    matchCass = new AuthMatchCassBL(authMatchDAOImpl, rocAuthSeSubmissionHistoryDAO);
    CassandraTestData.testSetupMock();
  }

  @Test
  public void testMatchLogic_tier_1() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      testData.setDataForCache("1");
      rocMatchRequest =
          (RocMatchRequest) mapper.readValue(TestData.matchInput1, RocMatchRequest.class);
      populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = matchCass.process(rocMatchRequest);
      System.out.println("Match tier 1 : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T01"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("2"));

    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_1_with_tid() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      testData.setDataForCache("1");
      rocMatchRequest =
          (RocMatchRequest)
              mapper.readValue(TestData.matchInput2_localAmount, RocMatchRequest.class);
      populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = matchCass.process(rocMatchRequest);
      CassandraMatchResultDAOImpl cassandraMatchResultDAOImpl = new CassandraMatchResultDAOImpl();
      cassandraMatchResultDAOImpl.insertMatchResult(
          rocMatchRequest, submissionMatchResponse, false, null);

      // Connect to database and verify tid is populated in the table ram_rslt_by_arn

      String netTranId =
          authMatchDAOImpl.selectNtwktidByRocarn(rocMatchRequest.getRocAcquirerReferenceNumber());
      Assert.assertEquals(rocMatchRequest.getRocNetworkGeneratedTID(), netTranId);

    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testInsertSeCountryCode() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      testData.setDataForCache("1");
      rocMatchRequest =
          (RocMatchRequest) mapper.readValue(TestData.matchInput10, RocMatchRequest.class);
      populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = matchCass.process(rocMatchRequest);

      SECharacteristics501Data SECharacteristics501DataRocRequest = new SECharacteristics501Data();

      IgniteProvider authMatchIgniteProvider = new IgniteProvider(false);
      String igniteConfigFile =
          PropertyLoaderUtils.resolveFileName("imc-ignite-client-config-${env}.xml");
      Ignite clientIgnite =
          Ignition.getOrStart(
              Ignition.loadSpringBean(
                  AuthMatchDAOTest.class.getClassLoader().getResourceAsStream(igniteConfigFile),
                  "ignite.cfg"));
      authMatchIgniteProvider.setIgnite(clientIgnite);
      SeChar501Dao seChar501Ignite = new SeChar501IgniteImpl(authMatchIgniteProvider);

      SECharacteristics501DataRocRequest.setPhysAdCtryCd("IN");
      seChar501Ignite.put(rocMatchRequest.getRocSENumber(), SECharacteristics501DataRocRequest);

      CassandraMatchResultDAOImpl cassandraMatchResultDAOImpl = new CassandraMatchResultDAOImpl();
      String seCountryCodeFromCache =
          seChar501Ignite.get(rocMatchRequest.getRocSENumber()).getPhysAdCtryCd();
      cassandraMatchResultDAOImpl.insertMatchResult(
          rocMatchRequest, submissionMatchResponse, false, seCountryCodeFromCache);

      // Connect to database and verify se country code is populated in the table ram_rslt_by_arn
      String seCountryCode =
          authMatchDAOImpl.selectSeCountryCodeByRocarn(
              rocMatchRequest.getRocAcquirerReferenceNumber());
      Assert.assertEquals(SECharacteristics501DataRocRequest.getPhysAdCtryCd(), seCountryCode);

    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_1_previousRecords() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      SubmissionMatchResponse submissionMatchResponse2 = null;
      testData.setDataForCache("1");
      rocMatchRequest =
          (RocMatchRequest) mapper.readValue(TestData.matchInput1, RocMatchRequest.class);
      populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = matchCass.process(rocMatchRequest);
      CassandraMatchResultDAOImpl cassandraMatchResultDAOImpl = new CassandraMatchResultDAOImpl();
      cassandraMatchResultDAOImpl.insertMatchResult(
          rocMatchRequest, submissionMatchResponse, false, null);

      System.out.println(
          "Match tier 1 with previous records : " + submissionMatchResponse.getRamTier());
      populateEligibleMatchTiersList(rocMatchRequest);
      submissionMatchResponse2 =
          matchCass.matchByPreviousRecords(rocMatchRequest, submissionMatchResponse2);
      Assert.assertTrue(
          submissionMatchResponse2.getResultRemarks().contains("Match by previous records"));

    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testCallAuthLoadApi()
      throws AuthMatchSystemException, JsonMappingException, JsonProcessingException,
          ParseException, com.fasterxml.jackson.databind.JsonMappingException,
          com.fasterxml.jackson.core.JsonProcessingException {
    SimpleDateFormat CAS_AUTHORIZATION_DATE_FORMAT = new SimpleDateFormat("MMddyy HHmmss");

    ObjectMapper mapper = new ObjectMapper();
    mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
    RocMatchRequest rocMatchRequest = null;
    RocMatchRequest rocMatchRequest2 = null;
    SubmissionMatchResponse submissionMatchResponse2 = null;
    // SubmissionMatchResponse submissionMatchResponse3 = null;
    testData.setDataForCache("loadInput2WithRTFData");

    rocMatchRequest =
        (RocMatchRequest) mapper.readValue(TestData.loadInput2WithRTFData_1, RocMatchRequest.class);
    rocMatchRequest2 =
        (RocMatchRequest) mapper.readValue(TestData.loadInput2WithRTFData_2, RocMatchRequest.class);

    populateEligibleMatchTiersList(rocMatchRequest);
    CassandraMatchResultDAOImpl cassandraMatchResultDAO = new CassandraMatchResultDAOImpl();

    SubmissionMatchResponse submissionMatchResponse = matchCass.process(rocMatchRequest);

    CassandraMatchResultDAOImpl cassandraMatchResultDAOImpl = new CassandraMatchResultDAOImpl();
    cassandraMatchResultDAOImpl.insertMatchResult(
        rocMatchRequest, submissionMatchResponse, false, null);

    /*populateEligibleMatchTiersList(rocMatchRequest2);
    submissionMatchResponse2 = matchCass.process(rocMatchRequest2);*/

    submissionMatchResponse2 =
        matchCass.matchByPreviousRecords(rocMatchRequest, submissionMatchResponse);

    AuthLoadClient authLoadCLient =
        new AuthLoadClient(authLoadClientBean, "/gmsrisk/authorizations/ipc1");
    submissionMatchResponse2 =
        authLoadCLient.callAuthLoadApi(
            cassandraMatchResultDAO,
            submissionMatchResponse2,
            rocMatchRequest.getRocAcquirerReferenceNumber());
    Assert.assertTrue(submissionMatchResponse2.isReversed());
  }

  @Test
  public void testMatchLogic_tier_2() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      testData.setDataForCache("2");
      rocMatchRequest =
          (RocMatchRequest) mapper.readValue(TestData.matchInput2, RocMatchRequest.class);
      populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = matchCass.process(rocMatchRequest);
      System.out.println(
          "Match tier 2 : "
              + submissionMatchResponse.getRamTier()
              + " : "
              + submissionMatchResponse.getResultRemarks());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T02"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));

    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_2_withLocalAmount() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      testData.setDataForCache("Tier_2_localAmount");
      rocMatchRequest =
          (RocMatchRequest)
              mapper.readValue(TestData.matchInput2_localAmount, RocMatchRequest.class);
      populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = matchCass.process(rocMatchRequest);
      System.out.println(
          "Local Amount Match tier 2 : "
              + submissionMatchResponse.getRamTier()
              + " : "
              + submissionMatchResponse.getResultRemarks());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T02"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));

    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_3a() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      testData.setDataForCache("3a");
      rocMatchRequest =
          (RocMatchRequest) mapper.readValue(TestData.matchInput3a, RocMatchRequest.class);
      populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = matchCass.process(rocMatchRequest);
      System.out.println("Match tier 3a : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T03"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));

    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_3a_withLocalAmount() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      testData.setDataForCache("Tier_3a_localAmount");
      rocMatchRequest =
          (RocMatchRequest)
              mapper.readValue(TestData.matchInput3a_localAmount, RocMatchRequest.class);
      populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = matchCass.process(rocMatchRequest);
      System.out.println(
          "Local Amount Match tier 3a : "
              + submissionMatchResponse.getRamTier()
              + " : "
              + submissionMatchResponse.getResultRemarks());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T03"));

    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_3b() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      testData.setDataForCache("3b1");
      testData.setDataForCache("3b2");
      rocMatchRequest =
          (RocMatchRequest) mapper.readValue(TestData.matchInput3b, RocMatchRequest.class);
      populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = matchCass.process(rocMatchRequest);
      System.out.println("Match tier 3b : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T03"));

    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_3c1() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      testData.setDataForCache("3c1");
      rocMatchRequest =
          (RocMatchRequest) mapper.readValue(TestData.matchInput3c_1, RocMatchRequest.class);
      populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = matchCass.process(rocMatchRequest);
      System.out.println("Match tier 3c1 : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T03"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));

    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_3c2() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      testData.setDataForCache("3c2");
      rocMatchRequest =
          (RocMatchRequest) mapper.readValue(TestData.matchInput3c_2, RocMatchRequest.class);
      populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = matchCass.process(rocMatchRequest);
      System.out.println("Match tier 3c2 : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T03"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));

    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_3c_withLocalAmount() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      testData.setDataForCache("Tier_3c_localAmount");
      rocMatchRequest =
          (RocMatchRequest)
              mapper.readValue(TestData.matchInput3c_localAmount, RocMatchRequest.class);
      populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = matchCass.process(rocMatchRequest);
      System.out.println(
          "Local Amount Match tier 3c : "
              + submissionMatchResponse.getRamTier()
              + " : "
              + submissionMatchResponse.getResultRemarks());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T03"));

    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_4() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      testData.setDataForCache("4");
      rocMatchRequest =
          (RocMatchRequest) mapper.readValue(TestData.matchInput4, RocMatchRequest.class);
      populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = matchCass.process(rocMatchRequest);
      System.out.println("Match tier 4 : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T04"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));

    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_4_withLocalAmount() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      testData.setDataForCache("Tier_4_localAmount");
      rocMatchRequest =
          (RocMatchRequest)
              mapper.readValue(TestData.matchInput4_localAmount, RocMatchRequest.class);
      populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = matchCass.process(rocMatchRequest);
      System.out.println(
          "Local Amount Match tier 4 : "
              + submissionMatchResponse.getRamTier()
              + " : "
              + submissionMatchResponse.getResultRemarks());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T04"));

    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_5() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      testData.setDataForCache("5");
      rocMatchRequest =
          (RocMatchRequest) mapper.readValue(TestData.matchInput5, RocMatchRequest.class);
      populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = matchCass.process(rocMatchRequest);
      System.out.println("Match tier 5 : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T05"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));

    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_5_withLocalAmount() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      testData.setDataForCache("Tier_5_localAmount");
      rocMatchRequest =
          (RocMatchRequest)
              mapper.readValue(TestData.matchInput5_localAmount, RocMatchRequest.class);
      populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = matchCass.process(rocMatchRequest);
      System.out.println(
          "Local Amount Match tier 5 : "
              + submissionMatchResponse.getRamTier()
              + " : "
              + submissionMatchResponse.getResultRemarks());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T05"));

    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_6() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      testData.setDataForCache("6");
      rocMatchRequest =
          (RocMatchRequest) mapper.readValue(TestData.matchInput6, RocMatchRequest.class);
      populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = matchCass.process(rocMatchRequest);
      System.out.println("Match tier 6 : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T06"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));

    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_6_withLocalAmount() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      testData.setDataForCache("Tier_6_localAmount");
      rocMatchRequest =
          (RocMatchRequest)
              mapper.readValue(TestData.matchInput6_localAmount, RocMatchRequest.class);
      populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = matchCass.process(rocMatchRequest);
      System.out.println(
          "Local Amount Match tier 6 : "
              + submissionMatchResponse.getRamTier()
              + " : "
              + submissionMatchResponse.getResultRemarks());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T06"));

    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_7() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      testData.setDataForCache("7");
      rocMatchRequest =
          (RocMatchRequest) mapper.readValue(TestData.matchInput7, RocMatchRequest.class);
      populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = matchCass.process(rocMatchRequest);
      System.out.println("Match tier 7 : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T07"));
      Assert.assertTrue(submissionMatchResponse.getRamIndicator().equals("1"));

    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_7_withLocalAmount() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      testData.setDataForCache("Tier_7_localAmount");
      rocMatchRequest =
          (RocMatchRequest)
              mapper.readValue(TestData.matchInput7_localAmount, RocMatchRequest.class);
      populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = matchCass.process(rocMatchRequest);
      System.out.println(
          "Local Amount Match tier 7 : "
              + submissionMatchResponse.getRamTier()
              + " : "
              + submissionMatchResponse.getResultRemarks());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T07"));

    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_8() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      testData.setDataForCache("81");
      testData.setDataForCache("82");
      testData.setDataForCache("83");
      rocMatchRequest =
          (RocMatchRequest) mapper.readValue(TestData.matchInput8, RocMatchRequest.class);
      populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = matchCass.process(rocMatchRequest);
      System.out.println("Match tier 8 : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T08"));

    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_9() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      testData.setDataForCache("9");
      rocMatchRequest =
          (RocMatchRequest) mapper.readValue(TestData.matchInput9, RocMatchRequest.class);
      populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = matchCass.process(rocMatchRequest);
      System.out.println("Match tier 9 : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T09"));

    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_11() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      testData.setDataForCache("11");
      rocMatchRequest =
          (RocMatchRequest) mapper.readValue(TestData.matchInput11, RocMatchRequest.class);
      populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = matchCass.process(rocMatchRequest);
      System.out.println("Match tier 11 : " + submissionMatchResponse.getRamTier());
      Assert.assertTrue(submissionMatchResponse.getRamTier().equals("T11"));

    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  @Test
  public void testMatchLogic_tier_11_Tid() {
    try {
      ObjectMapper mapper = new ObjectMapper();
      mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
      RocMatchRequest rocMatchRequest = null;
      testData.setDataForCache("11");
      rocMatchRequest =
          (RocMatchRequest) mapper.readValue(TestData.matchInput11, RocMatchRequest.class);
      populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse = matchCass.process(rocMatchRequest);
      System.out.println("Match tier 11 with tid: " + submissionMatchResponse.getRamTier());
      populateEligibleMatchTiersList(rocMatchRequest);
      SubmissionMatchResponse submissionMatchResponse2 = matchCass.process(rocMatchRequest);
      Assert.assertNotNull(submissionMatchResponse2.getTransactionId());
    } catch (Exception e) {
      System.out.println("Exception " + e);
    }
  }

  public void populateEligibleMatchTiersList(RocMatchRequest rocMatchRequest) {
    List<String> elibigleTiersList = new ArrayList<String>();
    String transactionId = rocMatchRequest.getRocAuthorizationTransactionId();
    String authDAC = rocMatchRequest.getRocAuthDAC();

    if (isTransactionIdContainAllZeroOrSpaces(transactionId)
        && isAuthDacContainAllZeroOrSpaces(authDAC)) {
      elibigleTiersList.add("T09");
      elibigleTiersList.add("T11");
    } else if (!(isTransactionIdContainAllZeroOrSpaces(transactionId))
        && (isAuthDacContainAllZeroOrSpaces(authDAC))) {
      elibigleTiersList.add("T01");
      elibigleTiersList.add("T02");
      elibigleTiersList.add("T03");
      elibigleTiersList.add("T08");
    } else if (isTransactionIdContainAllZeroOrSpaces(transactionId)
        && (!(isAuthDacContainAllZeroOrSpaces(authDAC)))) {
      elibigleTiersList.add("T04");
      elibigleTiersList.add("T05");
      elibigleTiersList.add("T06");
      elibigleTiersList.add("T07");
    } else {
      elibigleTiersList.add("T01");
      elibigleTiersList.add("T02");
      elibigleTiersList.add("T03");
      elibigleTiersList.add("T04");
      elibigleTiersList.add("T05");
      elibigleTiersList.add("T06");
      elibigleTiersList.add("T07");
      elibigleTiersList.add("T08");
    }
    rocMatchRequest.setEligibleTiersList(elibigleTiersList);
  }

  public boolean isTransactionIdContainAllZeroOrSpaces(String transactionId) {
    try {
      Long transactionIdLong = 0L;
      transactionIdLong = Long.parseLong(StringUtils.trim(transactionId));
      if (StringUtils.equals("000000000000000", transactionId)
          || StringUtils.equals("", StringUtils.trim(transactionId))
          || transactionIdLong == 0) return true;
    } catch (NumberFormatException e) {

    }
    return false;
  }

  public boolean isAuthDacContainAllZeroOrSpaces(String authDAC) {
    try {
      Integer authDACInteger = 0;
      authDACInteger = Integer.parseInt(StringUtils.trim(authDAC));
      if (StringUtils.equals("000000", authDAC)
          || StringUtils.equals("00", authDAC)
          || StringUtils.equals("", StringUtils.trim(authDAC))
          || authDACInteger == 0) return true;
    } catch (NumberFormatException e) {

    }
    return false;
  }
}
