package com.aexp.gms.risk.authmatch.test.dao;

import com.aexp.gms.risk.authmatch.util.PropertyLoaderUtils;
import org.apache.ignite.Ignite;
import org.apache.ignite.Ignition;

public class IgniteServerNode {
  Ignite ignite = null;

  public IgniteServerNode(String serverXml) {
    System.out.println("starting server node xml=" + serverXml);
    String igniteConfigFile = PropertyLoaderUtils.resolveFileName(serverXml);

    try {
      ignite =
          Ignition.start(this.getClass().getClassLoader().getResourceAsStream(igniteConfigFile));
    } catch (Exception e) {
      System.out.println("caught exception starting ignite test node..." + e);
    }
  }

  public Ignite getIgnite() {
    return this.ignite;
  }

  public static void main(String[] args) {
    IgniteServerNode node = new IgniteServerNode("ignite-config-server.xml");
  }
}
