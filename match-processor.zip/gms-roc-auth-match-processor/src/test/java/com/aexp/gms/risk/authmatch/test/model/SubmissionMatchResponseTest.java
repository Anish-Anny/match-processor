package com.aexp.gms.risk.authmatch.test.model;

import com.aexp.gms.risk.authmatch.model.SubmissionMatchResponse;
import nl.jqno.equalsverifier.EqualsVerifier;
import nl.jqno.equalsverifier.Warning;
import org.junit.Test;

public class SubmissionMatchResponseTest {
  @Test
  public void testEqualsAndHashCode() {
    EqualsVerifier.forClass(SubmissionMatchResponse.class)
        .suppress(Warning.STRICT_INHERITANCE, Warning.NONFINAL_FIELDS)
        .verify();
  }
}
