package com.aexp.gms.risk.authmatch.services;

import com.aexp.gms.risk.authmatch.exception.AuthMatchSystemException;
import com.aexp.gms.risk.authmatch.model.RocMatchRequest;
import com.aexp.gms.risk.authmatch.model.SubmissionMatchResponse;

public interface AuthMatchService {
  public void getMessages();

  public void validateAuthMatchBean();

  public SubmissionMatchResponse matchRequest(RocMatchRequest rocMatchRequest);

  public SubmissionMatchResponse reversalRequest(RocMatchRequest rocMatchRequest);

  public void broadCastCacheVersion();

  public boolean checkIgniteHealth();

  public void refreshCountDownLatch(String latchName);

  public void processCacheUpdate(String request, String rtfClientPath, String axCorrelationId)
      throws AuthMatchSystemException;
}
