package com.aexp.gms.risk.authmatch.rest.client;

import com.aexp.gms.risk.authmatch.model.AuthLoadRequestMapper;
import com.aexp.gms.risk.authmatch.model.SubmissionMatchResponse;
import com.aexp.gms.risk.data.CassandraMatchResultDAOImpl;
import com.aexp.rtf.client.RtfClient;
import com.aexp.rtf.client.RtfRequest;
import com.aexp.rtf.client.RtfResponse;
import java.sql.Timestamp;
import java.util.Date;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

public class AuthLoadClient {

  private final Logger log = LoggerFactory.getLogger(AuthLoadClient.class);

  private RtfClient rtfClient;

  private String rtfEventType;

  public AuthLoadClient(
      @Autowired RtfClient authLoadClientBean,
      @Value("${authload.RTF_Event_Type}") String rtfEventType) {
    this.rtfClient = authLoadClientBean;
    this.rtfEventType = rtfEventType;
  }

  public SubmissionMatchResponse callAuthLoadApi(
      CassandraMatchResultDAOImpl cassandraMatchResultDAO,
      SubmissionMatchResponse submissionMatchResponse,
      String rocArn) {

    log.debug("Calling auth load Api from :{}", this.rtfEventType);
    try {
      String authLoadJsonRequest =
          AuthLoadRequestMapper.buildAuthLadRequestFromSubmissionResponse(submissionMatchResponse);
      RtfRequest req =
          RtfRequest.newInstance()
              .setAxCorrelationId(UUID.randomUUID())
              .setBody(authLoadJsonRequest.getBytes())
              .setEventType(this.rtfEventType)
              .setTimeStamp(System.currentTimeMillis());

      RtfResponse response = rtfClient.execute(req, 10);
      if (response.isSuccessful()) {
        log.info(
            "saga id {}  Reversal AuthLoad response successful from {} ",
            req.getAxCorrelationId(),
            response.getResponseSource());
        submissionMatchResponse.setReversed(true);
        submissionMatchResponse.setReversalTimeStamp(new Timestamp(new Date().getTime()));
        submissionMatchResponse.setResultRemarks(
            "Reversal Process for match tier " + submissionMatchResponse.getRamTier());
        cassandraMatchResultDAO.updateMatchResultForReversal(submissionMatchResponse, rocArn);
        submissionMatchResponse = new SubmissionMatchResponse();
        submissionMatchResponse.setReversed(true);
      } else if (response.getThrowable() != null) {
        log.error(
            "saga id {}   Reversal AuthLoad  GR8383_419 Response Source {} response exception {}",
            req.getAxCorrelationId(),
            response.getResponseSource(),
            response.getThrowable());
      } else {
        log.error(
            "saga id  {} Reversal AuthLoad  GR8383_418 response failed http status code {} from {}  ",
            req.getAxCorrelationId(),
            response.getHttpStatusCode(),
            response.getResponseSource());
      }
    } catch (Exception e) {
      log.error("RTF Execute Error GR8383_416 ", e);
    }

    log.debug("AuthLoad API executed status success");
    return submissionMatchResponse;
  }
}
