package com.aexp.gms.risk.data;

import com.aexp.gms.risk.authmatch.exception.AuthMatchSystemException;
import com.aexp.gms.risk.authmatch.model.Authorization;
import com.aexp.gms.risk.authmatch.model.RocMatchRequest;
import com.aexp.gms.risk.authmatch.model.SubmissionMatchResponse;
import com.aexp.gms.risk.authmatch.util.AuthMatchLog;
import com.aexp.gms.risk.authmatch.util.AuthMatchUtil;
import com.datastax.driver.core.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

/** Created by rmanick on 6/4/2018. */
public class CassandraMatchResultDAOImpl {

  static PreparedStatement selectAuthPS = null;
  static PreparedStatement insertRamResultPS = null;
  static PreparedStatement insertSEUnmatchedAmountPS = null;
  static PreparedStatement updateRamResultPS = null;
  static PreparedStatement selectSEUnmatchAmountForTotalPS = null;

  private static PreparedStatement selectAuthCacheByTransIDPS = null;
  private Statement selectAuthStatementCacheByTransID = null;

  private static PreparedStatement deleteAuthCacheByTransIDPS = null;
  private static PreparedStatement deleteAuthCacheByCardAndSeIDPS = null;
  private static PreparedStatement deleteAuthCacheBy2DACPS = null;
  private static PreparedStatement deleteAuthCacheBy6DACPS = null;
  private static PreparedStatement deleteAuthPS = null;

  private Statement deleteAuthStatementCacheByTransID = null;
  private Statement deleteAuthStatementCacheByCardAndSe = null;
  private Statement deleteAuthStatementCacheBy2DAC = null;
  private Statement deleteAuthStatementCacheBy6DAC = null;
  private Statement deleteAuthStatement = null;

  Session session = null;

  ObjectMapper mapper = new ObjectMapper();

  public static final String SELECT_MATCHED_AUTHORIZATION = "select * from auth WHERE cas_pkey = ?";

  public static final String INSERT_RAM_RESULT_BY_ARN =
      "insert into ram_rslt_by_arn (roc_arn, cas_pkey, aprv_cd, auth2dac_appr_cd, auth6dac_appr_cd, auth_am_in_local_curr, auth_am_in_usd, auth_aprv_deny_cd,"
          + " auth_curr, auth_dt, auth_frd_loss_prbl_score, auth_frgn_spend_in, auth_lwrcw_7dlog_tx, auth_mag_swipe_in,auth_mcc, auth_se10,auth_se_ctry_cd, auth_se_indus_ctgy_cd, "
          + "auth_se_type_cd, auth_trans_id, auth_ts,chrg_dt,ctry_cd,ntwk_gen_tid_id,prcs_dt,ram_in,ram_tier,roc_cm15,roc_se10,sourceid,trans_id,soc_arn,roc_loc_am,roc_loc_am_curr_cd,roc_loc_am_"
          + "dcml_plce_no,roc_trans_dt,roc_trans_tm,roc_usd_am,soc_mcc_cd,soc_se_indus_ctgy_cd,trans_type_tx,roc_auth_dac_cd,hi_risk_api_invkd_in, hi_risk_api_resp_cd,match_ts,pos_data_cd,eci_in,"
          + "orig_mcc_cd,voice_auth_in,dpan_no,trans_ts,prcs_cd) "
          + " values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) USING TTL 1296000 ";

  public static final String UPDATE_RAM_RESULT_BY_ARN =
      "update ram_rslt_by_arn set mtch_rvs_in=?, mtch_rvs_ts=?" + " where roc_arn=? and cas_pkey=?";

  public static final String INSERT_SE_UNMATCHED_AMOUNT =
      "insert into unmtch_amt_by_soc_arn (trans_dt, trans_ts, roc_se10, dcl_mtch_usd_am, un_mtch_usd_am, soc_arn) "
          + " values (?,?,?,?,?,?) USING TTL 1296000 ";

  public static final String SELECT_UNMATCHED_AMOUNT =
      "select un_mtch_usd_am,dcl_mtch_usd_am from unmtch_amt_by_soc_arn WHERE  soc_arn= ? ";

  // REMOVE FROM CACHE Queries

  public static final String SELECT_AUTH_BY_TRANS_ID =
      "select * from auth_by_trans_id where trans_id=? and  cm_15 = ? and  aprv_deny_cd =? ";

  public static final String DELETE_AUTH_BY_TRANS_ID =
      "delete from auth_by_trans_id where trans_id=? and  cm_15 = ? and  aprv_deny_cd =? ";

  public static final String DELETE_AUTH_BY_CARD_AND_SE =
      "delete from auth_by_card_and_se where auth_se_no=? and  cm_15 = ? and  aprv_deny_cd =? ";

  public static final String DELETE_AUTH_BY_6DAC =
      "delete from auth_by_6dac_and_se where cm15 = ? and six_dgt_aprv_cde =?  and  aprv_deny_cd =? ";

  public static final String DELETE_AUTH_BY_2DAC =
      "delete from auth_by_2dac_and_se where cm15 = ? and two_dgt_aprv_cde  =?  and  aprv_deny_cd =? ";

  public static final String DELETE_AUTH = "delete from auth WHERE cas_pkey = ?";

  private ExecutorService executor = Executors.newFixedThreadPool(2);

  private AuthMatchLog authMatchLog =
      new AuthMatchLog(CassandraMatchResultDAOImpl.class.getPackage().getName());

  private final Logger LOGGER = LoggerFactory.getLogger(CassandraMatchResultDAOImpl.class);

  public CassandraMatchResultDAOImpl() {
    session = CassandraConnectionFactory.getInstance().getCassandraSession();
    if (selectAuthPS == null) {
      selectAuthPS = session.prepare(SELECT_MATCHED_AUTHORIZATION);
    }
    if (insertSEUnmatchedAmountPS == null) {
      insertSEUnmatchedAmountPS = session.prepare(INSERT_SE_UNMATCHED_AMOUNT);
    }
    if (insertRamResultPS == null) {
      insertRamResultPS = session.prepare(INSERT_RAM_RESULT_BY_ARN);
    }
    if (updateRamResultPS == null) {
      updateRamResultPS = session.prepare(UPDATE_RAM_RESULT_BY_ARN);
    }
    if (selectSEUnmatchAmountForTotalPS == null) {
      selectSEUnmatchAmountForTotalPS = session.prepare(SELECT_UNMATCHED_AMOUNT);
    }

    if (selectAuthCacheByTransIDPS == null)
      selectAuthCacheByTransIDPS = session.prepare(SELECT_AUTH_BY_TRANS_ID);

    if (deleteAuthCacheByTransIDPS == null)
      deleteAuthCacheByTransIDPS = session.prepare(DELETE_AUTH_BY_TRANS_ID);

    if (deleteAuthCacheByCardAndSeIDPS == null)
      deleteAuthCacheByCardAndSeIDPS = session.prepare(DELETE_AUTH_BY_CARD_AND_SE);

    if (deleteAuthCacheBy6DACPS == null)
      deleteAuthCacheBy6DACPS = session.prepare(DELETE_AUTH_BY_6DAC);

    if (deleteAuthCacheBy2DACPS == null)
      deleteAuthCacheBy2DACPS = session.prepare(DELETE_AUTH_BY_2DAC);

    if (deleteAuthPS == null) deleteAuthPS = session.prepare(DELETE_AUTH);
  }

  public Authorization getAuthorizationDetails(String authUniqeIdentifer) {
    Authorization authorization = null;
    BoundStatement boundStatement = selectAuthPS.bind();
    boundStatement.setString(0, authUniqeIdentifer);
    boundStatement.setConsistencyLevel(ConsistencyLevel.ONE);
    long startTimeForAuthQuery = System.currentTimeMillis();
    ResultSet resultSet = session.execute(boundStatement);
    LOGGER.debug(
        String.format(
            "Auth Query Execution time: %s ms",
            System.currentTimeMillis() - startTimeForAuthQuery));
    for (Row row : resultSet) {
      authorization = this.populateRow(row);
    }
    return authorization;
  }

  private Authorization populateRow(Row row) {
    Authorization authorization = new Authorization();
    authorization.setAuthUniqeIdentifer(row.getString("cas_pkey"));
    authorization.setApproveDenyCode(row.getString("aprv_deny_cd"));
    authorization.setAuth2DACApproveCode(row.getString("auth2dac_appr_cd"));
    authorization.setAuth6DACApproveCode(row.getString("auth6dac_appr_cd"));
    authorization.setAmountInLocalCurrency(row.getDecimal("auth_am_in_local_curr"));
    authorization.setAmountInUSD(row.getDecimal("auth_am_in_usd"));
    authorization.setAuthCurrency(row.getString("auth_curr"));
    authorization.setAuthorizationDate(row.get("auth_dt", java.time.LocalDate.class));
    authorization.setAuthorizationTime(row.get("auth_ts", java.time.LocalTime.class));
    authorization.setCardNumber(row.getString("cm15"));
    authorization.setFraudLossProbabilityScore(row.getFloat("frd_loss_prbl_score"));
    authorization.setForeignSpendIndicator(row.getString("frgn_sepnd_in"));
    authorization.setCasLogIdentifier(row.getString("lwrcw_7dlog_tx"));
    authorization.setMagStripeIndicator(row.getString("mag_swipe_in"));
    authorization.setmCC(row.getString("mcc"));
    authorization.setSeNumber(row.getString("se10"));
    authorization.setSeCountryCode(row.getString("se_ctry_cd"));
    authorization.setSeIndustryCode(row.getString("se_indus_ctgy_cd"));
    authorization.setSeTypeCode(row.getString("se_type_cd"));
    authorization.setSourceID(row.getString("sourceid"));
    authorization.setTransID(row.getString("trans_id"));
    return authorization;
  }

  public void insertMatchResult(
      RocMatchRequest rocMatchRequest,
      SubmissionMatchResponse matchResponseFromCache,
      boolean casApiInvoked,
      String seCountryCodeFromSeChar501Cache)
      throws AuthMatchSystemException {

    Authorization authorization = null;
    // Fix for Invalid null value in condition for column cas_pkey
    if (matchResponseFromCache.isMatched()
        && matchResponseFromCache.getAuthUniqueIdentifer() != null) {
      authorization = getAuthorizationDetails(matchResponseFromCache.getAuthUniqueIdentifer());
    }
    if (authorization == null) {
      authorization = new Authorization();
      authorization.setCasLogIdentifier("");
      authorization.setAuthUniqeIdentifer("Not Found");
    }
    java.time.LocalDate localDate =
        java.time.LocalDate.parse(rocMatchRequest.getRocTransactionDate());

    Timestamp matchTimestamp =
        org.apache.commons.lang.StringUtils.isNotEmpty(matchResponseFromCache.getMatchTimeStamp())
            ? Timestamp.valueOf(matchResponseFromCache.getMatchTimeStamp())
            : null;

    // When card number passed is of 19 digits then dpan need to be set to that card number
    String dpan =
        rocMatchRequest.getRocCardNumber().length() > 15
            ? rocMatchRequest.getRocCardNumber()
            : null;

    Timestamp ecbCreationTime = null;
    try {
      Date ecbCreationDate =
          new SimpleDateFormat(AuthMatchUtil.MX_AUTH_DATE_TIME_FORMAT)
              .parse(matchResponseFromCache.getEcbCreationTime());
      ecbCreationTime = new Timestamp(ecbCreationDate.getTime());
    } catch (Exception e) {
      ecbCreationTime = null;
    }

    String seCountryCode = null;
    if (!matchResponseFromCache.isMatched()) seCountryCode = seCountryCodeFromSeChar501Cache;

    Statement insertRamResultBS =
        insertRamResultPS.bind(
            rocMatchRequest.getRocAcquirerReferenceNumber(),
            authorization.getAuthUniqeIdentifer(),
            rocMatchRequest.getRocAuthDAC(),
            authorization.getAuth2DACApproveCode(),
            authorization.getAuth6DACApproveCode(),
            authorization.getAmountInLocalCurrency(),
            authorization.getAmountInUSD(),
            authorization.getApproveDenyCode(),
            authorization.getAuthCurrency(),
            authorization.getAuthorizationDate(),
            authorization.getFraudLossProbabilityScore(),
            authorization.getForeignSpendIndicator(),
            authorization.getCasLogIdentifier(),
            authorization.getMagStripeIndicator(),
            authorization.getmCC(),
            authorization.getSeNumber(),
            authorization.getSeCountryCode(),
            authorization.getSeIndustryCode(),
            authorization.getSeTypeCode(),
            authorization.getTransID(),
            authorization.getAuthorizationTime(),
            localDate,
            seCountryCode,
            rocMatchRequest.getRocNetworkGeneratedTID(),
            matchResponseFromCache.getProcessDate() != null
                ? java.time.LocalDate.parse(matchResponseFromCache.getProcessDate())
                : null,
            matchResponseFromCache.getRamIndicator(),
            matchResponseFromCache.getRamTier(),
            rocMatchRequest.getRocCardNumber(),
            rocMatchRequest.getRocSENumber(),
            authorization.getSourceID(),
            rocMatchRequest.getRocAuthorizationTransactionId(),
            rocMatchRequest.getSocAcquirerReferenceNumber(),
            rocMatchRequest.getRocLocalAmount() != null
                ? new BigDecimal(rocMatchRequest.getRocLocalAmount())
                : null,
            rocMatchRequest.getRocLocalAmountCurrency(),
            rocMatchRequest.getRocLocalDecimalPlaces() != null
                ? Integer.parseInt(rocMatchRequest.getRocLocalDecimalPlaces())
                : null,
            localDate,
            LocalTime.parse(rocMatchRequest.getRocTransactionTime()),
            new BigDecimal(rocMatchRequest.getRocAmountUSD()),
            rocMatchRequest.getSocMerchantCategoryCode(),
            rocMatchRequest.getSocSEIndustryCategoryCode(),
            rocMatchRequest.getTransactionType(),
            rocMatchRequest.getRocAuthDAC(),
            casApiInvoked,
            matchResponseFromCache.getRejIndicator(),
            matchTimestamp,
            matchResponseFromCache.getPosDataCode(),
            matchResponseFromCache.getEciIndicator(),
            matchResponseFromCache.getMcc(),
            matchResponseFromCache.getVoiceAuthIndicator(),
            dpan,
            ecbCreationTime,
            rocMatchRequest.getRocISOProcessingCode());

    try {
      session.execute(insertRamResultBS);
    } catch (Exception throwable) {
      LOGGER.error("Cassandra Insert Failure {} ", throwable.getMessage());
    }
  }

  private final SimpleDateFormat CAS_AUTHORIZATION_DATE_FORMAT =
      new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

  /*
      public RamTempSocValue rollupSEUnmatchAmountDetails(String socARN, String seNumber) {
          BoundStatement boundStatement = selectSEUnmatchAmountForTotalPS.bind();

          boundStatement.setString(0, socARN);
          boundStatement.setConsistencyLevel(ConsistencyLevel.ONE);
          RamTempSocKey ramTempSocKey = new RamTempSocKey(seNumber, socARN);


          ResultSet rollUpResult = session.execute(boundStatement);
          BigDecimal unMatchedAmount = new BigDecimal(0.0);
          BigDecimal declinedAmount = new BigDecimal(0.0);

          for (Row row : rollUpResult) {
              unMatchedAmount = unMatchedAmount.add(row.getDecimal("un_mtch_usd_am"));
              declinedAmount = declinedAmount.add(row.getDecimal("dcl_mtch_usd_am"));
          }

          RamTempSocValue ramTempSocRocValue = new RamTempSocValue(unMatchedAmount, declinedAmount);
          return ramTempSocRocValue;

      }

  */

  public boolean checkCassandraForDeclinedTransaction(String transactionId, String cm15) {
    try {
      selectAuthStatementCacheByTransID = selectAuthCacheByTransIDPS.bind(transactionId, cm15, "D");

      ResultSet resultSet = session.execute(selectAuthStatementCacheByTransID);
      if (resultSet.getAllExecutionInfo().size() > 0) return true;
      else return false;
    } catch (Exception e) {
      LOGGER.error("Message\":\"select Cassandra failed {}", e.getMessage(), e);
      return false;
    }
  }

  public void deleteFromCassandraCache(
      String tidKey, String dac6Key, String dac2Key, String casPKEY) {

    try {
      BatchStatement cacheDeleteBatch = new BatchStatement(BatchStatement.Type.UNLOGGED);

      String[] tidKeyParts = null;
      String[] dac6KeyParts = null;
      String[] dac2KeyParts = null;
      if (tidKey != null) {
        tidKeyParts = tidKey.split("\\|");
      }
      if (dac6Key != null) {
        dac6KeyParts = dac6Key.split("\\|");
      }
      if (dac2Key != null) {
        dac2KeyParts = dac2Key.split("\\|");
      }
      Date date = null;

      if (tidKeyParts != null
          && tidKeyParts.length == 3
          && !StringUtils.isEmpty(tidKeyParts[0])
          && !StringUtils.isEmpty(tidKeyParts[1])
          && !StringUtils.isEmpty(tidKeyParts[2])) {
        deleteAuthStatementCacheByTransID =
            deleteAuthCacheByTransIDPS.bind(tidKeyParts[0], tidKeyParts[1], tidKeyParts[2]);
        cacheDeleteBatch.add(deleteAuthStatementCacheByTransID);
      }
      if (dac6KeyParts != null
          && dac6KeyParts.length == 3
          && !StringUtils.isEmpty(dac6KeyParts[0])
          && !StringUtils.isEmpty(dac6KeyParts[1])
          && !StringUtils.isEmpty(dac6KeyParts[2])) {
        deleteAuthStatementCacheBy6DAC =
            deleteAuthCacheBy6DACPS.bind(dac6KeyParts[0], dac6KeyParts[1], dac6KeyParts[2]);
        cacheDeleteBatch.add(deleteAuthStatementCacheBy6DAC);
      }
      if (dac2KeyParts != null
          && dac2KeyParts.length == 3
          && !StringUtils.isEmpty(dac2KeyParts[0])
          && !StringUtils.isEmpty(dac2KeyParts[1])
          && !StringUtils.isEmpty(dac2KeyParts[2])) {
        deleteAuthStatementCacheBy2DAC =
            deleteAuthCacheBy2DACPS.bind(dac2KeyParts[0], dac2KeyParts[1], dac2KeyParts[2]);
        cacheDeleteBatch.add(deleteAuthStatementCacheBy2DAC);
      }
      if (casPKEY != null) {
        deleteAuthStatement = deleteAuthPS.bind(casPKEY);
        cacheDeleteBatch.add(deleteAuthStatement);
      }

      ResultSetFuture accountFuture = session.executeAsync(cacheDeleteBatch);
      Futures.addCallback(
          accountFuture,
          new FutureCallback<ResultSet>() {

            @Override
            public void onSuccess(ResultSet resultSet) {}

            @Override
            public void onFailure(Throwable throwable) {
              LOGGER.error("Casssandra Cache Delete Failure {} ", throwable.getMessage());
            }
          },
          executor);

    } catch (Exception e) {
      LOGGER.error(
          "{}|Delete From Cassandra {} , {}",
          authMatchLog.getCommonLogAttributes("S", "GR50651"),
          e.getMessage(),
          e);
    }
  }

  public void deleteFromAuthCardAndSe(String authSeNo, String cm15) {
    try {
      deleteAuthStatementCacheByCardAndSe =
          deleteAuthCacheByCardAndSeIDPS.bind(authSeNo, cm15, "A");
      ResultSetFuture accountFuture = session.executeAsync(deleteAuthStatementCacheByCardAndSe);
    } catch (Exception e) {
      LOGGER.error(
          "{}|Delete From Cassandra {} , {}",
          authMatchLog.getCommonLogAttributes("S", "GR50651"),
          e.getMessage(),
          e);
    }
  }

  public void updateMatchResultForReversal(SubmissionMatchResponse response, String rocArn) {
    Statement updateRamResultBS =
        updateRamResultPS.bind(
            response.isReversed(),
            response.getReversalTimeStamp(),
            rocArn,
            response.getAuthUniqueIdentifer());
    try {
      session.execute(updateRamResultBS);
    } catch (Exception throwable) {
      LOGGER.error("Cassandra update Failure {} ", throwable.getMessage());
    }
  }
}
