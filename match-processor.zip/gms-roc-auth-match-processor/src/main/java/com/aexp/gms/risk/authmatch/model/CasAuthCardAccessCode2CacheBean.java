package com.aexp.gms.risk.authmatch.model;

import java.math.BigDecimal;
import java.util.Date;

public class CasAuthCardAccessCode2CacheBean {

  /** */
  //	private static final long serialVersionUID = 655814863422556823L;

  private String cardNumber;

  private String auth2Dac;

  private String approveDenyCode;

  private String seNumber;

  private BigDecimal authAmountLocal;

  private String authAmountCurrencyCode;

  private Date authTransactionDateTime;

  private BigDecimal authAmountUSD;

  private String rocAuthMatchedFlag;

  private String rocAuthMatchedCriteriaId;

  private String persistedFlag; // Y -> Cassandra updated

  private String tidCMPrimaryKey;

  private String cardDac6PrimaryKey;

  private String authUniqueIdentifier;

  private BigDecimal matchedAmountUSD;

  public String getCardNumber() {
    return cardNumber;
  }

  public void setCardNumber(String cardNumber) {
    this.cardNumber = cardNumber;
  }

  public String getAuth2Dac() {
    return auth2Dac;
  }

  public void setAuth2Dac(String auth2Dac) {
    this.auth2Dac = auth2Dac;
  }

  public String getApproveDenyCode() {
    return approveDenyCode;
  }

  public void setApproveDenyCode(String approveDenyCode) {
    this.approveDenyCode = approveDenyCode;
  }

  public String getSeNumber() {
    return seNumber;
  }

  public void setSeNumber(String seNumber) {
    this.seNumber = seNumber;
  }

  public BigDecimal getAuthAmountLocal() {
    return authAmountLocal;
  }

  public void setAuthAmountLocal(BigDecimal authAmountLocal) {
    this.authAmountLocal = authAmountLocal;
  }

  public String getAuthAmountCurrencyCode() {
    return authAmountCurrencyCode;
  }

  public void setAuthAmountCurrencyCode(String authAmountCurrencyCode) {
    this.authAmountCurrencyCode = authAmountCurrencyCode;
  }

  public Date getAuthTransactionDateTime() {
    return authTransactionDateTime;
  }

  public void setAuthTransactionDateTime(Date authTransactionDateTime) {
    this.authTransactionDateTime = authTransactionDateTime;
  }

  public BigDecimal getAuthAmountUSD() {
    return authAmountUSD;
  }

  public void setAuthAmountUSD(BigDecimal authAmountUSD) {
    this.authAmountUSD = authAmountUSD;
  }

  public String getRocAuthMatchedFlag() {
    return rocAuthMatchedFlag;
  }

  public void setRocAuthMatchedFlag(String rocAuthMatchedFlag) {
    this.rocAuthMatchedFlag = rocAuthMatchedFlag;
  }

  public String getRocAuthMatchedCriteriaId() {
    return rocAuthMatchedCriteriaId;
  }

  public void setRocAuthMatchedCriteriaId(String rocAuthMatchedCriteriaId) {
    this.rocAuthMatchedCriteriaId = rocAuthMatchedCriteriaId;
  }

  public String getPersistedFlag() {
    return persistedFlag;
  }

  public void setPersistedFlag(String persistedFlag) {
    this.persistedFlag = persistedFlag;
  }

  public String getTidCMPrimaryKey() {
    return tidCMPrimaryKey;
  }

  public void setTidCMPrimaryKey(String tidCMPrimaryKey) {
    this.tidCMPrimaryKey = tidCMPrimaryKey;
  }

  public String getCardDac6PrimaryKey() {
    return cardDac6PrimaryKey;
  }

  public void setCardDac6PrimaryKey(String cardDac6PrimaryKey) {
    this.cardDac6PrimaryKey = cardDac6PrimaryKey;
  }

  public String getAuthUniqueIdentifier() {
    return authUniqueIdentifier;
  }

  public void setAuthUniqueIdentifier(String authUniqueIdentifier) {
    this.authUniqueIdentifier = authUniqueIdentifier;
  }

  public BigDecimal getMatchedAmountUSD() {
    return matchedAmountUSD;
  }

  public void setMatchedAmountUSD(BigDecimal matchedAmountUSD) {
    this.matchedAmountUSD = matchedAmountUSD;
  }

  public String getTableName() {
    return "CasAuthCardAccessCode2CacheBean";
  }

  public String getCacheName() {
    return "GMS_CAS_AUTH_CM_DAC2_CACHE_V1";
  }

  /*public String toString() {
    return "CasAuthCardAccessCode2CacheBean [cardNumber="
        + cardNumber
        + ", auth2Dac="
        + auth2Dac
        + ", authAmountLocal="
        + authAmountLocal
        + ", authAmountCurrencyCode="
        + authAmountCurrencyCode
        + ", authTransactionDateTime="
        + authTransactionDateTime
        + ", authAmountUSD="
        + authAmountUSD
        + ", tidCMPrimaryKey="
        + tidCMPrimaryKey
        + ", cardDac6PrimaryKey="
        + cardDac6PrimaryKey
        + ", authUniqueIdentifier="
        + authUniqueIdentifier
        + "] version1";
  }*/

  public String getCacheStringKey() {
    return this.cardNumber + "|" + this.auth2Dac + "|" + this.approveDenyCode;
  }
}
