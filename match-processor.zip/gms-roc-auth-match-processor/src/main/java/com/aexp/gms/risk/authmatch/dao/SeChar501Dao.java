package com.aexp.gms.risk.authmatch.dao;

import com.aexp.gmnt.imc.vo.SECharacteristics501Data;

public interface SeChar501Dao {

  void put(String seNumber, SECharacteristics501Data value);

  SECharacteristics501Data get(String seNumber);

  void setIgniteProvider(IgniteProvider igniteProvider);
}
