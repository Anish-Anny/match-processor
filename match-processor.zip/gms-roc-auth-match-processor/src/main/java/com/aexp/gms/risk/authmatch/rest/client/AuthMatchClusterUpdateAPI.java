package com.aexp.gms.risk.authmatch.rest.client;

import com.aexp.gms.risk.authmatch.model.CacheSynchUpRequest;
import com.aexp.gms.risk.authmatch.model.SubmissionMatchResponse;
import com.aexp.rtf.client.RtfClient;
import com.aexp.rtf.client.RtfRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

public class AuthMatchClusterUpdateAPI {

  private final Logger log = LoggerFactory.getLogger(AuthMatchClusterUpdateAPI.class);

  private String url;

  private RtfClient rtfClient;

  private String rtfEventType;

  public AuthMatchClusterUpdateAPI(
      @Autowired RtfClient rtfClientBean,
      @Value("${cluster.match.update_RTF_Event_Type}") String rtfEventType) {
    this.rtfClient = rtfClientBean;
    this.rtfEventType = rtfEventType;
  }

  public void cacheSynchUpCall(SubmissionMatchResponse request) {

    try {
      CacheSynchUpRequest result = new CacheSynchUpRequest();
      result.builder(request, result);
      String json = new ObjectMapper().writeValueAsString(result);
      log.debug("Cluster Update API  message Event Type :{} ", this.rtfEventType);
      RtfRequest req =
          RtfRequest.newInstance()
              .setAxCorrelationId(UUID.randomUUID())
              .setBody(json.getBytes())
              .setEventType(this.rtfEventType)
              .setTimeStamp(System.currentTimeMillis());

      this.rtfClient
          .executeAsynch(req, 10)
          .thenAccept(
              response -> {
                if (response.isSuccessful()) {
                  log.info(
                      "saga id {} and Request ARN {} response for AuthMatch successful from {} ",
                      req.getAxCorrelationId(),
                      request.getRocAcquirerReferenceNumber(),
                      response.getResponseSource());
                } else if (response.getThrowable() != null) {
                  log.error(
                      "saga id {} GR8383_508 Response  for AuthMatch Source {} response exception {}",
                      req.getAxCorrelationId(),
                      response.getResponseSource(),
                      response.getThrowable());
                } else {
                  log.error(
                      "saga id  {} GR8383_507 response  for AuthMatch failed http status code {} from {}  ",
                      req.getAxCorrelationId(),
                      response.getHttpStatusCode(),
                      response.getResponseSource());
                }
              })
          .exceptionally(
              t -> {
                log.error(
                    "Event {} RTF GR8383_506  for AuthMatch Exception ", this.rtfEventType, t);
                return null;
              });
    } catch (Exception e) {
      log.error("Event {} GR8383_509 RTF Execute Error ", this.rtfEventType, e);
    }

    log.debug("Cluster Update API RTF response ");
  }
}
