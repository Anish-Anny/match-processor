package com.aexp.gms.risk.authmatch.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Builder
@Getter
@Setter
@AllArgsConstructor
@RequiredArgsConstructor
@EqualsAndHashCode
@ToString
public class CacheSynchUpRequest {

  private String cacheKey;
  private String cacheName;
  private String tidCardKey;
  private String dac6CardKey;
  private String dac2CardKey;
  private ArrayList<String> tidCardKeysList;
  private ArrayList<String> dac6CardKeysList;
  private ArrayList<String> dac2CardKeysList;
  private String rocSENumber;
  private String rocCardNumber;
  private boolean donotDeleteFlag;
  private String ramTier;
  private String authUniqueIdentifer;
  private String transactionId;
  private String rocAuthDAC;
  private BigDecimal matchedAmountUSD;

  public void objectMapper(
      CacheSynchUpRequest request,
      RocMatchRequest rocMatchRequest,
      SubmissionMatchResponse reponse) {
    rocMatchRequest.setRocCardNumber(request.getRocCardNumber());
    rocMatchRequest.setRocSENumber(request.getRocSENumber());
    reponse.setAuthUniqueIdentifer(request.getAuthUniqueIdentifer());
    reponse.setCacheKey(request.getCacheKey());
    reponse.setCacheName(request.getCacheName());
    reponse.setDac2CardKey(request.getDac2CardKey());
    reponse.setDac2CardKeysList(request.getDac2CardKeysList());
    reponse.setDac6CardKey(request.getDac6CardKey());
    reponse.setDac6CardKeysList(request.getDac6CardKeysList());
    reponse.setRamTier(request.getRamTier());
    reponse.setTidCardKey(request.getTidCardKey());
    reponse.setTidCardKeysList(request.getTidCardKeysList());
    reponse.setTransactionId(request.getTransactionId());
    reponse.setRocAuthDAC(request.getRocAuthDAC());
  }

  public void builder(SubmissionMatchResponse source, CacheSynchUpRequest dest) {
    dest.setAuthUniqueIdentifer(source.getAuthUniqueIdentifer());
    dest.setCacheKey(source.getCacheKey());
    dest.setCacheName(source.getCacheName());
    dest.setDac2CardKey(source.getDac2CardKey());
    dest.setDac2CardKeysList(source.getDac2CardKeysList());
    dest.setDac6CardKey(source.getDac6CardKey());
    dest.setDac6CardKeysList(source.getDac6CardKeysList());
    dest.setRamTier(source.getRamTier());
    dest.setTidCardKey(source.getTidCardKey());
    dest.setTidCardKeysList(source.getTidCardKeysList());
    dest.setTransactionId(source.getTransactionId());
    dest.setRocCardNumber(source.getRocCardNumber());
    dest.setRocSENumber(source.getRocSENumber());
    dest.setRocAuthDAC(source.getRocAuthDAC());
  }
}
