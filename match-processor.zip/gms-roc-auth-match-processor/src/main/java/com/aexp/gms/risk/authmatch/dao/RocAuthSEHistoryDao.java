package com.aexp.gms.risk.authmatch.dao;

import com.aexp.gms.risk.authmatch.model.ignite.key.RocAuthSEHistoryKey;
import com.aexp.gms.risk.authmatch.model.ignite.value.RocAuthSEHistoryValue;

public interface RocAuthSEHistoryDao {
  void put(RocAuthSEHistoryKey key, RocAuthSEHistoryValue value);

  RocAuthSEHistoryValue get(RocAuthSEHistoryKey rocAuthSEHistoryKey);

  void setIgniteProvider(IgniteProvider igniteProvider);
}
