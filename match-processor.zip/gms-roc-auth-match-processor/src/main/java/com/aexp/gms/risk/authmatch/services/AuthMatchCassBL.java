package com.aexp.gms.risk.authmatch.services;

import com.aexp.gmnt.imc.compute.global.IProgramData;
import com.aexp.gms.imc.risk.rules.vo.values.IndustryLeverageBean;
import com.aexp.gms.risk.authmatch.model.CasAuthCardAccessCode2CacheBean;
import com.aexp.gms.risk.authmatch.model.CasAuthCardAccessCode6CacheBean;
import com.aexp.gms.risk.authmatch.model.CasAuthTransIdCardCacheBean;
import com.aexp.gms.risk.authmatch.model.RocAuthMatchResult;
import com.aexp.gms.risk.authmatch.model.RocMatchRequest;
import com.aexp.gms.risk.authmatch.model.SubmissionMatchResponse;
import com.aexp.gms.risk.authmatch.model.ignite.key.RocAuthSEHistoryKey;
import com.aexp.gms.risk.authmatch.util.AuthMatchConstants;
import com.aexp.gms.risk.authmatch.util.AuthMatchLog;
import com.aexp.gms.risk.authmatch.util.AuthMatchUtil;
import com.aexp.gms.risk.authmatch.util.ITier;
import com.aexp.gms.risk.authmatch.util.IndustryLeverage;
import com.aexp.gms.risk.data.AuthMatchDatabaseDAOImpl;
import com.aexp.gms.risk.data.RocAuthSeSubmissionHistoryDAOImpl;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

public class AuthMatchCassBL {

  private AuthMatchLog authMatchLog =
      new AuthMatchLog(AuthMatchCassBL.class.getPackage().getName());
  private final Logger LOGGER = LoggerFactory.getLogger(ComputeJobProcess.class);
  private static final String CLASS_NAME = "ComputeJobProcess";
  boolean igniteStarted;
  // @Autowired
  AuthMatchDatabaseDAOImpl authMatchDAOImpl;
  RocAuthSeSubmissionHistoryDAOImpl rocAuthSeSubmissionHistoryDAO;

  DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
  SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");

  public AuthMatchCassBL(
      AuthMatchDatabaseDAOImpl authMatchDAOImpl,
      RocAuthSeSubmissionHistoryDAOImpl rocAuthSeSubmissionHistoryDAO) {
    this.authMatchDAOImpl = authMatchDAOImpl;
    this.rocAuthSeSubmissionHistoryDAO = rocAuthSeSubmissionHistoryDAO;
  }

  public SubmissionMatchResponse process(IProgramData programDataInput) {
    RocMatchRequest input = (RocMatchRequest) programDataInput;

    SubmissionMatchResponse response = new SubmissionMatchResponse();
    List<String> eligibleTiersList = input.getEligibleTiersList();

    try {
      // Matches tier 2
      if (AuthMatchUtil.isEligibleTierListContainsTier(
          eligibleTiersList,
          AuthMatchUtil.MatchTiers.TIER_2.getValue(),
          AuthMatchUtil.MatchTiers.TIER_3.getValue()))
        response = matchByApprovedTIDAndAmount(input, response);
      if (!response.isMatched()
          && AuthMatchUtil.isEligibleTierListContainsTier(
              eligibleTiersList, AuthMatchUtil.MatchTiers.TIER_1.getValue()))
        // Matches tier 1
        response = matchByRejectedTID(input, response);
      if (!response.isMatched()
          && AuthMatchUtil.isEligibleTierListContainsTier(
              eligibleTiersList,
              AuthMatchUtil.MatchTiers.TIER_4.getValue(),
              AuthMatchUtil.MatchTiers.TIER_5.getValue()))
        // Matches tiers 4 and 5
        response = matchByCardDac6AndAmoutLeverageSEDate(input, response);
      if (!response.isMatched()
          && AuthMatchUtil.isEligibleTierListContainsTier(
              eligibleTiersList,
              AuthMatchUtil.MatchTiers.TIER_6.getValue(),
              AuthMatchUtil.MatchTiers.TIER_7.getValue()))
        // Matches tiers 6 and 7
        response = matchByCardDac2AndAmoutLeverageSEDate(input, response);
      if (!response.isMatched()
          && AuthMatchUtil.isEligibleTierListContainsTier(
              eligibleTiersList, AuthMatchUtil.MatchTiers.TIER_8.getValue()))
        response = matchByTier8(input, response);
      if (!response.isMatched()
          && AuthMatchUtil.isEligibleTierListContainsTier(
              eligibleTiersList, AuthMatchUtil.MatchTiers.TIER_9.getValue()))
        response = matchByTier9(input, response);
      if (!response.isMatched()
          && AuthMatchUtil.isEligibleTierListContainsTier(
              eligibleTiersList, AuthMatchUtil.MatchTiers.TIER_11.getValue()))
        response = matchByTier11(input, response);

      if (!response.isMatched()) {
        response.setRamIndicator("0");
        response.setRamTier("T00");
        response.setResultRemarks(
            "1 -> Match by TID not found, "
                + "2 -> Match by card-SE-DAC6-amount leverage not found, "
                + "3 -> Match by card,SE and DAC6 not found, "
                + "4 -> Match by card and DAC6 not found, "
                + "5 -> Match by card-SE-DAC2-amount leverage not found, "
                + "6 -> Match by card,SE and DAC2 not found, "
                + "7 -> Match by card and DAC2 not found in persistent data, "
                + "");
      }

    } catch (Exception e) {
      LOGGER.error(
          "{}|Match in Cassandra error: {} , {} ",
          authMatchLog.getCommonLogAttributes("S", "GR5003"),
          e.getMessage(),
          e);
    }
    return response;
  }

  public SubmissionMatchResponse matchByPreviousRecords(
      RocMatchRequest input, SubmissionMatchResponse response) {

    RocAuthMatchResult rocMatchResult = getMatchResult(input.getRocAcquirerReferenceNumber());
    if (response == null) {
      response = new SubmissionMatchResponse();
    }
    if (rocMatchResult == null || rocMatchResult.getRam_tier() == null) {
      return response;
    }
    String authAmountUsd =
        rocMatchResult.getAuth_am_in_usd() != null
            ? rocMatchResult.getAuth_am_in_usd().toString()
            : null;
    String authAmountLocal =
        rocMatchResult.getAuth_am_local_curr() != null
            ? rocMatchResult.getAuth_am_local_curr().toString()
            : null;

    response.setRamIndicator(rocMatchResult.getRam_in());
    response.setRamTier(rocMatchResult.getRam_tier());
    response.setResultRemarks(
        "Match by previous records match tier " + rocMatchResult.getRam_tier());
    response.setCacheName(AuthMatchConstants.CAS_AUTH_TID_CM_CACHE);
    response.setAuthSeNumber(rocMatchResult.getAuth_se10());
    response.setCaspKey(rocMatchResult.getCas_pkey());
    response.setApprovalCode(rocMatchResult.getAuth_aprv_deny_cd());
    response.setMcc(rocMatchResult.getAuth_mcc());
    response.setTransactionId(rocMatchResult.getTrans_id());
    response.setAuthSeNumber(rocMatchResult.getAuth_se10());
    response.setAuthUniqueIdentifer(rocMatchResult.getCas_pkey());

    response.setPosDataCode(rocMatchResult.getPosDataCode());
    response.setEciIndicator(rocMatchResult.getEciIndicator());
    response.setOriginalMccCode(rocMatchResult.getOrig_mcc_cd());
    response.setVoiceAuthIndicator(rocMatchResult.getVoiceAuthIndicator());
    response.setAuthDate(rocMatchResult.getAuth_dt());
    response.setAuthTime(rocMatchResult.getAuth_ts());
    response.setSeCountryCode(rocMatchResult.getAuth_se_ctry_cd());
    response.setSeIndustryCategoryCode(rocMatchResult.getAuth_se_indus_ctgy_cd());
    response.setAuthAmountUsd(authAmountUsd);
    response.setAuthAmountLocal(authAmountLocal);
    response.setAuthAmountCurrencyCode(rocMatchResult.getAuth_curr());
    response.setForeignSpendIndicator(rocMatchResult.getAuth_frgn_spend_in());
    response.setAuth2Dac(rocMatchResult.getAuth2dac_appr_cd());
    response.setAuth6Dac(rocMatchResult.getAuth6dac_appr_cd());
    response.setMagneticStripeCode(rocMatchResult.getAuth_mag_swipe_in());
    response.setFraudLossProbability(rocMatchResult.getAuth_frd_loss_prbl_score());
    response.setSeTypeCode(rocMatchResult.getAuth_se_type_cd());
    response.setRocCardNumber(rocMatchResult.getRoc_cm15());
    response.setDpan(rocMatchResult.getDpan());
    response.setEcbCreationTime(rocMatchResult.getEcbCreationTime());
    response.setFromPrevMatch(true);
    return response;
  }

  public SubmissionMatchResponse matchByTier8(
      RocMatchRequest rocMatchRequest, SubmissionMatchResponse submissionMatchResponse) {
    boolean rocMatched = false;
    BigDecimal rocLocalAmount = null;
    BigDecimal rocAmount = null;
    String approvalCode = "";
    boolean isLocalAmount = false;

    LOGGER.debug(
        "GRDEBUG3 - TID : {}, RocAmount : {}, ",
        rocMatchRequest.getRocAuthorizationTransactionId(),
        rocMatchRequest.getRocAmountUSD(),
        ITier.REQUESTHANDLER,
        CLASS_NAME,
        CLASS_NAME);

    try {
      if (rocMatchRequest.getRocLocalAmount() != null
          && rocMatchRequest.getRocLocalDecimalPlaces() != null) {
        Double localDecimalPlaces = Double.valueOf(rocMatchRequest.getRocLocalDecimalPlaces());
        Double localamount =
            (Double.valueOf(rocMatchRequest.getRocLocalAmount())
                / (((int) Math.pow(10, localDecimalPlaces))));
        if (org.apache.commons.lang.StringUtils.isNotEmpty(
            rocMatchRequest.getRocLocalDecimalPlaces())) {
          rocLocalAmount = new BigDecimal(localamount.toString());
        } else {
          rocLocalAmount = new BigDecimal(localamount).setScale(2, RoundingMode.FLOOR);
        }
      }
    } catch (Exception e) {
    }

    try {
      if (rocLocalAmount != null) {
        rocAmount = rocLocalAmount;
        isLocalAmount = true;
      } else {
        rocAmount = new BigDecimal(rocMatchRequest.getRocAmountUSD());
      }

      // Match with Tier 8 logic
      BigDecimal difference = rocAmount;
      BigDecimal authAmountFromDb = BigDecimal.ZERO;
      String transId = null;
      String dac6Key = null;
      String dac2Key = null;

      ResultSet resultSet = authMatchDAOImpl.getCasAuthByCardAndSe(rocMatchRequest, "A");

      List<String> transactionIdList = new ArrayList<String>();
      ArrayList<String> tidCardKeysList = new ArrayList<String>();
      ArrayList<String> dac6KeysList = new ArrayList<String>();
      ArrayList<String> dac2KeysList = new ArrayList<String>();
      BigDecimal sumOfAuthAmount = BigDecimal.ZERO;
      CasAuthTransIdCardCacheBean transCardBean = null;
      String rocAmountFromRocReq = null;
      Iterator<Row> iterator = resultSet.iterator();
      while (iterator.hasNext()) {
        Row row = iterator.next();

        if (transCardBean == null) {
          transCardBean = new CasAuthTransIdCardCacheBean();
          transCardBean.setTransactionId(row.getString("trans_id"));
          transCardBean.setCardNumber(row.getString("cm_15"));
          transCardBean.setApproveDenyCode(row.getString("aprv_deny_cd"));
          approvalCode = row.getString("aprv_deny_cd");
          if (isLocalAmount) {
            transCardBean.setAuthAmountLocal(row.getDecimal("auth_loc_am"));
          } else {
            transCardBean.setAuthAmountUSD(row.getDecimal("auth_usd_am"));
          }
          transCardBean.setSeNumber(row.getString("auth_se_no"));
          transCardBean.setAuthTransactionDateTime(row.getTimestamp("auth_ts"));
          transCardBean.setAuthAmountLocal(row.getDecimal("auth_loc_am"));
          transCardBean.setCardDac2PrimaryKey(row.getString("card_2dac_cache_key"));
          transCardBean.setCardDac6PrimaryKey(row.getString("card_6dac_cache_key"));
          transCardBean.setRocAuthMatchedFlag(row.getString("auth_mtch_in"));
          transCardBean.setRocAuthMatchedCriteriaId(row.getString("ram_mtch_tier_cd"));
          transCardBean.setAuthUniqueIdentifier(row.getString("cas_pkey"));
        }

        if (isLocalAmount) {
          authAmountFromDb = row.getDecimal("auth_loc_am");
          rocAmountFromRocReq = rocMatchRequest.getRocLocalAmount();
        } else {
          authAmountFromDb = row.getDecimal("auth_usd_am");
          rocAmountFromRocReq = rocMatchRequest.getRocAmountUSD();
        }
        transId = row.getString("trans_id");
        dac6Key = row.getString("card_6dac_cache_key");
        dac2Key = row.getString("card_2dac_cache_key");

        Date authTranDateTime = row.getTimestamp("auth_ts");

        simpleDateFormat.setLenient(false);
        String authDateTime = simpleDateFormat.format(authTranDateTime);

        String rocMatchedFlag = row.getString("auth_mtch_in");

        if (authDateTime.equals(rocMatchRequest.getRocTransactionDate())
            && authAmountFromDb.compareTo(new BigDecimal(rocAmountFromRocReq)) < 0
            && !rocMatchedFlag.equals("Y")) {
          sumOfAuthAmount = sumOfAuthAmount.add(authAmountFromDb);
          transactionIdList.add(transId);
          dac6KeysList.add(dac6Key);
          dac2KeysList.add(dac2Key);
        }
      }
      if (difference.compareTo(sumOfAuthAmount) == 0) {
        // Match by 8
        rocMatched = true;
        transCardBean.setRocAuthMatchedCriteriaId("T08");
        transCardBean.setRocAuthMatchedFlag("Y");
        submissionMatchResponse.setRamIndicator("1");
        submissionMatchResponse.setRamTier("T08");
        submissionMatchResponse.setTransactionId(transCardBean.getTransactionId());
        submissionMatchResponse.setResultRemarks(
            "8 -> Match by CM, SE and CAS Date found in persistent data"
                + (isLocalAmount ? " with Local amount" : ""));

        final CasAuthTransIdCardCacheBean transCardBeanTemp = transCardBean;
        transactionIdList.forEach(
            tranId -> {
              String cacheKey2 =
                  tranId
                      + "|"
                      + transCardBeanTemp.getCardNumber()
                      + "|"
                      + transCardBeanTemp.getApproveDenyCode();
              tidCardKeysList.add(cacheKey2);
            });
        submissionMatchResponse.setCaspKey(transCardBean.getAuthUniqueIdentifier());
        submissionMatchResponse.setAuthUniqueIdentifer(transCardBean.getAuthUniqueIdentifier());
        submissionMatchResponse.setCacheKey(transCardBean.getCacheStringKey());
        submissionMatchResponse.setCacheName(AuthMatchConstants.CAS_AUTH_TID_CM_CACHE);

        submissionMatchResponse.setTidCardKey(transCardBean.getCacheStringKey());
        submissionMatchResponse.setTidCardKeysList(tidCardKeysList);
        submissionMatchResponse.setDac6CardKey(transCardBean.getCardDac6PrimaryKey());
        submissionMatchResponse.setDac6CardKeysList(dac6KeysList);
        submissionMatchResponse.setDac2CardKey(transCardBean.getCardDac2PrimaryKey());
        submissionMatchResponse.setDac2CardKeysList(dac2KeysList);

        submissionMatchResponse.setPosDataCode(transCardBean.getPosDataCode());
        submissionMatchResponse.setEciIndicator(transCardBean.getEciIndicator());
        submissionMatchResponse.setApprovalCode(approvalCode);
        submissionMatchResponse.setMcc(transCardBean.getMccMerchant());
        submissionMatchResponse.setVoiceAuthIndicator(transCardBean.getVoiceAuthIndicator());
        submissionMatchResponse.setRejIndicator("");
        submissionMatchResponse.setAuthSeNumber(transCardBean.getSeNumber());

        submissionMatchResponse.setEcbCreationTime(
            transCardBean.getTransactionTimeStamp() != null
                ? AuthMatchUtil.getStringFromDate(
                    transCardBean.getTransactionTimeStamp(), AuthMatchUtil.MX_AUTH_DATE_TIME_FORMAT)
                : "");
        submissionMatchResponse.setRocAuthDAC(rocMatchRequest.getRocAuthDAC());
        submissionMatchResponse.setRocCardNumber(rocMatchRequest.getRocCardNumber());
        submissionMatchResponse.setRocSENumber(rocMatchRequest.getRocSENumber());
      }
    } catch (Exception e) {
      LOGGER.error(
          "{}| Error in Match by Approved TID and Amount",
          authMatchLog.getCommonLogAttributes("S", "GE000M04", rocMatchRequest),
          ITier.REQUESTHANDLER,
          CLASS_NAME,
          CLASS_NAME);
      rocMatched = false;
    }
    submissionMatchResponse.setMatched(rocMatched);
    return submissionMatchResponse;
  }

  private SubmissionMatchResponse matchByRejectedTID(
      RocMatchRequest rocMatchRequest, SubmissionMatchResponse submissionMatchResponse) {
    boolean rocMatched = false;
    try {

      CasAuthTransIdCardCacheBean tidBean =
          authMatchDAOImpl.getTransByTidData(rocMatchRequest, "D");

      String[] approvalCode = tidBean.getCardDac6PrimaryKey().split("\\|", 5);

      if (tidBean != null) {
        rocMatched = true;
        submissionMatchResponse.setCaspKey(tidBean.getAuthUniqueIdentifier());
        submissionMatchResponse.setPosDataCode(tidBean.getPosDataCode());
        submissionMatchResponse.setEciIndicator(tidBean.getEciIndicator());
        submissionMatchResponse.setApprovalCode(approvalCode[1]);
        submissionMatchResponse.setMcc(tidBean.getMccMerchant());
        submissionMatchResponse.setVoiceAuthIndicator(tidBean.getVoiceAuthIndicator());
        submissionMatchResponse.setRejIndicator("");
        submissionMatchResponse.setRamIndicator("2");
        submissionMatchResponse.setRamTier("T01");
        submissionMatchResponse.setTransactionId(tidBean.getTransactionId());
        submissionMatchResponse.setResultRemarks(
            "1 -> Match by Rejected TID found in persistent data");
        submissionMatchResponse.setAuthUniqueIdentifer(tidBean.getAuthUniqueIdentifier());
        submissionMatchResponse.setCacheKey(tidBean.getCacheStringKey());
        submissionMatchResponse.setCacheName(AuthMatchConstants.CAS_AUTH_TID_CM_CACHE);
        submissionMatchResponse.setTidCardKey(tidBean.getCacheStringKey());
        submissionMatchResponse.setDac6CardKey(tidBean.getCardDac6PrimaryKey());
        submissionMatchResponse.setDac2CardKey(tidBean.getCardDac2PrimaryKey());
        submissionMatchResponse.setAuthSeNumber(tidBean.getSeNumber());
        submissionMatchResponse.setEcbCreationTime(
            tidBean.getTransactionTimeStamp() != null
                ? AuthMatchUtil.getStringFromDate(
                    tidBean.getTransactionTimeStamp(), AuthMatchUtil.MX_AUTH_DATE_TIME_FORMAT)
                : "");
        submissionMatchResponse.setRocAuthDAC(rocMatchRequest.getRocAuthDAC());
        submissionMatchResponse.setRocCardNumber(rocMatchRequest.getRocCardNumber());
        submissionMatchResponse.setRocSENumber(rocMatchRequest.getRocSENumber());
        LOGGER.debug(
            "{}|Match by TID and deny code found in persistent data ",
            authMatchLog.getCommonLogAttributes("S", "GR0041"),
            ITier.REQUESTHANDLER,
            CLASS_NAME,
            CLASS_NAME);
      }
    } catch (Exception e) {
      rocMatched = false;
    }
    submissionMatchResponse.setMatched(rocMatched);
    return submissionMatchResponse;
  }

  private SubmissionMatchResponse matchByApprovedTIDAndAmount(
      RocMatchRequest rocMatchRequest, SubmissionMatchResponse submissionMatchResponse) {
    boolean rocMatched = false;
    BigDecimal rocLocalAmount = null;

    BigDecimal rocAmount = null;
    BigDecimal authAmount = null;
    String approvalCode = "";
    boolean isLocalAmount = false;

    try {
      if (rocMatchRequest.getRocLocalAmount() != null
          && rocMatchRequest.getRocLocalDecimalPlaces() != null) {
        Double localDecimalPlaces = Double.valueOf(rocMatchRequest.getRocLocalDecimalPlaces());
        Double localamount =
            (Double.valueOf(rocMatchRequest.getRocLocalAmount())
                / (((int) Math.pow(10, localDecimalPlaces))));
        if (org.apache.commons.lang.StringUtils.isNotEmpty(
            rocMatchRequest.getRocLocalDecimalPlaces())) {
          rocLocalAmount = new BigDecimal(localamount.toString());
        } else {
          rocLocalAmount = new BigDecimal(localamount).setScale(2, RoundingMode.FLOOR);
        }
      }
    } catch (Exception e) {
    }

    try {

      // Get Card Trans data into bean by approve code
      CasAuthTransIdCardCacheBean tidBean =
          authMatchDAOImpl.getTransByTidData(rocMatchRequest, "A");

      if (tidBean != null) {
        String[] dac6Key = tidBean.getCardDac6PrimaryKey().split("\\|", 5);
        if (dac6Key.length > 0) approvalCode = dac6Key[1];

        if (rocLocalAmount != null && tidBean.getAuthAmountLocal() != null) {
          rocAmount = rocLocalAmount;
          authAmount = tidBean.getAuthAmountLocal();
          isLocalAmount = true;
        } else {
          rocAmount = new BigDecimal(rocMatchRequest.getRocAmountUSD());
          authAmount = tidBean.getAuthAmountUSD();
        }
      }

      // Match with Tier 2 logic
      //			if (tidBean != null && tidBean.getAuthAmountUSD().equals(new
      // BigDecimal(rocMatchRequest.getRocAmountUSD()))) {
      if (tidBean != null
          && authAmount != null
          && rocAmount != null
          && authAmount.compareTo(rocAmount) == 0) {
        rocMatched = true;
        submissionMatchResponse.setRamIndicator("1");
        submissionMatchResponse.setRamTier("T02");
        submissionMatchResponse.setTransactionId(tidBean.getTransactionId());
        submissionMatchResponse.setResultRemarks(
            "2 -> Match by Approved TID and Amount found in persistent data"
                + (isLocalAmount ? " with Local amount" : ""));
        submissionMatchResponse.setAuthUniqueIdentifer(tidBean.getAuthUniqueIdentifier());
        submissionMatchResponse.setCacheKey(tidBean.getCacheStringKey());
        submissionMatchResponse.setCacheName(AuthMatchConstants.CAS_AUTH_TID_CM_CACHE);
        submissionMatchResponse.setDac6CardKey(tidBean.getCardDac6PrimaryKey());
        submissionMatchResponse.setDac2CardKey(tidBean.getCardDac2PrimaryKey());
        submissionMatchResponse.setTidCardKey(tidBean.getCacheStringKey());
        submissionMatchResponse.setAuthSeNumber(tidBean.getSeNumber());

        LOGGER.debug(
            "{}|Match by Approved TID and Amount found in persistent data ",
            authMatchLog.getCommonLogAttributes("S", "GR0031"),
            ITier.REQUESTHANDLER,
            CLASS_NAME,
            CLASS_NAME);
      }

      // Match with Tier 3a logic with multiple roc with 1 auth
      // Match with Tier 3b is not possible as it needs another table in Cassandra to lookup data by
      // Card and SE
      BigDecimal diffAmount = null;
      if (authAmount != null) diffAmount = authAmount.subtract(rocAmount);
      if (!rocMatched
          && tidBean != null
          && rocAmount != null
          && diffAmount != null
          && (diffAmount.compareTo(new BigDecimal(1.00)) > 0)) {
        BigDecimal matchAmount = tidBean.getMatchedAmountUSD();

        /*if (matchAmount == null) {
             matchAmount = new BigDecimal("0.00");
           } else {
             submissionMatchResponse.setMatchedMultipleRocToAuth(true);
           }

           matchAmount = matchAmount.add(rocAmount);
           tidBean.setMatchedAmountUSD(matchAmount);

           // Update auth_by_trans_id table for matched amount
        //   authMatchDAOImpl.updateMatchAmount(rocMatchRequest, "A", matchAmount);
        */

        rocMatched = true;
        submissionMatchResponse.setRamIndicator("1");
        submissionMatchResponse.setRamTier("T03");
        submissionMatchResponse.setTransactionId(tidBean.getTransactionId());
        submissionMatchResponse.setResultRemarks(
            "3a -> Match by Approved TID found in persistent data"
                + (isLocalAmount ? " with Local amount" : ""));
        submissionMatchResponse.setAuthUniqueIdentifer(tidBean.getAuthUniqueIdentifier());
        submissionMatchResponse.setCacheKey(tidBean.getCacheStringKey());
        submissionMatchResponse.setCacheName(AuthMatchConstants.CAS_AUTH_TID_CM_CACHE);
        submissionMatchResponse.setDac6CardKey(tidBean.getCardDac6PrimaryKey());
        submissionMatchResponse.setDac2CardKey(tidBean.getCardDac2PrimaryKey());
        submissionMatchResponse.setTidCardKey(tidBean.getCacheStringKey());
        submissionMatchResponse.setAuthSeNumber(tidBean.getSeNumber());

        LOGGER.debug(
            "{}|Match by Approved TID and Amount found in persistent data",
            authMatchLog.getCommonLogAttributes("S", "GR0011"),
            ITier.REQUESTHANDLER,
            CLASS_NAME,
            CLASS_NAME);
      }

      if (!rocMatched && tidBean != null) {
        submissionMatchResponse = matchByTier3b(rocMatchRequest, submissionMatchResponse, tidBean);
        if (submissionMatchResponse.getRamIndicator() != null
            && submissionMatchResponse.getRamIndicator().equals("1")) rocMatched = true;
      }

      IndustryLeverageBean industryLeverage =
          IndustryLeverage.getIndustryLeverageData(rocMatchRequest.getSocSEIndustryCategoryCode());

      // Match with Tier 3c logic
      if (!rocMatched && tidBean != null) {

        // Compare Auth amount with lower and high multiplier by SE Industry leverage code
        if (tidBean
                    .getAuthAmountUSD()
                    .compareTo(rocAmount.multiply(industryLeverage.getLowerMultiplier()))
                >= 0
            && tidBean
                    .getAuthAmountUSD()
                    .compareTo(rocAmount.multiply(industryLeverage.getHigherMultiplier()))
                <= 0) {
          rocMatched = true;
          submissionMatchResponse.setResultRemarks(
              "3c.1 -> Match by CM and industry leverage found in persitent data"
                  + (isLocalAmount ? " with Local amount" : ""));
        }

        // If above criteria not matched, then check if Roc Amount - Auth Amount < 100
        BigDecimal amountDifference = rocAmount.subtract(tidBean.getAuthAmountUSD());
        if (!rocMatched && (amountDifference.compareTo(new BigDecimal(100)) <= 0)) {
          rocMatched = true;
          submissionMatchResponse.setResultRemarks(
              "3c.2 -> Match by CM and ROC Amount - CAS Amount <= 100 found in persitent data"
                  + (isLocalAmount ? " with Local amount" : ""));
        }

        // If 3c.1 or 3c.2 matched
        if (rocMatched) {
          tidBean.setRocAuthMatchedCriteriaId("T03");
          tidBean.setRocAuthMatchedFlag("Y");
        }

        if (rocMatched) {
          submissionMatchResponse.setCaspKey(tidBean.getAuthUniqueIdentifier());
          submissionMatchResponse.setRamIndicator("1");
          submissionMatchResponse.setAuthUniqueIdentifer(tidBean.getAuthUniqueIdentifier());
          submissionMatchResponse.setRamTier("T03");
          submissionMatchResponse.setTransactionId(tidBean.getTransactionId());
          submissionMatchResponse.setResultRemarks(
              "3c -> Match by CM and industry leverage found in persistent data"
                  + (isLocalAmount ? " with Local amount" : ""));
          submissionMatchResponse.setCacheKey(tidBean.getCacheStringKey());
          submissionMatchResponse.setCacheName(AuthMatchConstants.CAS_AUTH_TID_CM_CACHE);
          submissionMatchResponse.setDac6CardKey(tidBean.getCardDac6PrimaryKey());
          submissionMatchResponse.setDac2CardKey(tidBean.getCardDac2PrimaryKey());
          submissionMatchResponse.setTidCardKey(tidBean.getCacheStringKey());

          submissionMatchResponse.setPosDataCode(tidBean.getPosDataCode());
          submissionMatchResponse.setEciIndicator(tidBean.getEciIndicator());
          submissionMatchResponse.setApprovalCode(approvalCode);
          submissionMatchResponse.setMcc(tidBean.getMccMerchant());
          submissionMatchResponse.setVoiceAuthIndicator(tidBean.getVoiceAuthIndicator());
          submissionMatchResponse.setRejIndicator("");
          submissionMatchResponse.setAuthSeNumber(tidBean.getSeNumber());
          submissionMatchResponse.setEcbCreationTime(
              tidBean.getTransactionTimeStamp() != null
                  ? AuthMatchUtil.getStringFromDate(
                      tidBean.getTransactionTimeStamp(), AuthMatchUtil.MX_AUTH_DATE_TIME_FORMAT)
                  : "");
          submissionMatchResponse.setRocAuthDAC(rocMatchRequest.getRocAuthDAC());
          submissionMatchResponse.setRocCardNumber(rocMatchRequest.getRocCardNumber());
          submissionMatchResponse.setRocSENumber(rocMatchRequest.getRocSENumber());
        }
      }

    } catch (Exception e) {
      rocMatched = false;
    }
    submissionMatchResponse.setMatched(rocMatched);
    return submissionMatchResponse;
  }

  public SubmissionMatchResponse matchByTier3b(
      RocMatchRequest rocMatchRequest,
      SubmissionMatchResponse submissionMatchResponse,
      CasAuthTransIdCardCacheBean transCardBean) {
    boolean rocMatched = false;
    BigDecimal rocLocalAmount = null;
    BigDecimal rocAmount = null;
    BigDecimal authAmount = null;
    String approvalCode = "";
    boolean isLocalAmount = false;

    try {
      if (rocMatchRequest.getRocLocalAmount() != null
          && rocMatchRequest.getRocLocalDecimalPlaces() != null) {
        Double localDecimalPlaces = Double.valueOf(rocMatchRequest.getRocLocalDecimalPlaces());
        Double localamount =
            (Double.valueOf(rocMatchRequest.getRocLocalAmount())
                / (((int) Math.pow(10, localDecimalPlaces))));
        if (org.apache.commons.lang.StringUtils.isNotEmpty(
            rocMatchRequest.getRocLocalDecimalPlaces())) {
          rocLocalAmount = new BigDecimal(localamount.toString());
        } else {
          rocLocalAmount = new BigDecimal(localamount).setScale(2, RoundingMode.FLOOR);
        }
      }

      if (transCardBean != null) {
        String[] dac6Key = transCardBean.getCardDac6PrimaryKey().split("\\|", 5);
        if (dac6Key.length > 0) approvalCode = dac6Key[1];
        if (rocLocalAmount != null && transCardBean.getAuthAmountLocal() != null) {
          rocAmount = rocLocalAmount;
          authAmount = transCardBean.getAuthAmountLocal();
          isLocalAmount = true;
        } else {
          rocAmount = new BigDecimal(rocMatchRequest.getRocAmountUSD());
          authAmount = transCardBean.getAuthAmountUSD();
        }
      }

      // Match with Tier 3b logic
      if (transCardBean != null && authAmount.compareTo(rocAmount) < 0) {
        BigDecimal difference = rocAmount.subtract(authAmount);
        ResultSet resultSet = authMatchDAOImpl.getCasAuthByCardAndSe(rocMatchRequest, "A");
        int numberOfMatchingRows = 0;
        BigDecimal authAmountFromDB = BigDecimal.ZERO;
        BigDecimal authAmountFromDBTemp = BigDecimal.ZERO;
        String rocAmountFromRocReq = null;
        String transId = null;
        String dac6Key = null;
        String dac2Key = null;
        Iterator<Row> iterator = resultSet.iterator();
        while (iterator.hasNext()) {
          Row row = iterator.next();

          if (isLocalAmount) {
            authAmountFromDBTemp = row.getDecimal("auth_loc_am");
            rocAmountFromRocReq = rocMatchRequest.getRocLocalAmount();
          } else {
            authAmountFromDBTemp = row.getDecimal("auth_usd_am");
            rocAmountFromRocReq = rocMatchRequest.getRocAmountUSD();
          }
          transId = row.getString("trans_id");
          dac6Key = row.getString("card_6dac_cache_key");
          dac2Key = row.getString("card_2dac_cache_key");

          Date authTranDateTime = row.getTimestamp("auth_ts");
          String rocMatchedFlag = row.getString("auth_mtch_in");
          simpleDateFormat.setLenient(false);
          String authDateTime = simpleDateFormat.format(authTranDateTime);

          if (authDateTime.equals(rocMatchRequest.getRocTransactionDate())
              && !transId.equals(rocMatchRequest.getRocAuthorizationTransactionId())
              && authAmountFromDBTemp.compareTo(new BigDecimal(rocAmountFromRocReq)) < 0
              && !rocMatchedFlag.equals("Y")) {
            numberOfMatchingRows++;
            if (isLocalAmount) {
              authAmountFromDB = row.getDecimal("auth_loc_am");
            } else {
              authAmountFromDB = row.getDecimal("auth_usd_am");
            }
          }
        }
        if (numberOfMatchingRows == 1) {
          String cacheKey1 =
              transId
                  + "|"
                  + transCardBean.getCardNumber()
                  + "|"
                  + transCardBean.getApproveDenyCode();
          if (difference.compareTo(authAmountFromDB) == 0) {
            LOGGER.debug(
                "{}|Match by Approved TID and Amount found in persistent data",
                authMatchLog.getCommonLogAttributes("S", "GR0011"),
                ITier.REQUESTHANDLER,
                CLASS_NAME,
                CLASS_NAME);

            // Match by 3b
            rocMatched = true;
            transCardBean.setRocAuthMatchedCriteriaId("T03");
            submissionMatchResponse.setRamIndicator("1");
            submissionMatchResponse.setRamTier("T03");
            submissionMatchResponse.setTransactionId(transCardBean.getTransactionId());
            submissionMatchResponse.setResultRemarks(
                "3b -> Match by CM, SE and CAS Date found in persistent data"
                    + (isLocalAmount ? " with Local amount" : ""));
            submissionMatchResponse.setCaspKey(transCardBean.getAuthUniqueIdentifier());
            submissionMatchResponse.setAuthUniqueIdentifer(transCardBean.getAuthUniqueIdentifier());
            submissionMatchResponse.setCacheKey(transCardBean.getCacheStringKey());
            submissionMatchResponse.setCacheName(AuthMatchConstants.CAS_AUTH_TID_CM_CACHE);
            submissionMatchResponse.setTidCardKey(transCardBean.getCacheStringKey());
            submissionMatchResponse.setTidCardKeysList(
                new ArrayList<String>(Arrays.asList(cacheKey1)));
            submissionMatchResponse.setDac6CardKey(transCardBean.getCardDac6PrimaryKey());
            submissionMatchResponse.setDac6CardKeysList(
                new ArrayList<String>(Arrays.asList(dac6Key)));
            submissionMatchResponse.setDac2CardKey(transCardBean.getCardDac2PrimaryKey());
            submissionMatchResponse.setDac2CardKeysList(
                new ArrayList<String>(Arrays.asList(dac2Key)));
            submissionMatchResponse.setPosDataCode(transCardBean.getPosDataCode());
            submissionMatchResponse.setEciIndicator(transCardBean.getEciIndicator());
            submissionMatchResponse.setApprovalCode(approvalCode);
            submissionMatchResponse.setMcc(transCardBean.getMccMerchant());
            submissionMatchResponse.setVoiceAuthIndicator(transCardBean.getVoiceAuthIndicator());
            submissionMatchResponse.setRejIndicator("");
            submissionMatchResponse.setAuthSeNumber(transCardBean.getSeNumber());
          }
        }
      }
    } catch (Exception e) {
      LOGGER.error(
          "{}| Error in Match by Tier 3b",
          authMatchLog.getCommonLogAttributes("S", "GE000M04", rocMatchRequest),
          ITier.REQUESTHANDLER,
          CLASS_NAME,
          CLASS_NAME);
      rocMatched = false;
    }
    submissionMatchResponse.setMatched(rocMatched);
    return submissionMatchResponse;
  }

  /*
   * 1 -> Set keys for lookup - card number, DAC6 and date without time
   * 2 -> Get records from cache and validate that there is only one record before update
   * 				TO DO - Handle the scenario of multiple records
   * 3 -> Get CardAuthCache key, DAC6 key and DAC2 key to be removed if match is success
   * 4 -> Match for level 4 criteria - same CM15, same APPROVAL_CD, same SE10* and CAS transaction date between (-7, +1) of ROC charge date and Amount leverage**
   * 5 -> Run update statement to update flag if matched
   * 6 -> If match level 4 is not successful then match for level 5 criteria -
   * 				same CM15, same APPROVAL_CD and CAS transaction date between (-7, +1) of ROC charge date and Amount leverage**
   * 7 -> Run update statement to update flag if matched
   */
  public SubmissionMatchResponse matchByCardDac6AndAmoutLeverageSEDate(
      RocMatchRequest rocMatchRequest, SubmissionMatchResponse submissionMatchResponse) {
    boolean rocMatched = false;
    BigDecimal rocLocalAmount = null;
    Date authDateTime = new Date();
    String dac6Key = "";
    String sql = "";
    BigDecimal rocAmount = null;
    BigDecimal authAmount = null;
    boolean isLocalAmount = false;

    try {
      if (rocMatchRequest.getRocLocalAmount() != null
          && rocMatchRequest.getRocLocalDecimalPlaces() != null) {
        Double localDecimalPlaces = Double.valueOf(rocMatchRequest.getRocLocalDecimalPlaces());
        Double localamount =
            (Double.valueOf(rocMatchRequest.getRocLocalAmount())
                / (((int) Math.pow(10, localDecimalPlaces))));
        if (org.apache.commons.lang.StringUtils.isNotEmpty(
            rocMatchRequest.getRocLocalDecimalPlaces())) {
          rocLocalAmount = new BigDecimal(localamount.toString());
        } else {
          rocLocalAmount = new BigDecimal(localamount).setScale(2, RoundingMode.FLOOR);
        }
      }
    } catch (Exception e) {
    }

    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    try {
      IndustryLeverageBean industryLeverage =
          IndustryLeverage.getIndustryLeverageData(rocMatchRequest.getSocSEIndustryCategoryCode());
      // 1 -> Set keys for lookup - card number, DAC6 and date without time
      CasAuthCardAccessCode6CacheBean cardDac6Bean =
          authMatchDAOImpl.getAuthByDac6AndSe6(rocMatchRequest, "A");

      if (cardDac6Bean != null) {
        dac6Key = cardDac6Bean.getCacheStringKey();
        if (rocLocalAmount != null && cardDac6Bean.getAuthAmountLocal() != null) {
          rocAmount = rocLocalAmount;
          authAmount = cardDac6Bean.getAuthAmountLocal();
          isLocalAmount = true;
        } else {
          rocAmount = new BigDecimal(rocMatchRequest.getRocAmountUSD());
          authAmount = cardDac6Bean.getAuthAmountUSD();
        }
      }

      try {
        if (StringUtils.isEmpty(
            StringUtils.trimTrailingWhitespace(rocMatchRequest.getRocTransactionTime()))) {
          rocMatchRequest.setRocTransactionTime("00:00:00");
        }
        sdf.setLenient(false);
        authDateTime =
            sdf.parse(
                rocMatchRequest.getRocTransactionDate()
                    + " "
                    + rocMatchRequest.getRocTransactionTime());
      } catch (ParseException e1) {
        LOGGER.error(
            "{}|Date parse exception in matchByCardDac6AndAmoutLeverageSEDate {} ,  {} ",
            authMatchLog.getCommonLogAttributes("S", "GR5021", rocMatchRequest),
            e1.getMessage(),
            e1);
        try {
          authDateTime = dateFormat.parse("1900-01-01 00:00:00");
        } catch (ParseException e) {
        }
      }
      LocalDateTime localDateTime =
          authDateTime.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
      Date fromDate =
          Date.from(localDateTime.minusDays(7).atZone(ZoneId.systemDefault()).toInstant());
      Date toDate = Date.from(localDateTime.plusDays(1).atZone(ZoneId.systemDefault()).toInstant());

      // 4 -> Match for level 4 criteria - same CM15, same APPROVAL_CD, same SE10* and CAS
      // transaction date between (-7, +1) of ROC charge date and Amount leverage**

      if (rocMatchRequest.getRocSENumber() != null
          && isSEEquals(rocMatchRequest.getRocSENumber(), cardDac6Bean.getSeNumber())
          && cardDac6Bean.getAuthTransactionDateTime() != null
          && cardDac6Bean.getAuthTransactionDateTime().after(fromDate)
          && cardDac6Bean.getAuthTransactionDateTime().before(toDate)
          && rocAmount != null
          && (rocAmount.compareTo(authAmount.multiply(industryLeverage.getLowerMultiplier())) >= 0)
          && (rocAmount.compareTo(authAmount.multiply(industryLeverage.getHigherMultiplier()))
              <= 0)) {

        LOGGER.debug(
            "{}|Match by card,SE DAC6 found, amount leverage and date found in persistent data",
            authMatchLog.getCommonLogAttributes("S", "GR0111"),
            ITier.REQUESTHANDLER,
            CLASS_NAME,
            CLASS_NAME);
        submissionMatchResponse.setMatched(rocMatched);
        submissionMatchResponse.setRamIndicator("1");
        submissionMatchResponse.setRamTier("T04");
        submissionMatchResponse.setResultRemarks(
            "4 -> Match by DAC6, Approval code, SE10, CAS date and amount leverage found in persistent data"
                + (isLocalAmount ? " with Local amount" : ""));

        rocMatched = true;
      }

      // 6 -> Match for level 5 criteria - same CM15, same APPROVAL_CD, and CAS transaction date
      // between (-7, +1) of ROC charge date and Amount leverage**

      if (!rocMatched
          && cardDac6Bean.getAuthTransactionDateTime() != null
          && cardDac6Bean.getAuthTransactionDateTime().after(fromDate)
          && cardDac6Bean.getAuthTransactionDateTime().before(toDate)
          && rocAmount != null
          && (rocAmount.compareTo(authAmount.multiply(industryLeverage.getLowerMultiplier())) >= 0)
          && (rocAmount.compareTo(authAmount.multiply(industryLeverage.getHigherMultiplier()))
              <= 0)) {

        // 7 -> Run update statement to update flag if matched
        sql = AuthMatchConstants.updateDac6AMatched;
        sql = String.format(sql, dac6Key);

        LOGGER.debug(
            "{}|Match by card,SE DAC6 found, amount leverage and date found in persistent data",
            authMatchLog.getCommonLogAttributes("S", "GR0001"),
            ITier.REQUESTHANDLER,
            CLASS_NAME,
            CLASS_NAME);
        submissionMatchResponse.setMatched(rocMatched);
        submissionMatchResponse.setRamIndicator("1");
        submissionMatchResponse.setRamTier("T05");
        submissionMatchResponse.setResultRemarks(
            "5 -> Match by DAC6, Approval code, CAS date and amount leverage found in persistent data"
                + (isLocalAmount ? " with Local amount" : ""));
        rocMatched = true;
      }

      if (rocMatched) {
        submissionMatchResponse.setCaspKey(cardDac6Bean.getAuthUniqueIdentifier());
        submissionMatchResponse.setCacheKey(dac6Key);
        submissionMatchResponse.setCacheName(AuthMatchConstants.CAS_AUTH_CM_DAC6_CACHE);
        submissionMatchResponse.setDac6CardKey(dac6Key);
        submissionMatchResponse.setTidCardKey(cardDac6Bean.getTidCMPrimaryKey());
        submissionMatchResponse.setDac2CardKey(cardDac6Bean.getCardDac2PrimaryKey());
        submissionMatchResponse.setAuthSeNumber(cardDac6Bean.getSeNumber());
        submissionMatchResponse.setAuthUniqueIdentifer(cardDac6Bean.getAuthUniqueIdentifier());

        String[] keyList = cardDac6Bean.getTidCMPrimaryKey().split("\\|");
        if (keyList.length == 3) {
          CasAuthTransIdCardCacheBean transCardBean =
              authMatchDAOImpl.getTransByTidData(rocMatchRequest, "A");
          if (transCardBean != null) {
            submissionMatchResponse.setPosDataCode(transCardBean.getPosDataCode());
            submissionMatchResponse.setEciIndicator(transCardBean.getEciIndicator());
            submissionMatchResponse.setApprovalCode(cardDac6Bean.getAuth6Dac());
            submissionMatchResponse.setMcc(transCardBean.getMccMerchant());
            submissionMatchResponse.setVoiceAuthIndicator(transCardBean.getVoiceAuthIndicator());
            submissionMatchResponse.setTransactionId(transCardBean.getTransactionId());
            submissionMatchResponse.setEcbCreationTime(
                transCardBean.getTransactionTimeStamp() != null
                    ? AuthMatchUtil.getStringFromDate(
                        transCardBean.getTransactionTimeStamp(),
                        AuthMatchUtil.MX_AUTH_DATE_TIME_FORMAT)
                    : "");
            submissionMatchResponse.setRocAuthDAC(rocMatchRequest.getRocAuthDAC());
            submissionMatchResponse.setRocCardNumber(rocMatchRequest.getRocCardNumber());
            submissionMatchResponse.setRocSENumber(rocMatchRequest.getRocSENumber());
          }
        }

        submissionMatchResponse.setRejIndicator("");
      }

    } catch (Exception e) {
      rocMatched = false;
    }
    submissionMatchResponse.setMatched(rocMatched);
    return submissionMatchResponse;
  }

  /*
   * 1 -> Set keys for lookup - card number, DAC2 and date without time
   * 2 -> Get records from cache and validate that there is only one record before update
   * 				TO DO - Handle the scenario of multiple records
   * 3 -> Get CardAuthCache key, DAC6 key and DAC2 key to be removed if match is success
   * 4 -> Match for level 4 criteria - same CM15, same APPROVAL_CD, same SE10* and CAS transaction date between (-7, +1) of ROC charge date and Amount leverage**
   * 5 -> Run update statement to update flag if matched
   * 6 -> If match level 4 is not successful then match for level 5 criteria -
   * 				same CM15, same APPROVAL_CD and CAS transaction date between (-7, +1) of ROC charge date and Amount leverage**
   * 7 -> Run update statement to update flag if matched
   */
  public SubmissionMatchResponse matchByCardDac2AndAmoutLeverageSEDate(
      RocMatchRequest rocMatchRequest, SubmissionMatchResponse submissionMatchResponse) {
    boolean rocMatched = false;
    Date authDateTime = new Date();
    String dac2Key = "";
    String sql = "";
    BigDecimal rocLocalAmount = null;
    BigDecimal rocAmount = null;
    BigDecimal authAmount = null;
    boolean isLocalAmount = false;

    try {
      if (rocMatchRequest.getRocLocalAmount() != null
          && rocMatchRequest.getRocLocalDecimalPlaces() != null) {
        Double localDecimalPlaces = Double.valueOf(rocMatchRequest.getRocLocalDecimalPlaces());
        Double localamount =
            (Double.valueOf(rocMatchRequest.getRocLocalAmount())
                / (((int) Math.pow(10, localDecimalPlaces))));
        if (org.apache.commons.lang.StringUtils.isNotEmpty(
            rocMatchRequest.getRocLocalDecimalPlaces())) {
          rocLocalAmount = new BigDecimal(localamount.toString());
        } else {
          rocLocalAmount = new BigDecimal(localamount).setScale(2, RoundingMode.FLOOR);
        }
      }
    } catch (Exception e) {
    }

    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    try {
      IndustryLeverageBean industryLeverage =
          IndustryLeverage.getIndustryLeverageData(rocMatchRequest.getSocSEIndustryCategoryCode());
      // 1 -> Set keys for lookup - card number, DAC2 and date without time
      CasAuthCardAccessCode2CacheBean cardDac2Bean =
          authMatchDAOImpl.getAuthByDac2AndSe6(rocMatchRequest, "A");

      if (cardDac2Bean != null) {
        dac2Key = cardDac2Bean.getCacheStringKey();
        if (rocLocalAmount != null && cardDac2Bean.getAuthAmountLocal() != null) {
          rocAmount = rocLocalAmount;
          authAmount = cardDac2Bean.getAuthAmountLocal();
          isLocalAmount = true;
        } else {
          rocAmount = new BigDecimal(rocMatchRequest.getRocAmountUSD());
          authAmount = cardDac2Bean.getAuthAmountUSD();
        }
      }

      try {
        if (StringUtils.isEmpty(
            StringUtils.trimTrailingWhitespace(rocMatchRequest.getRocTransactionTime()))) {
          rocMatchRequest.setRocTransactionTime("00:00:00");
        }
        sdf.setLenient(false);
        authDateTime =
            sdf.parse(
                rocMatchRequest.getRocTransactionDate()
                    + " "
                    + rocMatchRequest.getRocTransactionTime());
      } catch (ParseException e1) {
        LOGGER.error(
            "{}|Date parse exception in matchByCardDac2AndAmoutLeverageSEDate {} ,  {} ",
            authMatchLog.getCommonLogAttributes("S", "GR5021", rocMatchRequest),
            e1.getMessage(),
            e1);
        try {
          authDateTime = dateFormat.parse("1900-01-01 00:00:00");
        } catch (ParseException e) {
        }
      }
      LocalDateTime localDateTime =
          authDateTime.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
      Date fromDate =
          Date.from(localDateTime.minusDays(7).atZone(ZoneId.systemDefault()).toInstant());
      Date toDate = Date.from(localDateTime.plusDays(1).atZone(ZoneId.systemDefault()).toInstant());

      // 4 -> Match for level 6 criteria - same CM15, same APPROVAL_CD, same SE10* and CAS
      // transaction date between (-7, +1) of ROC charge date and Amount leverage**

      if (rocMatchRequest.getRocSENumber() != null
          && isSEEquals(rocMatchRequest.getRocSENumber(), cardDac2Bean.getSeNumber())
          && cardDac2Bean.getAuthTransactionDateTime() != null
          && cardDac2Bean.getAuthTransactionDateTime().after(fromDate)
          && cardDac2Bean.getAuthTransactionDateTime().before(toDate)
          && rocAmount != null
          && (rocAmount.compareTo(authAmount.multiply(industryLeverage.getLowerMultiplier())) >= 0)
          && (rocAmount.compareTo(authAmount.multiply(industryLeverage.getHigherMultiplier()))
              <= 0)) {

        LOGGER.debug(
            "{}|Match by card,SE DAC2 found, amount leverage and date found in persistent data",
            authMatchLog.getCommonLogAttributes("S", "GR0111"),
            ITier.REQUESTHANDLER,
            CLASS_NAME,
            CLASS_NAME);
        submissionMatchResponse.setMatched(rocMatched);
        submissionMatchResponse.setRamIndicator("1");
        submissionMatchResponse.setRamTier("T06");
        submissionMatchResponse.setResultRemarks(
            "6 -> Match by DAC2, Approval code, SE10, CAS date and amount leverage found in persistent data"
                + (isLocalAmount ? " with Local amount" : ""));

        rocMatched = true;
      }

      // 7 -> Match for level 7 criteria - same CM15, same APPROVAL_CD, and CAS transaction date
      // between (-7, +1) of ROC charge date and Amount leverage**

      if (!rocMatched
          && cardDac2Bean.getAuthTransactionDateTime() != null
          && cardDac2Bean.getAuthTransactionDateTime().after(fromDate)
          && cardDac2Bean.getAuthTransactionDateTime().before(toDate)
          && rocAmount != null
          && (rocAmount.compareTo(authAmount.multiply(industryLeverage.getLowerMultiplier())) >= 0)
          && (rocAmount.compareTo(authAmount.multiply(industryLeverage.getHigherMultiplier()))
              <= 0)) {
        // 7 -> Run update statement to update flag if matched

        LOGGER.debug(
            "{}|Match by card,SE DAC2 found, amount leverage and date found in persistent data",
            authMatchLog.getCommonLogAttributes("S", "GR0001"),
            ITier.REQUESTHANDLER,
            CLASS_NAME,
            CLASS_NAME);
        submissionMatchResponse.setMatched(rocMatched);
        submissionMatchResponse.setRamIndicator("1");
        submissionMatchResponse.setRamTier("T07");
        submissionMatchResponse.setResultRemarks(
            "7 -> Match by DAC2, Approval code, CAS date and amount leverage found in persistent data"
                + (isLocalAmount ? " with Local amount" : ""));
        rocMatched = true;
      }

      if (rocMatched) {
        submissionMatchResponse.setCaspKey(cardDac2Bean.getAuthUniqueIdentifier());
        submissionMatchResponse.setCacheKey(dac2Key);
        submissionMatchResponse.setCacheName(AuthMatchConstants.CAS_AUTH_CM_DAC2_CACHE);
        submissionMatchResponse.setDac2CardKey(dac2Key);
        submissionMatchResponse.setTidCardKey(cardDac2Bean.getTidCMPrimaryKey());
        submissionMatchResponse.setDac6CardKey(cardDac2Bean.getCardDac6PrimaryKey());
        submissionMatchResponse.setAuthSeNumber(cardDac2Bean.getSeNumber());
        submissionMatchResponse.setAuthUniqueIdentifer(cardDac2Bean.getAuthUniqueIdentifier());

        String[] keyList = cardDac2Bean.getTidCMPrimaryKey().split("\\|");
        if (keyList.length == 3) {
          CasAuthTransIdCardCacheBean transCardBean =
              authMatchDAOImpl.getTransByTidData(rocMatchRequest, "A");

          if (transCardBean != null) {
            submissionMatchResponse.setPosDataCode(transCardBean.getPosDataCode());
            submissionMatchResponse.setEciIndicator(transCardBean.getEciIndicator());
            submissionMatchResponse.setApprovalCode(cardDac2Bean.getAuth2Dac());
            submissionMatchResponse.setMcc(transCardBean.getMccMerchant());
            submissionMatchResponse.setVoiceAuthIndicator(transCardBean.getVoiceAuthIndicator());
            submissionMatchResponse.setTransactionId(transCardBean.getTransactionId());
            submissionMatchResponse.setEcbCreationTime(
                transCardBean.getTransactionTimeStamp() != null
                    ? AuthMatchUtil.getStringFromDate(
                        transCardBean.getTransactionTimeStamp(),
                        AuthMatchUtil.MX_AUTH_DATE_TIME_FORMAT)
                    : "");
            submissionMatchResponse.setRocAuthDAC(rocMatchRequest.getRocAuthDAC());
            submissionMatchResponse.setRocCardNumber(rocMatchRequest.getRocCardNumber());
            submissionMatchResponse.setRocSENumber(rocMatchRequest.getRocSENumber());
          }
        }

        submissionMatchResponse.setRejIndicator("");
      }

    } catch (Exception e) {
      rocMatched = false;
    }
    submissionMatchResponse.setMatched(rocMatched);
    return submissionMatchResponse;
  }

  public SubmissionMatchResponse matchByTier9(
      RocMatchRequest rocMatchRequest, SubmissionMatchResponse submissionMatchResponse) {
    boolean rocMatched = false;
    BigDecimal rocLocalAmount = null;
    BigDecimal rocAmount = null;
    BigDecimal authAmount = null;
    boolean isLocalAmount = false;
    BigDecimal lowerMultiplier = BigDecimal.valueOf(0);
    BigDecimal higherMultiplier = BigDecimal.valueOf(0);

    try {
      if (rocMatchRequest.getRocLocalAmount() != null
          && rocMatchRequest.getRocLocalDecimalPlaces() != null) {
        Double localDecimalPlaces = Double.valueOf(rocMatchRequest.getRocLocalDecimalPlaces());
        Double localamount =
            (Double.valueOf(rocMatchRequest.getRocLocalAmount())
                / (((int) Math.pow(10, localDecimalPlaces))));
        if (org.apache.commons.lang.StringUtils.isNotEmpty(
            rocMatchRequest.getRocLocalDecimalPlaces())) {
          rocLocalAmount = new BigDecimal(localamount.toString());
        } else {
          rocLocalAmount = new BigDecimal(localamount).setScale(2, RoundingMode.FLOOR);
        }
      }
    } catch (Exception e) {
    }

    try {
      IndustryLeverageBean industryLeverage =
          IndustryLeverage.getIndustryLeverageData(rocMatchRequest.getSocSEIndustryCategoryCode());

      if (industryLeverage != null) {
        lowerMultiplier = industryLeverage.getLowerMultiplier();
        higherMultiplier = industryLeverage.getHigherMultiplier();
      } else LOGGER.error("GR50011 - Industry Leverage cache does not exist or not created ");

      SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
      Date rocDateTime = null;
      try {
        if (StringUtils.isEmpty(
            StringUtils.trimTrailingWhitespace(rocMatchRequest.getRocTransactionTime()))) {
          rocMatchRequest.setRocTransactionTime("00:00:00");
        }
        sdf.setLenient(false);
        rocDateTime =
            sdf.parse(
                rocMatchRequest.getRocTransactionDate()
                    + " "
                    + rocMatchRequest.getRocTransactionTime());
      } catch (ParseException e1) {
        LOGGER.error(
            "{}|Date parse exception in matchByCardDac2AndAmoutLeverageSEDate {} , {} ",
            authMatchLog.getCommonLogAttributes("S", "GR5001", rocMatchRequest),
            e1.getMessage(),
            e1);
        try {
          rocDateTime = dateFormat.parse("1900-01-01 00:00:00");
        } catch (ParseException e) {
        }
      }
      LocalDateTime localDateTime =
          rocDateTime.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
      Date fromDate =
          Date.from(localDateTime.minusDays(1).atZone(ZoneId.systemDefault()).toInstant());
      Date toDate = Date.from(localDateTime.plusDays(1).atZone(ZoneId.systemDefault()).toInstant());

      ResultSet resultSet = authMatchDAOImpl.getCasAuthByCardAndSe(rocMatchRequest, "A");
      Iterator<Row> iterator = resultSet.iterator();
      int numberOfMatchingRows = 0;
      String transId = null;
      String dac6Key = null;
      CasAuthTransIdCardCacheBean transCardBean = null;
      while (iterator.hasNext()) {
        Row row = iterator.next();
        transId = row.getString("trans_id");
        dac6Key = row.getString("card_6dac_cache_key");
        Date authTranDateTime = row.getTimestamp("auth_ts");
        String rocMatchedFlag = row.getString("auth_mtch_in");

        if (transCardBean == null) {
          transCardBean = new CasAuthTransIdCardCacheBean();
          transCardBean.setTransactionId(row.getString("trans_id"));
          transCardBean.setCardNumber(row.getString("cm_15"));
          transCardBean.setApproveDenyCode(row.getString("aprv_deny_cd"));
          transCardBean.setAuthAmountUSD(row.getDecimal("auth_usd_am"));
          transCardBean.setSeNumber(row.getString("auth_se_no"));
          transCardBean.setAuthTransactionDateTime(row.getTimestamp("auth_ts"));
          transCardBean.setAuthAmountLocal(row.getDecimal("auth_loc_am"));
          transCardBean.setCardDac2PrimaryKey(row.getString("card_2dac_cache_key"));
          transCardBean.setCardDac6PrimaryKey(row.getString("card_6dac_cache_key"));
          transCardBean.setRocAuthMatchedFlag(row.getString("auth_mtch_in"));
          transCardBean.setRocAuthMatchedCriteriaId(row.getString("ram_mtch_tier_cd"));
          transCardBean.setAuthUniqueIdentifier(row.getString("cas_pkey"));
        }

        if (authTranDateTime.after(fromDate)
            && authTranDateTime.before(toDate)
            && !rocMatchedFlag.equals("Y")) {
          numberOfMatchingRows++;
        }
      }

      if (numberOfMatchingRows == 1) {
        if (transCardBean != null) {
          if (rocLocalAmount != null && transCardBean.getAuthAmountLocal() != null) {
            rocAmount = rocLocalAmount;
            authAmount = transCardBean.getAuthAmountLocal();
            isLocalAmount = true;
          } else {
            rocAmount = new BigDecimal(rocMatchRequest.getRocAmountUSD());
            authAmount = transCardBean.getAuthAmountUSD();
          }
        }

        if (transCardBean != null
            && (rocAmount.compareTo(authAmount.multiply(lowerMultiplier)) >= 0)
            && (rocAmount.compareTo(authAmount.multiply(higherMultiplier)) <= 0)) {
          rocMatched = true;
          transCardBean.setRocAuthMatchedCriteriaId("T09");
          transCardBean.setRocAuthMatchedFlag("Y");

          submissionMatchResponse.setRamIndicator("1");
          submissionMatchResponse.setRamTier("T09");
          submissionMatchResponse.setTransactionId(transCardBean.getTransactionId());
          submissionMatchResponse.setResultRemarks(
              "9 -> Match by Approved TID and Amount found in persistent data"
                  + (isLocalAmount ? " with Local amount" : ""));
          submissionMatchResponse.setCaspKey(transCardBean.getAuthUniqueIdentifier());
          submissionMatchResponse.setAuthUniqueIdentifer(transCardBean.getAuthUniqueIdentifier());
          submissionMatchResponse.setCacheKey(transCardBean.getCacheStringKey());
          submissionMatchResponse.setCacheName(AuthMatchConstants.CAS_AUTH_TID_CM_CACHE);
          submissionMatchResponse.setTidCardKey(transCardBean.getCacheStringKey());
          submissionMatchResponse.setDac6CardKey(transCardBean.getCardDac6PrimaryKey());
          submissionMatchResponse.setDac2CardKey(transCardBean.getCardDac2PrimaryKey());
          submissionMatchResponse.setPosDataCode(transCardBean.getPosDataCode());
          submissionMatchResponse.setEciIndicator(transCardBean.getEciIndicator());
          submissionMatchResponse.setApprovalCode((dac6Key.split("\\|", 5)[1]).toString());
          submissionMatchResponse.setMcc(transCardBean.getMccMerchant());
          submissionMatchResponse.setVoiceAuthIndicator(transCardBean.getVoiceAuthIndicator());
          submissionMatchResponse.setRejIndicator("");
          submissionMatchResponse.setAuthSeNumber(transCardBean.getSeNumber());
          submissionMatchResponse.setEcbCreationTime(
              transCardBean.getTransactionTimeStamp() != null
                  ? AuthMatchUtil.getStringFromDate(
                      transCardBean.getTransactionTimeStamp(),
                      AuthMatchUtil.MX_AUTH_DATE_TIME_FORMAT)
                  : "");
          submissionMatchResponse.setRocAuthDAC(rocMatchRequest.getRocAuthDAC());
          submissionMatchResponse.setRocCardNumber(rocMatchRequest.getRocCardNumber());
          submissionMatchResponse.setRocSENumber(rocMatchRequest.getRocSENumber());
        }
      }
    } catch (Exception e) {
      LOGGER.error(
          "{}| Error in Match by Tier 9",
          authMatchLog.getCommonLogAttributes("S", "GE000M09", rocMatchRequest),
          ITier.REQUESTHANDLER,
          CLASS_NAME,
          CLASS_NAME);
      rocMatched = false;
    }
    submissionMatchResponse.setMatched(rocMatched);
    return submissionMatchResponse;
  }

  private boolean isSEEquals(String rocSE, String authSE) {
    if (authSE.equals(rocSE)) {
      return true;
    }

    if (rocAuthSeSubmissionHistoryDAO != null
        && rocAuthSeSubmissionHistoryDAO.isRocAuthSEHistoryPresent(
            new RocAuthSEHistoryKey(rocSE, authSE))) {
      return true;
    }
    return false;
  }

  public RocAuthMatchResult getMatchResult(String rocArn) {
    // TODO Auto-generated method stub
    RocAuthMatchResult results = new RocAuthMatchResult();
    try {
      results = authMatchDAOImpl.getMatchResult(rocArn);
    } catch (ParseException e1) {
      LOGGER.error(
          "{}|Date parse exception in getMatchResult {} , {} ",
          authMatchLog.getCommonLogAttributes("S", "GR5006"),
          e1.getMessage(),
          e1);
    }
    return results;
  }

  public SubmissionMatchResponse matchByTier11(
      RocMatchRequest rocMatchRequest, SubmissionMatchResponse submissionMatchResponse) {
    boolean rocMatched = false;
    Date authDateTime = null;
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    BigDecimal rocLocalAmount = null;
    BigDecimal rocAmount = null;
    BigDecimal authAmount = null;
    boolean isLocalAmount = false;

    try {
      if (rocMatchRequest.getRocLocalAmount() != null
          && rocMatchRequest.getRocLocalDecimalPlaces() != null) {
        Double localDecimalPlaces = Double.valueOf(rocMatchRequest.getRocLocalDecimalPlaces());
        Double localamount =
            (Double.valueOf(rocMatchRequest.getRocLocalAmount())
                / (((int) Math.pow(10, localDecimalPlaces))));
        if (org.apache.commons.lang.StringUtils.isNotEmpty(
            rocMatchRequest.getRocLocalDecimalPlaces())) {
          rocLocalAmount = new BigDecimal(localamount.toString());
        } else {
          rocLocalAmount = new BigDecimal(localamount).setScale(2, RoundingMode.FLOOR);
        }
      }
    } catch (Exception e) {
    }

    try {
      if (StringUtils.isEmpty(
          StringUtils.trimTrailingWhitespace(rocMatchRequest.getRocTransactionTime()))) {
        rocMatchRequest.setRocTransactionTime("00:00:00");
      }
      sdf.setLenient(false);
      authDateTime =
          sdf.parse(
              rocMatchRequest.getRocTransactionDate()
                  + " "
                  + rocMatchRequest.getRocTransactionTime());
    } catch (ParseException e1) {
      LOGGER.error(
          "{}|Date parse exception in matchByCardNumberAndSeNumber {} , {} ",
          authMatchLog.getCommonLogAttributes("S", "GR5011", rocMatchRequest),
          e1.getMessage(),
          e1);
      try {
        authDateTime = dateFormat.parse("1900-01-01 00:00:00");
      } catch (ParseException e) {
      }
    }

    try {
      LocalDateTime localDateTime =
          authDateTime.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();

      Date fromDate =
          Date.from(localDateTime.minusDays(7).atZone(ZoneId.systemDefault()).toInstant());
      Date toDate = Date.from(localDateTime.plusDays(1).atZone(ZoneId.systemDefault()).toInstant());

      BigDecimal fromAmountValue = null;
      BigDecimal toAmountValue = null;

      ResultSet resultSet = authMatchDAOImpl.getCasAuthByCardAndSe(rocMatchRequest, "A");
      Iterator<Row> iterator = resultSet.iterator();
      int numberOfMatchingRows = 0;
      String transId = null;
      String dac6Key = null;
      CasAuthTransIdCardCacheBean transCardBean = null;
      while (iterator.hasNext()) {
        Row row = iterator.next();

        if (transCardBean == null) {
          transCardBean = new CasAuthTransIdCardCacheBean();
          transCardBean.setTransactionId(row.getString("trans_id"));
          transCardBean.setCardNumber(row.getString("cm_15"));
          transCardBean.setApproveDenyCode(row.getString("aprv_deny_cd"));
          transCardBean.setAuthAmountUSD(row.getDecimal("auth_usd_am"));
          transCardBean.setSeNumber(row.getString("auth_se_no"));
          transCardBean.setAuthTransactionDateTime(row.getTimestamp("auth_ts"));
          transCardBean.setAuthAmountLocal(row.getDecimal("auth_loc_am"));
          transCardBean.setCardDac2PrimaryKey(row.getString("card_2dac_cache_key"));
          transCardBean.setCardDac6PrimaryKey(row.getString("card_6dac_cache_key"));
          transCardBean.setRocAuthMatchedFlag(row.getString("auth_mtch_in"));
          transCardBean.setRocAuthMatchedCriteriaId(row.getString("ram_mtch_tier_cd"));
          transCardBean.setAuthUniqueIdentifier(row.getString("cas_pkey"));
        }

        if (rocLocalAmount != null && transCardBean.getAuthAmountLocal() != null) {
          rocAmount = rocLocalAmount;
          authAmount = transCardBean.getAuthAmountLocal();
          isLocalAmount = true;
        } else {
          rocAmount = new BigDecimal(rocMatchRequest.getRocAmountUSD());
          authAmount = transCardBean.getAuthAmountUSD();
        }

        Date authTranDateTime = row.getTimestamp("auth_ts");

        if (authAmount != null) {
          fromAmountValue = authAmount.multiply(new BigDecimal(0.75));
          toAmountValue = authAmount.multiply(new BigDecimal(1.25));
        }

        if (authTranDateTime.after(fromDate)
            && authTranDateTime.before(toDate)
            && rocAmount.compareTo(fromAmountValue) >= 0
            && rocAmount.compareTo(toAmountValue) <= 0) {
          numberOfMatchingRows++;
        }
      }

      if (numberOfMatchingRows == 1) {
        rocMatched = true;
        transCardBean.setRocAuthMatchedCriteriaId("T11");
        transCardBean.setRocAuthMatchedFlag("Y");
        String[] approvalCode = transCardBean.getCardDac6PrimaryKey().split("\\|", 5);

        submissionMatchResponse.setCaspKey(transCardBean.getAuthUniqueIdentifier());
        submissionMatchResponse.setAuthUniqueIdentifer(transCardBean.getAuthUniqueIdentifier());
        submissionMatchResponse.setPosDataCode(transCardBean.getPosDataCode());
        submissionMatchResponse.setEciIndicator(transCardBean.getEciIndicator());
        submissionMatchResponse.setApprovalCode(approvalCode[1]);
        submissionMatchResponse.setMcc(transCardBean.getMccMerchant());
        submissionMatchResponse.setVoiceAuthIndicator(transCardBean.getVoiceAuthIndicator());
        submissionMatchResponse.setRejIndicator("");
        submissionMatchResponse.setRamIndicator("1");
        submissionMatchResponse.setRamTier("T11");
        submissionMatchResponse.setTransactionId(transCardBean.getTransactionId());
        submissionMatchResponse.setResultRemarks(
            "11 -> Match by Card number and SE number found in persistent data"
                + (isLocalAmount ? " with Local amount" : ""));

        submissionMatchResponse.setCacheKey(transCardBean.getCacheStringKey());
        submissionMatchResponse.setCacheName(AuthMatchConstants.CAS_AUTH_TID_CM_CACHE);
        submissionMatchResponse.setTidCardKey(transCardBean.getCacheStringKey());
        submissionMatchResponse.setDac6CardKey(transCardBean.getCardDac6PrimaryKey());
        submissionMatchResponse.setDac2CardKey(transCardBean.getCardDac2PrimaryKey());
        submissionMatchResponse.setAuthSeNumber(transCardBean.getSeNumber());

        submissionMatchResponse.setEcbCreationTime(
            transCardBean.getTransactionTimeStamp() != null
                ? AuthMatchUtil.getStringFromDate(
                    transCardBean.getTransactionTimeStamp(), AuthMatchUtil.MX_AUTH_DATE_TIME_FORMAT)
                : "");
        submissionMatchResponse.setRocAuthDAC(rocMatchRequest.getRocAuthDAC());
        submissionMatchResponse.setRocCardNumber(rocMatchRequest.getRocCardNumber());
        submissionMatchResponse.setRocSENumber(rocMatchRequest.getRocSENumber());
      }
    } catch (Exception e) {
      LOGGER.error(
          "{}| Error occurred while performaing Match by level 11",
          authMatchLog.getCommonLogAttributes("S", "GE000M11", rocMatchRequest),
          ITier.REQUESTHANDLER,
          CLASS_NAME,
          CLASS_NAME);
      rocMatched = false;
      LOGGER.error("{} Error during Match by Card number and SE number", e.getMessage());
    }
    submissionMatchResponse.setMatched(rocMatched);
    return submissionMatchResponse;
  }
}
