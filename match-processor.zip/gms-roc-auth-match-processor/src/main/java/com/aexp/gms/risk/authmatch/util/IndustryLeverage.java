package com.aexp.gms.risk.authmatch.util;

import com.aexp.gms.imc.risk.rules.vo.keys.GenericKey;
import com.aexp.gms.imc.risk.rules.vo.keys.ICacheKey;
import com.aexp.gms.imc.risk.rules.vo.values.IndustryLeverageBean;
import com.aexp.gms.risk.authmatch.exception.AuthMatchSystemException;
import java.io.FileReader;
import java.math.BigDecimal;
import java.util.HashMap;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class IndustryLeverage {
  static HashMap<ICacheKey, IndustryLeverageBean> industryLeverageMap = null;
  private static final Logger LOGGER = LoggerFactory.getLogger(IndustryLeverage.class);

  public static IndustryLeverageBean getIndustryLeverageData(String key) {

    IndustryLeverageBean industryLeverageBean = null;

    if (industryLeverageMap == null) {
      try {
        loadIndustryLeverageData();
      } catch (AuthMatchSystemException e) {
        e.printStackTrace();
      }
    }

    industryLeverageBean = industryLeverageMap.get(key);

    if (industryLeverageBean == null) {
      industryLeverageBean = new IndustryLeverageBean();
      industryLeverageBean.setHigherMultiplier(new BigDecimal("1.05"));
      industryLeverageBean.setLowerMultiplier(new BigDecimal("0.85"));
      industryLeverageBean.setLeveragePercent(15);
    }

    return industryLeverageBean;
  }

  private static void loadIndustryLeverageData() throws AuthMatchSystemException {
    JSONParser parser = new JSONParser();
    ObjectMapper mapper = new ObjectMapper();
    industryLeverageMap = new HashMap<>();
    try {
      LOGGER.info(AuthMatchPropertyPlaceholderConfigurer.getProperty("SEIndustryLeverage.path"));
      FileReader reader =
          new FileReader(
              AuthMatchPropertyPlaceholderConfigurer.getProperty("SEIndustryLeverage.path"));

      JSONObject jsonObject = (JSONObject) parser.parse(reader);
      JSONArray msg = (JSONArray) jsonObject.get("leverage");
      IndustryLeverageBean leverage = null;
      for (Object object : msg) {
        leverage = mapper.readValue(object.toString(), IndustryLeverageBean.class);
        industryLeverageMap.put(
            new GenericKey((String) leverage.getIndustryCategoryCode()), leverage);
      }
    } catch (Exception e) {
      throw new AuthMatchSystemException(e.getMessage());
    }
  }
}
