package com.aexp.gms.risk.authmatch.controller;

import com.americanexpress.ea.elf.servlet.ELFFilter;
import com.americanexpress.ea.elf.spring.resttemplate.DefaultHttpClientConfig;
import com.americanexpress.ea.elf.spring.servlet.DefaultSpringWebServerConfig;
import com.americanexpress.ea.elf.tracer.core.util.TracerUtils;
import io.opentracing.Tracer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.cassandra.CassandraDataAutoConfiguration;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.ImportResource;

@SpringBootApplication
@Configuration
@EnableAutoConfiguration(exclude = CassandraDataAutoConfiguration.class)
@ImportResource("classpath:authmatch-processor-spring-config.xml")
@Import({DefaultSpringWebServerConfig.class, DefaultHttpClientConfig.class})
public class AuthMatchLauncher {

  private static final Logger logger = LoggerFactory.getLogger(AuthMatchLauncher.class);

  public static void main(String[] args) {
    ApplicationContext ctx = SpringApplication.run(AuthMatchLauncher.class, args);

    logger.info("Starting Auth Match SpringBoot app");

    if (args != null && args.length > 0) {
      logger.info("Enumerating jar args:");

      for (String arg : args) {
        logger.info("\t{}", arg);
      }
    }
  }

  @Bean
  public FilterRegistrationBean registerLoggingFilter(ELFFilter elfFilter) {
    FilterRegistrationBean registration = new FilterRegistrationBean(elfFilter);
    registration.addUrlPatterns("/healthcheck");
    registration.setOrder(1);
    return registration;
  }

  @Bean
  public Tracer tracer() {
    return TracerUtils.defaultTracer();
  }
}
