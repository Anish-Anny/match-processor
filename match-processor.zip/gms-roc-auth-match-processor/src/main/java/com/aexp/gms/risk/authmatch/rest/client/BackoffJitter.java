package com.aexp.gms.risk.authmatch.rest.client;

import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class BackoffJitter {
  private final Logger log = LoggerFactory.getLogger(BackoffJitter.class);

  private int getPower(int tryNumber) {
    return (int) Math.pow(2.0, tryNumber);
  }

  public long getWaitTime(int tryNumber, int baseBackoffMs, int waitCap) {
    return ThreadLocalRandom.current()
        .nextLong(0, Math.max(1, Math.min(waitCap, baseBackoffMs * getPower(tryNumber))));
  }

  public void backoffJitter(int tryNumber, int baseBackoffMs, int waitCapMs) {
    if (tryNumber == 0) return; // don't wait on the first try
    long timeToWait = getWaitTime(tryNumber, baseBackoffMs, waitCapMs);
    log.info("sleeping for {}ms", timeToWait);

    try {
      TimeUnit.MILLISECONDS.sleep(timeToWait);
    } catch (InterruptedException e) {
      log.info("thread interrupted during backoff/jitter", e);
    }
  }
}
