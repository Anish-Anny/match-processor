package com.aexp.gms.risk.authmatch.services;

import com.aexp.gmnt.imc.compute.global.IGmntIMCompute;
import com.aexp.gmnt.imc.compute.global.IMCProcessException;
import com.aexp.gmnt.imc.compute.global.IProgramData;
import com.aexp.gms.imc.risk.rules.vo.keys.CasAuthTransIdCardCacheKey;
import com.aexp.gms.imc.risk.rules.vo.values.CasAuthTransIdCardCacheBean;
import com.aexp.gms.risk.authmatch.dao.IgniteProvider;
import com.aexp.gms.risk.authmatch.util.AuthMatchConstants;
import org.apache.ignite.Ignite;
import org.apache.ignite.lang.IgniteCallable;
import org.apache.ignite.lang.IgniteRunnable;
import org.apache.ignite.resources.IgniteInstanceResource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AuthMatchIgniteCompute implements IGmntIMCompute<IProgramData> {

  private ComputeJobProcess jobInstance;
  private IgniteProvider igniteProvider;
  private final Logger LOGGER = LoggerFactory.getLogger(AuthMatchIgniteCompute.class);

  public ComputeJobProcess getJobInstance() {
    return jobInstance;
  }

  public void setJobInstance(ComputeJobProcess jobInstance) {
    this.jobInstance = jobInstance;
  }

  public AuthMatchIgniteCompute() {
    jobInstance = new ComputeJobProcess();
    igniteProvider = new IgniteProvider();
  }

  public AuthMatchIgniteCompute(ComputeJobProcess jobInstance, IgniteProvider igniteProvider) {
    this.jobInstance = jobInstance;
    this.igniteProvider = igniteProvider;
  }

  /** Single point of entry for Ignite Compute Grid calls. */
  @Override
  public IProgramData affinityCall(IProgramData inputData, String key, Long igniteTimeOut)
      throws IMCProcessException {

    IProgramData outputData =
        igniteProvider
            .getIgnite()
            .compute(igniteProvider.getIgnite().cluster().forServers())
            .affinityCall(
                AuthMatchConstants.CAS_AUTH_TID_CM_CACHE,
                key,
                (new IgniteCallable<IProgramData>() {
                  private static final long serialVersionUID = 1L;
                  @IgniteInstanceResource private Ignite ignite; // = igniteProvider.getIgnite();

                  public IProgramData call() throws Exception {
                    if (ignite == null) LOGGER.info(">>>>ignite instance is null");

                    return jobInstance.process((IProgramData) inputData);
                  }
                }));

    return outputData;
  }

  @Override
  public void broadCastCacheVersion() {
    igniteProvider.getIgnite().compute().broadcast(new Test());
  }

  public static class Test implements IgniteRunnable {
    @IgniteInstanceResource private Ignite ignite; // = igniteProvider.getIgnite();

    public void run() {
      CasAuthTransIdCardCacheKey key =
          new CasAuthTransIdCardCacheKey("000000000000200", "370000000000200", "D");
      System.out.println(
          "Domain Bean version info : TID Cache - {"
              + (new CasAuthTransIdCardCacheBean()).toString()
              + "} , TID Cache Key - {"
              + (new CasAuthTransIdCardCacheKey("1|1|1")).toString());
    }
  }
}
