package com.aexp.gms.risk.authmatch.model;

import com.fasterxml.jackson.core.JsonProcessingException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AuthLoadRequestMapper {

  private static com.fasterxml.jackson.databind.ObjectMapper mapper =
      new com.fasterxml.jackson.databind.ObjectMapper();
  private static final Logger LOGGER = LoggerFactory.getLogger(AuthLoadRequestMapper.class);

  public static String buildAuthLadRequestFromSubmissionResponse(SubmissionMatchResponse response) {
    String jsonStr = null;
    AuthSchema authSchema = new AuthSchema();
    String formattedDate = null;
    String formattedTime = null;

    try {
      DateFormat originalFormat = new SimpleDateFormat("yyyy-MM-dd");
      DateFormat originalTimeFormat = new SimpleDateFormat("hh:mm:ss.SSS");
      Date date = originalFormat.parse(response.getAuthDate());
      Date time = originalTimeFormat.parse(response.getAuthTime());
      DateFormat targetFormat = new SimpleDateFormat("MMddyy");
      DateFormat targetTimeFormat = new SimpleDateFormat("hhmmss");
      formattedDate = targetFormat.format(date);
      formattedTime = targetTimeFormat.format(time);
    } catch (ParseException e1) {
      LOGGER.error("Error occurred while parsing the dates error message : " + e1.getMessage());
    }

    authSchema.setLwrcw7etrid(response.getTransactionId());
    authSchema.setLwrisoaid(response.getAuthSeNumber());
    authSchema.setLwrdgod(formattedDate);
    authSchema.setLwrdtim(formattedTime);

    if (response.getApprovalCode().equals("A")) authSchema.setLwrcwDadc("0");
    else authSchema.setLwrcwDadc("2");

    String casPkey = response.getCaspKey();
    // cak_pkey is formed as "ecbcreationyear(4) + Julian(3) + authuniqueidentifier(10)"
    String julian = casPkey.substring(4, 7);
    String lwrcw7dlog = casPkey.substring(7);

    authSchema.setLwrlsdpan(response.getDpan());
    authSchema.setCr41mcc(response.getMcc());
    authSchema.setLwrcw7dlog(lwrcw7dlog);
    authSchema.setLwrcwEcbcret(response.getEcbCreationTime());
    authSchema.setLwrsorc(response.getVoiceAuthIndicator());
    authSchema.setLwrisfld22(response.getPosDataCode());
    authSchema.setLwrisdf61eci1(response.getEciIndicator());
    authSchema.setLwrcc7komcc(response.getOriginalMccCode());
    authSchema.setLwrisoact(response.getRocCardNumber());
    authSchema.setCr41tcntry2(response.getSeCountryCode());
    authSchema.setCr41wwic(response.getSeIndustryCategoryCode());
    authSchema.setLwrisoamt(response.getAuthAmountUsd());
    authSchema.setLwrcc7kfrc(response.getAuthAmountLocal());
    authSchema.setLwrisocur(response.getAuthAmountCurrencyCode());
    authSchema.setLwrrrKapc(response.getAuth2Dac());
    authSchema.setLwrrr7dap6(response.getAuth6Dac());
    authSchema.setLwrcxMgstrpcd(response.getMagneticStripeCode());
    authSchema.setLwrgmZprobfb(Double.valueOf(response.getFraudLossProbability()));
    authSchema.setLwrdx7ksep(response.getSeTypeCode());
    authSchema.setLwrdx7kjdd(julian);

    authSchema.setLwrdwCwdcde(""); // value is not available in ram_rslt_by_arn_table
    authSchema.setLwrdwFwdcde(""); // value is not available in ram_rslt_by_arn_table

    try {
      jsonStr = mapper.writeValueAsString(authSchema);
    } catch (JsonProcessingException e) {
      LOGGER.error("Error occurred while converting object into json cause : " + e.getCause());
      return null;
    }
    return jsonStr;
  }
}
