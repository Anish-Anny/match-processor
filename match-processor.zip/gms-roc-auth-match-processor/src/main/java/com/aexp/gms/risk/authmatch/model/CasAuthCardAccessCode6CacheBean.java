package com.aexp.gms.risk.authmatch.model;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CasAuthCardAccessCode6CacheBean {

  /** */
  //	private static final long serialVersionUID = 655814863422556823L;

  private String cardNumber;

  private String auth6Dac;

  private String approveDenyCode;

  private String strAuthTransactionDateTime;

  private String seNumber;

  private BigDecimal authAmountLocal;

  private String authAmountCurrencyCode;

  private Date authTransactionDateTime;

  private BigDecimal authAmountUSD;

  private String rocAuthMatchedFlag;

  private String rocAuthMatchedCriteriaId;

  private String persistedFlag; // Y -> Cassandra updated

  private String tidCMPrimaryKey;

  private String cardDac2PrimaryKey;

  private String authUniqueIdentifier;

  private BigDecimal matchedAmountUSD;

  private DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

  public String getCacheStringKey() {
    return this.cardNumber + "|" + this.auth6Dac + "|" + this.approveDenyCode;
  }

  public String getCardNumber() {
    return cardNumber;
  }

  public void setCardNumber(String cardNumber) {
    this.cardNumber = cardNumber;
  }

  public String getApproveDenyCode() {
    return approveDenyCode;
  }

  public void setApproveDenyCode(String approveDenyCode) {
    this.approveDenyCode = approveDenyCode;
  }

  public String getStrAuthTransactionDateTime() {
    return strAuthTransactionDateTime;
  }

  public void setStrAuthTransactionDateTime(String strAuthTransactionDateTime) {
    this.strAuthTransactionDateTime = strAuthTransactionDateTime;
  }

  public String getAuth6Dac() {
    return auth6Dac;
  }

  public void setAuth6Dac(String auth6Dac) {
    this.auth6Dac = auth6Dac;
  }

  public String getSeNumber() {
    return seNumber;
  }

  public void setSeNumber(String seNumber) {
    this.seNumber = seNumber;
  }

  public BigDecimal getAuthAmountLocal() {
    return authAmountLocal;
  }

  public void setAuthAmountLocal(BigDecimal authAmountLocal) {
    this.authAmountLocal = authAmountLocal;
  }

  public String getAuthAmountCurrencyCode() {
    return authAmountCurrencyCode;
  }

  public void setAuthAmountCurrencyCode(String authAmountCurrencyCode) {
    this.authAmountCurrencyCode = authAmountCurrencyCode;
  }

  public Date getAuthTransactionDateTime() {
    return authTransactionDateTime;
  }

  public void setAuthTransactionDateTime(Date authTransactionDateTime) {
    this.authTransactionDateTime = authTransactionDateTime;
    this.strAuthTransactionDateTime = dateFormat.format(authTransactionDateTime);
  }

  public BigDecimal getAuthAmountUSD() {
    return authAmountUSD;
  }

  public void setAuthAmountUSD(BigDecimal authAmountUSD) {
    this.authAmountUSD = authAmountUSD;
  }

  public String getRocAuthMatchedFlag() {
    return rocAuthMatchedFlag;
  }

  public void setRocAuthMatchedFlag(String rocAuthMatchedFlag) {
    this.rocAuthMatchedFlag = rocAuthMatchedFlag;
  }

  public String getRocAuthMatchedCriteriaId() {
    return rocAuthMatchedCriteriaId;
  }

  public void setRocAuthMatchedCriteriaId(String rocAuthMatchedCriteriaId) {
    this.rocAuthMatchedCriteriaId = rocAuthMatchedCriteriaId;
  }

  public String getPersistedFlag() {
    return persistedFlag;
  }

  public void setPersistedFlag(String persistedFlag) {
    this.persistedFlag = persistedFlag;
  }

  public String getTidCMPrimaryKey() {
    return tidCMPrimaryKey;
  }

  public void setTidCMPrimaryKey(String tidCMPrimaryKey) {
    this.tidCMPrimaryKey = tidCMPrimaryKey;
  }

  public String getCardDac2PrimaryKey() {
    return cardDac2PrimaryKey;
  }

  public void setCardDac2PrimaryKey(String cardDac2PrimaryKey) {
    this.cardDac2PrimaryKey = cardDac2PrimaryKey;
  }

  public String getAuthUniqueIdentifier() {
    return authUniqueIdentifier;
  }

  public void setAuthUniqueIdentifier(String authUniqueIdentifier) {
    this.authUniqueIdentifier = authUniqueIdentifier;
  }

  public BigDecimal getMatchedAmountUSD() {
    return matchedAmountUSD;
  }

  public void setMatchedAmountUSD(BigDecimal matchedAmountUSD) {
    this.matchedAmountUSD = matchedAmountUSD;
  }

  public String getTableName() {
    return "CasAuthCardAccessCode6CacheBean";
  }

  public String getCacheName() {
    return "GMS_CAS_AUTH_CM_DAC6_CACHE_V1";
  }

  /*  public String toString() {
    return "CasAuthCardAccessCode6CacheBean [cardNumber="
        + cardNumber
        + ", auth6Dac="
        + auth6Dac
        + ", authAmountLocal="
        + authAmountLocal
        + ", authAmountCurrencyCode="
        + authAmountCurrencyCode
        + ", authTransactionDateTime="
        + authTransactionDateTime
        + ", authAmountUSD="
        + authAmountUSD
        + ", tidCMPrimaryKey="
        + tidCMPrimaryKey
        + ", cardDac2PrimaryKey="
        + cardDac2PrimaryKey
        + ", authUniqueIdentifier="
        + authUniqueIdentifier
        + "] version1";
  }*/
}
