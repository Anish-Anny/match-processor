package com.aexp.gms.risk.authmatch.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;

/** Created by rmanick on 6/25/2018. */
public class Authorization {
  private String authUniqeIdentifer;
  private String approveDenyCode;
  private String auth2DACApproveCode;
  private String auth6DACApproveCode;
  private BigDecimal amountInLocalCurrency;
  private BigDecimal amountInUSD;
  private String authCurrency;
  private LocalDate authorizationDate;
  private LocalTime authorizationTime;
  private String cardNumber;
  private Float fraudLossProbabilityScore;
  private String foreignSpendIndicator;
  private String casLogIdentifier;
  private String magStripeIndicator;
  private String mCC;
  private String seNumber;
  private String seCountryCode;
  private String seIndustryCode;
  private String seTypeCode;
  private String sourceID;
  private String transID;

  public String getAuthUniqeIdentifer() {
    return authUniqeIdentifer;
  }

  public void setAuthUniqeIdentifer(String authUniqeIdentifer) {
    this.authUniqeIdentifer = authUniqeIdentifer;
  }

  public String getApproveDenyCode() {
    return approveDenyCode;
  }

  public void setApproveDenyCode(String approveDenyCode) {
    this.approveDenyCode = approveDenyCode;
  }

  public String getAuth2DACApproveCode() {
    return auth2DACApproveCode;
  }

  public void setAuth2DACApproveCode(String auth2DACApproveCode) {
    this.auth2DACApproveCode = auth2DACApproveCode;
  }

  public String getAuth6DACApproveCode() {
    return auth6DACApproveCode;
  }

  public void setAuth6DACApproveCode(String auth6DACApproveCode) {
    this.auth6DACApproveCode = auth6DACApproveCode;
  }

  public BigDecimal getAmountInLocalCurrency() {
    return amountInLocalCurrency;
  }

  public void setAmountInLocalCurrency(BigDecimal amountInLocalCurrency) {
    this.amountInLocalCurrency = amountInLocalCurrency;
  }

  public BigDecimal getAmountInUSD() {
    return amountInUSD;
  }

  public void setAmountInUSD(BigDecimal amountInUSD) {
    this.amountInUSD = amountInUSD;
  }

  public String getAuthCurrency() {
    return authCurrency;
  }

  public void setAuthCurrency(String authCurrency) {
    this.authCurrency = authCurrency;
  }

  public LocalDate getAuthorizationDate() {
    return authorizationDate;
  }

  public void setAuthorizationDate(LocalDate authorizationDate) {
    this.authorizationDate = authorizationDate;
  }

  public LocalTime getAuthorizationTime() {
    return authorizationTime;
  }

  public void setAuthorizationTime(LocalTime authorizationTime) {
    this.authorizationTime = authorizationTime;
  }

  public String getCardNumber() {
    return cardNumber;
  }

  public void setCardNumber(String cardNumber) {
    this.cardNumber = cardNumber;
  }

  public Float getFraudLossProbabilityScore() {
    return fraudLossProbabilityScore;
  }

  public void setFraudLossProbabilityScore(Float fraudLossProbabilityScore) {
    this.fraudLossProbabilityScore = fraudLossProbabilityScore;
  }

  public String getForeignSpendIndicator() {
    return foreignSpendIndicator;
  }

  public void setForeignSpendIndicator(String foreignSpendIndicator) {
    this.foreignSpendIndicator = foreignSpendIndicator;
  }

  public String getCasLogIdentifier() {
    return casLogIdentifier;
  }

  public void setCasLogIdentifier(String casLogIdentifier) {
    this.casLogIdentifier = casLogIdentifier;
  }

  public String getMagStripeIndicator() {
    return magStripeIndicator;
  }

  public void setMagStripeIndicator(String magStripeIndicator) {
    this.magStripeIndicator = magStripeIndicator;
  }

  public String getmCC() {
    return mCC;
  }

  public void setmCC(String mCC) {
    this.mCC = mCC;
  }

  public String getSeNumber() {
    return seNumber;
  }

  public void setSeNumber(String seNumber) {
    this.seNumber = seNumber;
  }

  public String getSeCountryCode() {
    return seCountryCode;
  }

  public void setSeCountryCode(String seCountryCode) {
    this.seCountryCode = seCountryCode;
  }

  public String getSeIndustryCode() {
    return seIndustryCode;
  }

  public void setSeIndustryCode(String seIndustryCode) {
    this.seIndustryCode = seIndustryCode;
  }

  public String getSeTypeCode() {
    return seTypeCode;
  }

  public void setSeTypeCode(String seTypeCode) {
    this.seTypeCode = seTypeCode;
  }

  public String getSourceID() {
    return sourceID;
  }

  public void setSourceID(String sourceID) {
    this.sourceID = sourceID;
  }

  public String getTransID() {
    return transID;
  }

  public void setTransID(String transID) {
    this.transID = transID;
  }
}
