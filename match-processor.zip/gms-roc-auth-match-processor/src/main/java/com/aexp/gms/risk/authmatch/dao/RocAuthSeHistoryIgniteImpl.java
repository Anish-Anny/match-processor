package com.aexp.gms.risk.authmatch.dao;

import com.aexp.gms.risk.authmatch.model.ignite.key.RocAuthSEHistoryKey;
import com.aexp.gms.risk.authmatch.model.ignite.value.RocAuthSEHistoryValue;
import org.apache.ignite.IgniteBinary;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.binary.BinaryObject;
import org.apache.ignite.binary.BinaryObjectBuilder;
import org.springframework.stereotype.Component;

@Component
public class RocAuthSeHistoryIgniteImpl implements RocAuthSEHistoryDao {
  public static final String CACHE_ROC_AUTH_HISTORY = "RocAuthHistory";
  private IgniteProvider igniteClient;

  public RocAuthSeHistoryIgniteImpl() {}

  public void setIgniteProvider(IgniteProvider igniteClient) {
    this.igniteClient = igniteClient;
  }

  public RocAuthSeHistoryIgniteImpl(IgniteProvider igniteClient) {
    this.igniteClient = igniteClient;
  }

  public void put(RocAuthSEHistoryKey key, RocAuthSEHistoryValue value) {
    getCache().put(key, value);
  }

  public RocAuthSEHistoryValue get(RocAuthSEHistoryKey key) {

    IgniteBinary binary = igniteClient.getIgnite().binary();
    BinaryObjectBuilder builder =
        binary.builder("com.aexp.gms.risk.authmatch.model.ignite.key.RocAuthSEHistoryKey");
    builder.setField("rocSE", key.getRocSE());
    builder.setField("authSE", key.getAuthSE());
    IgniteCache<BinaryObject, BinaryObject> rocAuthHistoryCache =
        igniteClient.getIgnite().cache(CACHE_ROC_AUTH_HISTORY).withKeepBinary();

    RocAuthSEHistoryValue rocAuthSEHistoryValue = null;
    BinaryObject rocAuthSEHistoryValueBean = rocAuthHistoryCache.get(builder.build());
    if (rocAuthSEHistoryValueBean != null) {
      rocAuthSEHistoryValue =
          new RocAuthSEHistoryValue(
              rocAuthSEHistoryValueBean.field("rocSE"),
              rocAuthSEHistoryValueBean.field("authSE"),
              rocAuthSEHistoryValueBean.field("transactionDate"));
    }

    return rocAuthSEHistoryValue;
  }

  private IgniteCache<RocAuthSEHistoryKey, RocAuthSEHistoryValue> getCache() {
    return igniteClient.getIgnite().cache(CACHE_ROC_AUTH_HISTORY);
  }
}
