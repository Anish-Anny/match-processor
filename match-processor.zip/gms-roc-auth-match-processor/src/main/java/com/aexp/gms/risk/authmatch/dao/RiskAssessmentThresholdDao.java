package com.aexp.gms.risk.authmatch.dao;

import com.aexp.gms.imc.metadata.vo.RiskThresholdValue;

public interface RiskAssessmentThresholdDao {

  boolean isThresholdReached();

  void setIgniteProvider(IgniteProvider igniteProvider);

  void purgeThresholdCountDownLatch(String lastThresholdCountDownLatchName);

  void createThresholdCountDownLatch(String thresholdCountDownLatchName);

  RiskThresholdValue getThresholdValue();
}
