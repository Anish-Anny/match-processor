package com.aexp.gms.risk.authmatch.model;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.util.HashMap;
import java.util.Map;
import javax.validation.Valid;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.Size;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * authorization
 *
 * <p>An authorization from CAS
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
  "lwrcw_7etrid",
  "lwrisoact",
  "lwrisoaid",
  "cr41tcntry2",
  "cr41wwic",
  "lwrdgod",
  "lwrdtim",
  "lwrisoamt",
  "lwrcc_7kfrc",
  "lwrisocur",
  "lwraw_frgnind",
  "lwrrr_kapc",
  "lwrrr_7dap6",
  "lwrcx_mgstrpcd",
  "lwrcw_dadc",
  "cr41mcc",
  "lwrgm_zprobfb",
  "lwrdx_7ksep",
  "lwrcw_7dlog",
  "lwrcw_ecbcret",
  "lwrdx_7kjdd",
  "lwrsorc",
  "lwrisfld22",
  "lwrisdf61eci1",
  "lwrcc_7komcc",
  "lwrdw_cwdcde",
  "lwrdw_fwdcde",
  "lwrlsdpan"
})
public class AuthSchema {

  /** The unique identifier for a transaction */
  @JsonProperty("lwrcw_7etrid")
  @JsonPropertyDescription("The unique identifier for a transaction")
  private String lwrcw7etrid;
  /** 19 DIGIT ISO ACCOUNT NUMBER */
  @JsonProperty("lwrisoact")
  @JsonPropertyDescription("19 DIGIT ISO ACCOUNT NUMBER ")
  @Size(max = 19)
  private String lwrisoact;
  /** Authorizing SE number */
  @JsonProperty("lwrisoaid")
  @JsonPropertyDescription("Authorizing SE number")
  @Size(max = 15)
  private String lwrisoaid;
  /** SE Transacting country */
  @JsonProperty("cr41tcntry2")
  @JsonPropertyDescription("SE Transacting country")
  @Size(max = 2)
  private String cr41tcntry2;
  /** WORLD WIDE INDUSTRY CODE (WWIC) */
  @JsonProperty("cr41wwic")
  @JsonPropertyDescription("WORLD WIDE INDUSTRY CODE (WWIC)")
  @Size(max = 3)
  private String cr41wwic;
  /** AUTHORIZATION DATE (MST) */
  @JsonProperty("lwrdgod")
  @JsonPropertyDescription("AUTHORIZATION DATE (MST)")
  @Size(max = 8)
  private String lwrdgod;
  /** AUTHORIZATION TIME (MST) */
  @JsonProperty("lwrdtim")
  @JsonPropertyDescription("AUTHORIZATION TIME (MST)")
  @Size(max = 6)
  private String lwrdtim;
  /** 12 digit ISO dollar amount */
  @JsonProperty("lwrisoamt")
  @JsonPropertyDescription("12 digit ISO dollar amount")
  @DecimalMax("9999999999.99")
  @Size(max = 13)
  private String lwrisoamt;
  /** foreign currency amount */
  @JsonProperty("lwrcc_7kfrc")
  @JsonPropertyDescription("foreign currency amount")
  @DecimalMax("9999999999.999")
  @Size(max = 14)
  private String lwrcc7kfrc;
  /** ALPHA S/E CURRENCY CODE L7DCID */
  @JsonProperty("lwrisocur")
  @JsonPropertyDescription("ALPHA S/E CURRENCY CODE  L7DCID")
  @Size(max = 3)
  private String lwrisocur;
  /** FOREIGN SPEND INDICATOR */
  @JsonProperty("lwraw_frgnind")
  @JsonPropertyDescription("FOREIGN SPEND INDICATOR")
  @Size(max = 1)
  private String lwrawFrgnind;
  /** AUTH 2 DAC */
  @JsonProperty("lwrrr_kapc")
  @JsonPropertyDescription("AUTH 2 DAC")
  @Size(max = 2)
  private String lwrrrKapc;
  /** AUTH 6 DAC */
  @JsonProperty("lwrrr_7dap6")
  @JsonPropertyDescription("AUTH 6 DAC")
  @Size(max = 6)
  private String lwrrr7dap6;
  /** Mag stripe code */
  @JsonProperty("lwrcx_mgstrpcd")
  @JsonPropertyDescription("Mag stripe code")
  @Size(max = 1)
  private String lwrcxMgstrpcd;
  /** Approval/Deny Code - For Rule A1/C1 */
  @JsonProperty("lwrcw_dadc")
  @JsonPropertyDescription("Approval/Deny Code - For Rule A1/C1")
  @Size(max = 1)
  private String lwrcwDadc;
  /** Mechant Category Code */
  @JsonProperty("cr41mcc")
  @JsonPropertyDescription("Mechant Category Code")
  @Size(max = 4)
  private String cr41mcc;
  /** PROBABILITY OF CREDIT LOSS~*** FRAU */
  @JsonProperty("lwrgm_zprobfb")
  @JsonPropertyDescription("PROBABILITY OF CREDIT LOSS~***                FRAU")
  @DecimalMax("0.9999")
  private Double lwrgmZprobfb;
  /** SE TYPE */
  @JsonProperty("lwrdx_7ksep")
  @JsonPropertyDescription("SE TYPE")
  @Size(max = 1)
  private String lwrdx7ksep;
  /** LSEQNO - used to derive the cas key */
  @JsonProperty("lwrcw_7dlog")
  @JsonPropertyDescription("LSEQNO - used to derive the cas key")
  @DecimalMax("4294967295")
  @Size(max = 10)
  private String lwrcw7dlog;
  /** TRNSDTTM - used to derive the cas key */
  @JsonProperty("lwrcw_ecbcret")
  @JsonPropertyDescription("TRNSDTTM  - used to derive the cas key")
  @Size(max = 23)
  private String lwrcwEcbcret;
  /** JULIAN - used to derive the cas key */
  @JsonProperty("lwrdx_7kjdd")
  @JsonPropertyDescription("JULIAN - used to derive the cas key")
  @Size(max = 3)
  private String lwrdx7kjdd;
  /** Voice Auth Indicator */
  @JsonProperty("lwrsorc")
  @JsonPropertyDescription("Voice Auth Indicator")
  @Size(max = 1)
  private String lwrsorc;
  /** B55PDCAC - POS data code for all types of authorization */
  @JsonProperty("lwrisfld22")
  @JsonPropertyDescription("B55PDCAC - POS data code for all types of authorization")
  @Size(max = 12)
  private String lwrisfld22;
  /** DF61EC1 - ECI indicator */
  @JsonProperty("lwrisdf61eci1")
  @JsonPropertyDescription("DF61EC1 - ECI indicator")
  @Size(max = 2)
  private String lwrisdf61eci1;
  /** OMCC - original MCC from auth request */
  @JsonProperty("lwrcc_7komcc")
  @JsonPropertyDescription("OMCC - original MCC from auth request")
  @Size(max = 4)
  private String lwrcc7komcc;
  /** CRWHYDND - credit why denied */
  @JsonProperty("lwrdw_cwdcde")
  @JsonPropertyDescription("CRWHYDND - credit why denied")
  @Size(max = 3)
  private String lwrdwCwdcde;
  /** FWDCDE - fraud why denied code */
  @JsonProperty("lwrdw_fwdcde")
  @JsonPropertyDescription("FWDCDE - fraud why denied code")
  @Size(max = 3)
  private String lwrdwFwdcde;
  /** DPAN - device permanent account number */
  @JsonProperty("lwrlsdpan")
  @JsonPropertyDescription("DPAN - device permanent account number")
  @Size(max = 19)
  private String lwrlsdpan;

  @JsonIgnore @Valid
  private Map<String, Object> additionalProperties = new HashMap<String, Object>();

  /** The unique identifier for a transaction */
  @JsonProperty("lwrcw_7etrid")
  public String getLwrcw7etrid() {
    return lwrcw7etrid;
  }

  /** The unique identifier for a transaction */
  @JsonProperty("lwrcw_7etrid")
  public void setLwrcw7etrid(String lwrcw7etrid) {
    this.lwrcw7etrid = lwrcw7etrid;
  }

  /** 19 DIGIT ISO ACCOUNT NUMBER */
  @JsonProperty("lwrisoact")
  public String getLwrisoact() {
    return lwrisoact;
  }

  /** 19 DIGIT ISO ACCOUNT NUMBER */
  @JsonProperty("lwrisoact")
  public void setLwrisoact(String lwrisoact) {
    this.lwrisoact = lwrisoact;
  }

  /** Authorizing SE number */
  @JsonProperty("lwrisoaid")
  public String getLwrisoaid() {
    return lwrisoaid;
  }

  /** Authorizing SE number */
  @JsonProperty("lwrisoaid")
  public void setLwrisoaid(String lwrisoaid) {
    this.lwrisoaid = lwrisoaid;
  }

  /** SE Transacting country */
  @JsonProperty("cr41tcntry2")
  public String getCr41tcntry2() {
    return cr41tcntry2;
  }

  /** SE Transacting country */
  @JsonProperty("cr41tcntry2")
  public void setCr41tcntry2(String cr41tcntry2) {
    this.cr41tcntry2 = cr41tcntry2;
  }

  /** WORLD WIDE INDUSTRY CODE (WWIC) */
  @JsonProperty("cr41wwic")
  public String getCr41wwic() {
    return cr41wwic;
  }

  /** WORLD WIDE INDUSTRY CODE (WWIC) */
  @JsonProperty("cr41wwic")
  public void setCr41wwic(String cr41wwic) {
    this.cr41wwic = cr41wwic;
  }

  /** AUTHORIZATION DATE (MST) */
  @JsonProperty("lwrdgod")
  public String getLwrdgod() {
    return lwrdgod;
  }

  /** AUTHORIZATION DATE (MST) */
  @JsonProperty("lwrdgod")
  public void setLwrdgod(String lwrdgod) {
    this.lwrdgod = lwrdgod;
  }

  /** AUTHORIZATION TIME (MST) */
  @JsonProperty("lwrdtim")
  public String getLwrdtim() {
    return lwrdtim;
  }

  /** AUTHORIZATION TIME (MST) */
  @JsonProperty("lwrdtim")
  public void setLwrdtim(String lwrdtim) {
    this.lwrdtim = lwrdtim;
  }

  /** 12 digit ISO dollar amount */
  @JsonProperty("lwrisoamt")
  public String getLwrisoamt() {
    return lwrisoamt;
  }

  /** 12 digit ISO dollar amount */
  @JsonProperty("lwrisoamt")
  public void setLwrisoamt(String lwrisoamt) {
    this.lwrisoamt = lwrisoamt;
  }

  /** foreign currency amount */
  @JsonProperty("lwrcc_7kfrc")
  public String getLwrcc7kfrc() {
    return lwrcc7kfrc;
  }

  /** foreign currency amount */
  @JsonProperty("lwrcc_7kfrc")
  public void setLwrcc7kfrc(String lwrcc7kfrc) {
    this.lwrcc7kfrc = lwrcc7kfrc;
  }

  /** ALPHA S/E CURRENCY CODE L7DCID */
  @JsonProperty("lwrisocur")
  public String getLwrisocur() {
    return lwrisocur;
  }

  /** ALPHA S/E CURRENCY CODE L7DCID */
  @JsonProperty("lwrisocur")
  public void setLwrisocur(String lwrisocur) {
    this.lwrisocur = lwrisocur;
  }

  /** FOREIGN SPEND INDICATOR */
  @JsonProperty("lwraw_frgnind")
  public String getLwrawFrgnind() {
    return lwrawFrgnind;
  }

  /** FOREIGN SPEND INDICATOR */
  @JsonProperty("lwraw_frgnind")
  public void setLwrawFrgnind(String lwrawFrgnind) {
    this.lwrawFrgnind = lwrawFrgnind;
  }

  /** AUTH 2 DAC */
  @JsonProperty("lwrrr_kapc")
  public String getLwrrrKapc() {
    return lwrrrKapc;
  }

  /** AUTH 2 DAC */
  @JsonProperty("lwrrr_kapc")
  public void setLwrrrKapc(String lwrrrKapc) {
    this.lwrrrKapc = lwrrrKapc;
  }

  /** AUTH 6 DAC */
  @JsonProperty("lwrrr_7dap6")
  public String getLwrrr7dap6() {
    return lwrrr7dap6;
  }

  /** AUTH 6 DAC */
  @JsonProperty("lwrrr_7dap6")
  public void setLwrrr7dap6(String lwrrr7dap6) {
    this.lwrrr7dap6 = lwrrr7dap6;
  }

  /** Mag stripe code */
  @JsonProperty("lwrcx_mgstrpcd")
  public String getLwrcxMgstrpcd() {
    return lwrcxMgstrpcd;
  }

  /** Mag stripe code */
  @JsonProperty("lwrcx_mgstrpcd")
  public void setLwrcxMgstrpcd(String lwrcxMgstrpcd) {
    this.lwrcxMgstrpcd = lwrcxMgstrpcd;
  }

  /** Approval/Deny Code - For Rule A1/C1 */
  @JsonProperty("lwrcw_dadc")
  public String getLwrcwDadc() {
    return lwrcwDadc;
  }

  /** Approval/Deny Code - For Rule A1/C1 */
  @JsonProperty("lwrcw_dadc")
  public void setLwrcwDadc(String lwrcwDadc) {
    this.lwrcwDadc = lwrcwDadc;
  }

  /** Mechant Category Code */
  @JsonProperty("cr41mcc")
  public String getCr41mcc() {
    return cr41mcc;
  }

  /** Mechant Category Code */
  @JsonProperty("cr41mcc")
  public void setCr41mcc(String cr41mcc) {
    this.cr41mcc = cr41mcc;
  }

  /** PROBABILITY OF CREDIT LOSS~*** FRAU */
  @JsonProperty("lwrgm_zprobfb")
  public Double getLwrgmZprobfb() {
    return lwrgmZprobfb;
  }

  /** PROBABILITY OF CREDIT LOSS~*** FRAU */
  @JsonProperty("lwrgm_zprobfb")
  public void setLwrgmZprobfb(Double lwrgmZprobfb) {
    this.lwrgmZprobfb = lwrgmZprobfb;
  }

  /** SE TYPE */
  @JsonProperty("lwrdx_7ksep")
  public String getLwrdx7ksep() {
    return lwrdx7ksep;
  }

  /** SE TYPE */
  @JsonProperty("lwrdx_7ksep")
  public void setLwrdx7ksep(String lwrdx7ksep) {
    this.lwrdx7ksep = lwrdx7ksep;
  }

  /** LSEQNO - used to derive the cas key */
  @JsonProperty("lwrcw_7dlog")
  public String getLwrcw7dlog() {
    return lwrcw7dlog;
  }

  /** LSEQNO - used to derive the cas key */
  @JsonProperty("lwrcw_7dlog")
  public void setLwrcw7dlog(String lwrcw7dlog) {
    this.lwrcw7dlog = lwrcw7dlog;
  }

  /** TRNSDTTM - used to derive the cas key */
  @JsonProperty("lwrcw_ecbcret")
  public String getLwrcwEcbcret() {
    return lwrcwEcbcret;
  }

  /** TRNSDTTM - used to derive the cas key */
  @JsonProperty("lwrcw_ecbcret")
  public void setLwrcwEcbcret(String lwrcwEcbcret) {
    this.lwrcwEcbcret = lwrcwEcbcret;
  }

  /** JULIAN - used to derive the cas key */
  @JsonProperty("lwrdx_7kjdd")
  public String getLwrdx7kjdd() {
    return lwrdx7kjdd;
  }

  /** JULIAN - used to derive the cas key */
  @JsonProperty("lwrdx_7kjdd")
  public void setLwrdx7kjdd(String lwrdx7kjdd) {
    this.lwrdx7kjdd = lwrdx7kjdd;
  }

  /** Voice Auth Indicator */
  @JsonProperty("lwrsorc")
  public String getLwrsorc() {
    return lwrsorc;
  }

  /** Voice Auth Indicator */
  @JsonProperty("lwrsorc")
  public void setLwrsorc(String lwrsorc) {
    this.lwrsorc = lwrsorc;
  }

  /** B55PDCAC - POS data code for all types of authorization */
  @JsonProperty("lwrisfld22")
  public String getLwrisfld22() {
    return lwrisfld22;
  }

  /** B55PDCAC - POS data code for all types of authorization */
  @JsonProperty("lwrisfld22")
  public void setLwrisfld22(String lwrisfld22) {
    this.lwrisfld22 = lwrisfld22;
  }

  /** DF61EC1 - ECI indicator */
  @JsonProperty("lwrisdf61eci1")
  public String getLwrisdf61eci1() {
    return lwrisdf61eci1;
  }

  /** DF61EC1 - ECI indicator */
  @JsonProperty("lwrisdf61eci1")
  public void setLwrisdf61eci1(String lwrisdf61eci1) {
    this.lwrisdf61eci1 = lwrisdf61eci1;
  }

  /** OMCC - original MCC from auth request */
  @JsonProperty("lwrcc_7komcc")
  public String getLwrcc7komcc() {
    return lwrcc7komcc;
  }

  /** OMCC - original MCC from auth request */
  @JsonProperty("lwrcc_7komcc")
  public void setLwrcc7komcc(String lwrcc7komcc) {
    this.lwrcc7komcc = lwrcc7komcc;
  }

  /** CRWHYDND - credit why denied */
  @JsonProperty("lwrdw_cwdcde")
  public String getLwrdwCwdcde() {
    return lwrdwCwdcde;
  }

  /** CRWHYDND - credit why denied */
  @JsonProperty("lwrdw_cwdcde")
  public void setLwrdwCwdcde(String lwrdwCwdcde) {
    this.lwrdwCwdcde = lwrdwCwdcde;
  }

  /** FWDCDE - fraud why denied code */
  @JsonProperty("lwrdw_fwdcde")
  public String getLwrdwFwdcde() {
    return lwrdwFwdcde;
  }

  /** FWDCDE - fraud why denied code */
  @JsonProperty("lwrdw_fwdcde")
  public void setLwrdwFwdcde(String lwrdwFwdcde) {
    this.lwrdwFwdcde = lwrdwFwdcde;
  }

  /** DPAN - device permanent account number */
  @JsonProperty("lwrlsdpan")
  public String getLwrlsdpan() {
    return lwrlsdpan;
  }

  /** DPAN - device permanent account number */
  @JsonProperty("lwrlsdpan")
  public void setLwrlsdpan(String lwrlsdpan) {
    this.lwrlsdpan = lwrlsdpan;
  }

  @Override
  public String toString() {
    return ToStringBuilder.reflectionToString(this);
  }

  @JsonAnyGetter
  public Map<String, Object> getAdditionalProperties() {
    return this.additionalProperties;
  }

  @JsonAnySetter
  public void setAdditionalProperty(String name, Object value) {
    this.additionalProperties.put(name, value);
  }

  @Override
  public int hashCode() {
    return new HashCodeBuilder()
        .append(lwrcw7etrid)
        .append(lwrisoact)
        .append(lwrisoaid)
        .append(cr41tcntry2)
        .append(cr41wwic)
        .append(lwrdgod)
        .append(lwrdtim)
        .append(lwrisoamt)
        .append(lwrcc7kfrc)
        .append(lwrisocur)
        .append(lwrawFrgnind)
        .append(lwrrrKapc)
        .append(lwrrr7dap6)
        .append(lwrcxMgstrpcd)
        .append(lwrcwDadc)
        .append(cr41mcc)
        .append(lwrgmZprobfb)
        .append(lwrdx7ksep)
        .append(lwrcw7dlog)
        .append(lwrcwEcbcret)
        .append(lwrdx7kjdd)
        .append(lwrsorc)
        .append(lwrisfld22)
        .append(lwrisdf61eci1)
        .append(lwrcc7komcc)
        .append(lwrdwCwdcde)
        .append(lwrdwFwdcde)
        .append(lwrlsdpan)
        .append(additionalProperties)
        .toHashCode();
  }

  @Override
  public boolean equals(Object other) {
    if (other == this) {
      return true;
    }
    if ((other instanceof AuthSchema) == false) {
      return false;
    }
    AuthSchema rhs = ((AuthSchema) other);
    return new EqualsBuilder()
        .append(lwrcw7etrid, rhs.lwrcw7etrid)
        .append(lwrisoact, rhs.lwrisoact)
        .append(lwrisoaid, rhs.lwrisoaid)
        .append(cr41tcntry2, rhs.cr41tcntry2)
        .append(cr41wwic, rhs.cr41wwic)
        .append(lwrdgod, rhs.lwrdgod)
        .append(lwrdtim, rhs.lwrdtim)
        .append(lwrisoamt, rhs.lwrisoamt)
        .append(lwrcc7kfrc, rhs.lwrcc7kfrc)
        .append(lwrisocur, rhs.lwrisocur)
        .append(lwrawFrgnind, rhs.lwrawFrgnind)
        .append(lwrrrKapc, rhs.lwrrrKapc)
        .append(lwrrr7dap6, rhs.lwrrr7dap6)
        .append(lwrcxMgstrpcd, rhs.lwrcxMgstrpcd)
        .append(lwrcwDadc, rhs.lwrcwDadc)
        .append(cr41mcc, rhs.cr41mcc)
        .append(lwrgmZprobfb, rhs.lwrgmZprobfb)
        .append(lwrdx7ksep, rhs.lwrdx7ksep)
        .append(lwrcw7dlog, rhs.lwrcw7dlog)
        .append(lwrcwEcbcret, rhs.lwrcwEcbcret)
        .append(lwrdx7kjdd, rhs.lwrdx7kjdd)
        .append(lwrsorc, rhs.lwrsorc)
        .append(lwrisfld22, rhs.lwrisfld22)
        .append(lwrisdf61eci1, rhs.lwrisdf61eci1)
        .append(lwrcc7komcc, rhs.lwrcc7komcc)
        .append(lwrdwCwdcde, rhs.lwrdwCwdcde)
        .append(lwrdwFwdcde, rhs.lwrdwFwdcde)
        .append(lwrlsdpan, rhs.lwrlsdpan)
        .append(additionalProperties, rhs.additionalProperties)
        .isEquals();
  }
}
