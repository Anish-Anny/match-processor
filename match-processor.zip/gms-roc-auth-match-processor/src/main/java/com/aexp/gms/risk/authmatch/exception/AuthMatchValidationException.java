package com.aexp.gms.risk.authmatch.exception;

public class AuthMatchValidationException extends AuthMatchException {

  private static final long serialVersionUID = 1L;

  public AuthMatchValidationException() {
    super();
  }

  public AuthMatchValidationException(String msg, Throwable e) {
    super(msg, e);
  }

  public AuthMatchValidationException(String message) {
    super(message);
  }

  public AuthMatchValidationException(Throwable t) {
    super(t);
  }
}
