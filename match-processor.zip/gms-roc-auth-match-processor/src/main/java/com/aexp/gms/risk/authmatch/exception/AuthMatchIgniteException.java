package com.aexp.gms.risk.authmatch.exception;

public class AuthMatchIgniteException extends AuthMatchException {

  private static final long serialVersionUID = 1L;

  public AuthMatchIgniteException() {
    super();
  }

  public AuthMatchIgniteException(String msg, Throwable e) {
    super(msg, e);
  }

  public AuthMatchIgniteException(String message) {
    super(message);
  }

  public AuthMatchIgniteException(Throwable t) {
    super(t);
  }
}
