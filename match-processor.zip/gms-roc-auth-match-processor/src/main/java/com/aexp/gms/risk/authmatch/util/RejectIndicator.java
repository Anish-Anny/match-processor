package com.aexp.gms.risk.authmatch.util;

import java.util.HashMap;
import java.util.Map;

public enum RejectIndicator {
  Release("S"),
  Reject("F"),
  Ineligible("I"),
  Error("E");
  private String code;

  RejectIndicator(String code) {
    this.code = code;
  }

  public String code() {
    return code;
  }

  private static final Map<String, String> sMap = new HashMap<>();

  static {
    for (final RejectIndicator d : RejectIndicator.values()) {

      sMap.put(d.toString(), d.code());
    }
  }

  public static String fromCode(final String code) {

    final String element = sMap.get(code);
    if (element != null) {

      return element;
    }
    return "E";
  }
}
