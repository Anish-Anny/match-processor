package com.aexp.gms.risk.authmatch.controller;

import com.aexp.gms.risk.authmatch.model.ResponseMetaData;
import com.aexp.gms.risk.authmatch.model.RocMatchRequest;
import com.aexp.gms.risk.authmatch.model.SubmissionMatchResponse;
import com.aexp.gms.risk.authmatch.services.AuthMatchService;
import com.aexp.gms.risk.authmatch.util.AuthMatchLog;
import com.aexp.gms.risk.authmatch.util.AuthMatchUtil;
import com.aexp.gms.risk.authmatch.util.ITier;
import com.fasterxml.jackson.databind.ser.FilterProvider;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import java.time.Instant;
import java.util.HashSet;
import java.util.Set;
import javax.validation.*;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping
public class AuthMatchController {

  private static final String CLASS_NAME = "AuthMatchController";
  private AuthMatchLog authMatchLog =
      new AuthMatchLog(AuthMatchController.class.getPackage().getName());
  private final Logger LOGGER = LoggerFactory.getLogger(AuthMatchController.class);
  private final AuthMatchService serviceLayer;

  static ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
  private static final String BONUS_PAY_REVERSAL_CODE = "020000";
  private static final String DEBIT_REVERSAL_CODE = "020809";
  private static final String DISBURSE_REVERSAL_CODE = "020810";
  private static final Set<String> reversalSet = new HashSet<String>();

  {
    reversalSet.add(BONUS_PAY_REVERSAL_CODE);
    reversalSet.add(DEBIT_REVERSAL_CODE);
    reversalSet.add(DISBURSE_REVERSAL_CODE);
  }

  @RequestMapping(method = RequestMethod.GET, value = "/v1/healthcheck")
  public ResponseEntity checkHealth() {
    return ResponseEntity.status(HttpStatus.OK).body("I am healthy!");
  }

  @RequestMapping(method = RequestMethod.GET, value = "/cachehealthcheck")
  public ResponseEntity checkCacheHealth() {
    return serviceLayer.checkIgniteHealth()
        ? ResponseEntity.status(HttpStatus.OK).body("I am healthy and cache is healthy!")
        : ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("I am not healthy!");
  }

  /**
   * This API resource makes compute ignite call to match ROC transaction with CAS stored in Ignite
   * Cache.
   *
   * @param matchRequest
   * @return ResponseEntity
   */
  @RequestMapping(
      method = RequestMethod.POST,
      value = "/v1/submissions/rocmatchrequest",
      consumes = "application/json",
      produces = "application/json;charset=UTF-8")
  @ResponseBody
  @GetMapping("/ignoreProperties")
  public ResponseEntity submissionROCMatchRequest(@RequestBody RocMatchRequest matchRequest) {
    LOGGER.debug(
        "{}\"Message\":\"request parameter {}, thread id {}\"}",
        authMatchLog.getCommonLogAttributes("S", "GR0430", matchRequest),
        matchRequest.getRocAuthorizationTransactionId(),
        Thread.currentThread().getId(),
        ITier.REQUESTHANDLER,
        CLASS_NAME,
        "AuthMatchController");
    long startTime = Instant.now().toEpochMilli();

    Validator validator = factory.getValidator();
    Set<ConstraintViolation<RocMatchRequest>> violations = validator.validate(matchRequest);
    if (!violations.isEmpty()) {
      ResponseMetaData responseMetaData = new ResponseMetaData();
      responseMetaData.setCode(String.valueOf(HttpStatus.BAD_REQUEST.value()));
      responseMetaData.setShortMessage(getViolationMessage(violations));
      SubmissionMatchResponse submissionMatchResponse = new SubmissionMatchResponse();
      submissionMatchResponse.setResponseMetaData(responseMetaData);
      return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(submissionMatchResponse);
    }
    ResponseMetaData responseMetaData = new ResponseMetaData();
    responseMetaData.setCode(String.valueOf(HttpStatus.OK.value()));
    responseMetaData.setShortMessage(HttpStatus.OK.getReasonPhrase());

    // Make service layer call
    SubmissionMatchResponse submissionMatchResponse = serviceLayer.matchRequest(matchRequest);
    submissionMatchResponse.setRocAcquirerReferenceNumber(
        matchRequest.getRocAcquirerReferenceNumber());
    String responseTime = AuthMatchUtil.getAPIResponseTime(startTime);
    responseMetaData.setResponseTime(responseTime);

    submissionMatchResponse.setResponseMetaData(responseMetaData);
    // Json filter
    SimpleBeanPropertyFilter Submissionfilter =
        SimpleBeanPropertyFilter.filterOutAllExcept(
            "rocAcquirerReferenceNumber",
            "ramTier",
            "responseMetaData",
            "ramIndicator",
            "resultRemarks");
    FilterProvider filterSubmissionFields =
        new SimpleFilterProvider().addFilter("SubmissionMatchResponseFilter", Submissionfilter);
    MappingJacksonValue filterSubmissionMatchResponse =
        new MappingJacksonValue(submissionMatchResponse);
    filterSubmissionMatchResponse.setFilters(filterSubmissionFields);
    LOGGER.debug(
        "{}\"Message\":\"request parameter {}, thread id {}\"}",
        authMatchLog.getCommonLogAttributes("S", "GR4000", submissionMatchResponse),
        matchRequest.getRocAuthorizationTransactionId(),
        Thread.currentThread().getId(),
        ITier.REQUESTHANDLER,
        CLASS_NAME,
        "AuthMatchController");
    LOGGER.debug(
        "\"TID\":\"{}\", \"CM\":\"{}\",\"ROC_Ind_Code\":\"{}\",\"Roc_Approval_Cd\":\"{}\",\"ROC_SE\":\"{}\",\"ROC_AMT\":\"{}\",\"Message\":\"thread id {}\"}",
        matchRequest.getRocAuthorizationTransactionId(),
        (matchRequest.getRocCardNumber().substring(0, 11))
            + StringUtils.repeat("X", matchRequest.getRocCardNumber().length() - 11),
        matchRequest.getSocSEIndustryCategoryCode(),
        matchRequest.getRocAuthDAC(),
        matchRequest.getRocSENumber(),
        matchRequest.getRocAmountUSD(),
        Thread.currentThread().getId(),
        ITier.REQUESTHANDLER,
        CLASS_NAME,
        "AuthMatchController");

    return ResponseEntity.status(HttpStatus.OK).body(filterSubmissionMatchResponse);
  }

  @RequestMapping(
      method = RequestMethod.POST,
      value = "/v2/submissions/rocmatchrequest",
      consumes = "application/json",
      produces = "application/json;charset=UTF-8")
  @ResponseBody
  public ResponseEntity submissionROCMatchRequestV2(@RequestBody RocMatchRequest matchRequest) {
    LOGGER.info(
        "{}\"Message\":\"request parameter {}, thread id {}\"}",
        authMatchLog.getCommonLogAttributes("S", "GR0430", matchRequest),
        matchRequest.getRocAuthorizationTransactionId(),
        Thread.currentThread().getId(),
        ITier.REQUESTHANDLER,
        CLASS_NAME,
        "AuthMatchController");
    long startTime = Instant.now().toEpochMilli();

    Validator validator = factory.getValidator();
    Set<ConstraintViolation<RocMatchRequest>> violations = validator.validate(matchRequest);

    Set<String> properties = new HashSet<String>();
    properties.add("rocAcquirerReferenceNumber");
    properties.add("ramTier");
    properties.add("responseMetaData");
    properties.add("ramIndicator");
    properties.add("resultRemarks");
    properties.add("caspKey");
    properties.add("posDataCode");
    properties.add("eciIndicator");
    properties.add("approvalCode");
    properties.add("mcc");
    properties.add("voiceAuthIndicator");
    properties.add("rejIndicator");
    properties.add("ecbCreationTime");
    properties.add("transactionId");
    SimpleBeanPropertyFilter Submissionfilter =
        SimpleBeanPropertyFilter.filterOutAllExcept(properties);
    FilterProvider filterSubmissionFields =
        new SimpleFilterProvider().addFilter("SubmissionMatchResponseFilter", Submissionfilter);
    if (!violations.isEmpty()) {
      ResponseMetaData responseMetaData = new ResponseMetaData();
      responseMetaData.setCode(String.valueOf(HttpStatus.BAD_REQUEST.value()));
      responseMetaData.setShortMessage(getViolationMessage(violations));
      SubmissionMatchResponse submissionMatchResponse = new SubmissionMatchResponse();
      submissionMatchResponse.setResponseMetaData(responseMetaData);

      MappingJacksonValue filterSubmissionMatchResponse =
          new MappingJacksonValue(submissionMatchResponse);
      filterSubmissionMatchResponse.setFilters(filterSubmissionFields);
      return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(filterSubmissionMatchResponse);
    }
    ResponseMetaData responseMetaData = new ResponseMetaData();
    responseMetaData.setCode(String.valueOf(HttpStatus.OK.value()));
    responseMetaData.setShortMessage(HttpStatus.OK.getReasonPhrase());
    matchRequest.setReversalCode(
        (!org.springframework.util.StringUtils.isEmpty(
                matchRequest.getOriRocAcquirerReferenceNumber()))
            ? true
            : false);
    // Make service layer call
    SubmissionMatchResponse submissionMatchResponse = null;

    if (matchRequest.isReversalCode()) {
      if (reversalSet.contains(matchRequest.getRocISOProcessingCode())) {
        serviceLayer.reversalRequest(matchRequest);
      }
      return ResponseEntity.status(HttpStatus.OK).body(new SubmissionMatchResponse());
    } else {
      matchRequest.setReversalCode(false);
      submissionMatchResponse = serviceLayer.matchRequest(matchRequest);
    }

    submissionMatchResponse.setRocAcquirerReferenceNumber(
        matchRequest.getRocAcquirerReferenceNumber());
    String responseTime = AuthMatchUtil.getAPIResponseTime(startTime);
    responseMetaData.setResponseTime(responseTime);

    submissionMatchResponse.setResponseMetaData(responseMetaData);
    MappingJacksonValue filterSubmissionMatchResponse =
        new MappingJacksonValue(submissionMatchResponse);
    filterSubmissionMatchResponse.setFilters(filterSubmissionFields);
    LOGGER.info(
        "{} \"TID\":\"{}\",\"ROC_SE\":\"{}\",\"ROC_AMT\":\"{}\",\"NetworkGeneratedID\":\"{}\",\"rocLocalAmount\":\"{}\",\"rocLocalAmountCurrency\":\"{}\",\"rocLocalDecimalPlaces\":\"{}\",\"rocProcessingCode\":\"{}\",\"Message\":\"thread id {}\"}",
        authMatchLog.getCommonLogAttributes("S", "GR4000", submissionMatchResponse),
        matchRequest.getRocAuthorizationTransactionId(),
        matchRequest.getRocSENumber(),
        matchRequest.getRocAmountUSD(),
        matchRequest.getRocNetworkGeneratedTID(),
        matchRequest.getRocLocalAmount(),
        matchRequest.getRocLocalAmountCurrency(),
        matchRequest.getRocLocalDecimalPlaces(),
        matchRequest.getRocISOProcessingCode(),
        Thread.currentThread().getId(),
        ITier.REQUESTHANDLER,
        CLASS_NAME,
        "AuthMatchController");
    return ResponseEntity.status(HttpStatus.OK).body(filterSubmissionMatchResponse);
  }

  @RequestMapping(method = RequestMethod.GET, value = "/v1/submissions/validatecache")
  @ResponseBody
  public ResponseEntity validateCacheVersion() {

    LOGGER.debug(
        "{}\"Message\":\"AuthMatchController validate cache, thread id {}\"}",
        authMatchLog.getCommonLogAttributes("S", "GR0002"),
        Thread.currentThread().getId(),
        ITier.REQUESTHANDLER,
        CLASS_NAME,
        CLASS_NAME);

    ResponseMetaData responseMetaData = new ResponseMetaData();
    responseMetaData.setCode(String.valueOf(HttpStatus.OK.value()));
    responseMetaData.setShortMessage(HttpStatus.OK.getReasonPhrase());

    // Make service layer call
    serviceLayer.broadCastCacheVersion();

    return ResponseEntity.status(HttpStatus.OK).body(responseMetaData);
  }

  @RequestMapping(method = RequestMethod.GET, value = "/maintain/resetlatch/{latch_name}")
  public ResponseEntity resetLatch(@PathVariable("latch_name") String latch_name) {

    LOGGER.info(
        "{}\"Message\":\"In Reset Letach , thread id {} - {}\"}",
        authMatchLog.getCommonLogAttributes("S", "GR0010"),
        Thread.currentThread().getId(),
        latch_name,
        ITier.REQUESTHANDLER,
        CLASS_NAME,
        "AuthMatchController");

    Instant.now().toEpochMilli();

    serviceLayer.refreshCountDownLatch(latch_name);

    return ResponseEntity.status(HttpStatus.OK)
        .body(String.format("Success - Reset Latch - %s ", latch_name));
  }

  private String getViolationMessage(Set<? extends ConstraintViolation> violations) {
    StringBuilder stringBuilder = new StringBuilder();
    for (ConstraintViolation cv : violations) {
      stringBuilder.append(cv.getPropertyPath()).append(" ").append(cv.getMessage()).append(",");
    }
    stringBuilder.deleteCharAt(stringBuilder.lastIndexOf(","));
    return stringBuilder.toString();
  }

  // @Autowired
  public AuthMatchController(@Qualifier("authMatchServiceImpl") AuthMatchService serviceLayer) {
    LOGGER.info(
        "{}\"Message\":\"AuthMatchServiceImpl constructor, thread id {}\"}",
        authMatchLog.getCommonLogAttributes("S", "GR0003"),
        Thread.currentThread().getId(),
        ITier.REQUESTHANDLER,
        CLASS_NAME,
        CLASS_NAME);

    this.serviceLayer = serviceLayer;
    LOGGER.info(
        "{}\"Message\":\"Launched thread\"}",
        authMatchLog.getCommonLogAttributes("S", "GR0004"),
        ITier.REQUESTHANDLER,
        CLASS_NAME,
        CLASS_NAME);
  }

  @RequestMapping(method = RequestMethod.POST, value = "/v2/submissions/clusterUpdate")
  @ResponseBody
  public ResponseEntity cacheSynchUpProcess(
      @RequestBody String request,
      @RequestHeader(name = "ax-correlation-id", required = false, defaultValue = "")
          String axCorrelationId,
      @RequestHeader(name = "rtf-client-path", required = false, defaultValue = "")
          String rtfClientPath) {
    ResponseMetaData responseMetaData = null;
    long startTime = Instant.now().toEpochMilli();
    try {
      this.serviceLayer.processCacheUpdate(request, rtfClientPath, axCorrelationId);
      responseMetaData = new ResponseMetaData();
      responseMetaData.setCode("200");
      responseMetaData.setShortMessage("OK");
      String responseTime = AuthMatchUtil.getAPIResponseTime(startTime);
      responseMetaData.setResponseTime(responseTime);
      LOGGER.debug("Cahce Synch Up Request Process End");
    } catch (Exception e) {
      // TODO Auto-generated catch block
      LOGGER.error(" Cache SynchUp Processing Error {}", e);
      responseMetaData = new ResponseMetaData();
      responseMetaData.setCode("400");
      responseMetaData.setShortMessage("OK");
      String responseTime = AuthMatchUtil.getAPIResponseTime(startTime);
      responseMetaData.setResponseTime(responseTime);
    }
    return ResponseEntity.status(HttpStatus.OK).body(responseMetaData);
  }

  public AuthMatchService getServiceLayer() {
    return serviceLayer;
  }
}
