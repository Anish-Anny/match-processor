package com.aexp.gms.risk.data;

import com.aexp.gms.risk.authmatch.model.*;
import com.aexp.gms.risk.authmatch.model.RocAuthMatchResult;
import com.aexp.gms.risk.authmatch.model.RocMatchRequest;
import java.text.ParseException;

public interface AuthMatchDatabaseDAO {

  public CasAuthTransIdCardCacheBean getTransByTidData(
      RocMatchRequest request, String approveDenyCode);

  public CasAuthTransIdCardCacheBean getTransByCardAndSe(
      RocMatchRequest request, String approveDenyCode);

  public CasAuthCardAccessCode6CacheBean getAuthByDac6AndSe6(
      RocMatchRequest request, String approveDenyCode);

  public boolean deleteTransByTid(String transactionId, String cardNumber, String approveDenyCode);

  public CasAuthCardAccessCode2CacheBean getAuthByDac2AndSe6(
      RocMatchRequest request, String approveDenyCode);

  public RocAuthMatchResult getMatchResult(String roc_arn) throws ParseException;
}
