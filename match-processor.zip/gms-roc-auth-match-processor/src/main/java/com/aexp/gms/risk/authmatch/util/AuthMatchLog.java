package com.aexp.gms.risk.authmatch.util;

import com.aexp.gms.risk.authmatch.model.RocMatchRequest;
import com.aexp.gms.risk.authmatch.model.SubmissionMatchResponse;
import org.apache.commons.lang.StringUtils;

/**
 * Package name to be passed as parameter in constructor. Make this as class level global variable.
 * MerchantLog merchantLog = new
 * MerchantLog(RiskSubmonRulesExecutionProcessor.class.getPackage().getName());
 *
 * <p>Info statements will not have application specific attributes ->
 * LOGGER.info(merchantLog.getCommonLogAttributes() + "|json message == null, returning");
 *
 * <p>Errors from Exception block should be logged with application specific attributes. Exception
 * object passed to LOGGER will print stacktrace ->
 * LOGGER.error(merchantLog.getSpecificLogAttributes("F", "GR100") + "|\"Exception in overall
 * try/catch: \" ",e);
 */
public class AuthMatchLog {
  // Common or Generic attributes
  private String packageName;
  private String transactionResult;
  private String transactionResultCode;
  private String transactionResultSubCode;
  private String placeHolder1;
  private String placeHolder2;

  // Application specific attributes
  private String seNumber;
  private String cardNumber; // This is place holder. Perhaps masked number with last 4 digits.
  private String correlationId = "";
  private String referralCode = "";

  public AuthMatchLog(String packageName) {
    this.packageName = packageName;
  }

  public void setAppSpecificInfo(String seNumber, String correlationId) {
    this.seNumber = seNumber;
    this.correlationId = correlationId;
  }

  @Override
  public String toString() {

    return String.format(
        "[PackageName=%s|TransactionResult=%s|TransactionResultCode=%s|TransactionResultSubCode=%s|%s|%s]|CorrelationId=%s|SENumber=%s|||ReferralCode=%s|",
        packageName,
        transactionResult,
        transactionResultCode,
        transactionResultSubCode,
        placeHolder1,
        placeHolder2,
        correlationId.toString(),
        seNumber,
        referralCode);
  }

  /*public String getSpecificLogAttributes(String transactionResult, String transactionResultCode) {
      StringBuilder StringBuild =
          new StringBuilder(1000)
              .append("{\"PackageName\":\"")
              .append(packageName)
              .append("\",")
              .append("\"TransactionResult\":")
              .append("\"")
              .append(transactionResult)
              .append("\",")
              .append("\"TransactionResultCode\":\"")
              .append(transactionResultCode)
              .append("\",")
              .append("\"TransactionResultSubCode\":\"")
              .append(transactionResultSubCode)
              .append("\",")
              .append("\"\":\"")
              .append(placeHolder1)
              .append("\",")
              .append("\",")
              .append("\"\":")
              .append(placeHolder2)
              .append("\",")
              .append("\"CorrelationId\":")
              .append("\"")
              .append(correlationId.toString())
              .append("\"SENumber\":")
              .append("\"")
              .append(seNumber)
              .append("\",")
              .append("\"ReferralCode\":")
              .append("\"")
              .append(referralCode)
              .append("\",");
      return StringBuild.toString();
    }

    public String getCommonLogAttributes() {
      StringBuilder StringBuild =
          new StringBuilder(1000)
              .append("{\"PackageName\":\"")
              .append(packageName)
              .append("\",")
              .append("\"TransactionResult\":")
              .append("\"")
              .append(transactionResult)
              .append("\",")
              .append("\"TransactionResultCode\":\"")
              .append(transactionResultCode)
              .append("\",")
              .append("\"TransactionResultSubCode\":\"")
              .append(transactionResultSubCode)
              .append("\"CorrelationId\":\"")
              .append(correlationId.toString())
              .append("\",");
      return StringBuild.toString();
    }
  */
  public String getCommonLogAttributes(String transactionResult, String transactionResultCode) {
    StringBuilder StringBuild =
        new StringBuilder(1000)
            .append("{\"version\":\"")
            .append("v1.1")
            .append("\",")
            .append("{\"PackageName\":\"")
            .append(packageName)
            .append("\",")
            .append("\"TransactionResult\":\"")
            .append(transactionResult)
            .append("\",")
            .append("\"TransactionResultCode\":\"")
            .append(transactionResultCode)
            .append("\",")
            .append("\"TransactionResultSubCode\":\"")
            .append(transactionResultSubCode)
            .append("\",")
            .append("\"CorrelationId\":\"")
            .append(correlationId.toString())
            .append("\",");
    return StringBuild.toString();
  }

  public String getCommonLogAttributes(
      String transactionResult, String transactionResultCode, RocMatchRequest matchRequest) {
    StringBuilder StringBuild =
        new StringBuilder(1000)
            .append("\"TID\":\"")
            .append(matchRequest.getRocAuthorizationTransactionId())
            .append("\",")
            .append("\"CM\":\"")
            .append(matchRequest.getRocCardNumber().substring(0, 11))
            .append(StringUtils.repeat("X", matchRequest.getRocCardNumber().length() - 11))
            .append("\",")
            .append("\"ARN\":\"")
            .append(matchRequest.getRocAcquirerReferenceNumber())
            .append("\"TransactionResultCode\":\"")
            .append(transactionResultCode)
            .append("\",");
    return StringBuild.toString();
  }

  public String getCommonLogAttributes(
      String transactionResult,
      String transactionResultCode,
      SubmissionMatchResponse submissionMatchResponse) {
    StringBuilder StringBuild =
        new StringBuilder(1000)
            .append("\"RAM_Indicator\":\"")
            .append(submissionMatchResponse.getRamIndicator())
            .append("\",")
            .append("\"RAM_Tier\":\"")
            .append(submissionMatchResponse.getRamTier())
            .append("\",")
            .append("\"RiskAssessmentThreshold\":\"")
            .append(submissionMatchResponse.isRiskAssessmentThreshold())
            .append("\",")
            .append("\"RejIndicator\":\"")
            .append(submissionMatchResponse.getRejIndicator())
            .append("\",")
            .append("\"RAM_isMultipleMatchRoc\":\"")
            .append(submissionMatchResponse.isMatchedMultipleRocToAuth())
            .append("\",")
            .append("\"ARN\":\"")
            .append(submissionMatchResponse.getRocAcquirerReferenceNumber())
            .append("\",")
            .append("\"Response_Time\":\"")
            .append(submissionMatchResponse.getResponseMetaData().getResponseTime())
            .append("\",")
            .append("\"Response_Code\":\"")
            .append(submissionMatchResponse.getResponseMetaData().getCode())
            .append("\",");
    return StringBuild.toString();
  }
}
