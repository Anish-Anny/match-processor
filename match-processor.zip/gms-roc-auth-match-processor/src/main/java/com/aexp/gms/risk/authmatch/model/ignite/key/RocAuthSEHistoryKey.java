package com.aexp.gms.risk.authmatch.model.ignite.key;

public class RocAuthSEHistoryKey {
  String rocSE;
  String authSE;

  public RocAuthSEHistoryKey(String rocSE, String authSE) {
    this.rocSE = rocSE;
    this.authSE = authSE;
  }

  public String getRocSE() {
    return rocSE;
  }

  public void setRocSE(String rocSE) {
    this.rocSE = rocSE;
  }

  public String getAuthSE() {
    return authSE;
  }

  public void setAuthSE(String authSE) {
    this.authSE = authSE;
  }
}
