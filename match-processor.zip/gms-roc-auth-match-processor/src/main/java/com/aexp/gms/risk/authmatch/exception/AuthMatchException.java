package com.aexp.gms.risk.authmatch.exception;

public class AuthMatchException extends Exception {

  private static final long serialVersionUID = 1L;

  public AuthMatchException() {
    super();
  }

  public AuthMatchException(String msg, Throwable e) {
    super(msg, e);
  }

  public AuthMatchException(String message) {
    super(message);
  }

  public AuthMatchException(Throwable t) {
    super(t);
  }
}
