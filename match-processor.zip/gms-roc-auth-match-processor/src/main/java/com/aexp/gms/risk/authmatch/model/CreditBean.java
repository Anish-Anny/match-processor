package com.aexp.gms.risk.authmatch.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CreditBean {

  @JsonProperty(value = "seNumber")
  private String seNumber;

  @JsonProperty(value = "cardNumber")
  private String cardNumber;

  @JsonProperty(value = "submissionAuthorizationTransactionId")
  private String submissionAuthorizationTransactionId;

  @JsonProperty(value = "authTransactionDateTime")
  private String authTransactionDateTime;

  @JsonProperty(value = "socId")
  private String socId;

  @JsonProperty(value = "rocSubmissionDateTime")
  private String rocSubmissionDateTime;

  @JsonProperty(value = "rocAmountUSD")
  private String rocAmountUSD;

  @JsonProperty(value = "rocAmountLocal")
  private String rocAmountLocal;

  @JsonProperty(value = "rocAmountCurrencyCode")
  private String rocAmountCurrencyCode;

  @JsonProperty(value = "seIndustryCategoryCode")
  private String seIndustryCategoryCode;

  @JsonProperty(value = "invoiceRocReferenceNumber")
  private String invoiceRocReferenceNumber;

  @JsonProperty(value = "acquirerReferenceNumber")
  private String acquirerReferenceNumber;

  @JsonProperty(value = "socAcquirerReferenceNumber")
  private String socAcquirerReferenceNumber;

  @JsonProperty(value = "transactionType")
  private String transactionType;

  public CreditBean() {}

  public CreditBean(
      String seNumber,
      String cardNumber,
      String submissionAuthorizationTransactionId,
      String authTransactionDateTime,
      String socId,
      String rocSubmissionDateTime,
      String rocAmountUSD,
      String rocAmountLocal,
      String rocAmountCurrencyCode,
      String seIndustryCategoryCode,
      String invoiceRocReferenceNumber,
      String acquirerReferenceNumber,
      String socAcquirerReferenceNumber,
      String transactionType) {
    this.cardNumber = cardNumber;
    this.seNumber = seNumber;
    this.submissionAuthorizationTransactionId = submissionAuthorizationTransactionId;
    this.authTransactionDateTime = authTransactionDateTime;
    this.socId = socId;
    this.rocSubmissionDateTime = rocSubmissionDateTime;
    this.rocAmountUSD = rocAmountUSD;
    this.rocAmountLocal = rocAmountLocal;
    this.rocAmountCurrencyCode = rocAmountCurrencyCode;
    this.seIndustryCategoryCode = seIndustryCategoryCode;
    this.invoiceRocReferenceNumber = invoiceRocReferenceNumber;
    this.acquirerReferenceNumber = acquirerReferenceNumber;
    this.socAcquirerReferenceNumber = socAcquirerReferenceNumber;
    this.transactionType = transactionType;
  }

  /*public String getSeNumber() {
    return seNumber;
  }

  public void setSeNumber(String seNumber) {
    this.seNumber = seNumber;
  }

  public String getCardNumber() {
    return cardNumber;
  }

  public void setCardNumber(String cardNumber) {
    this.cardNumber = cardNumber;
  }

  public String getSubmissionAuthorizationTransactionId() {
    return submissionAuthorizationTransactionId;
  }

  public void setSubmissionAuthorizationTransactionId(String submissionAuthorizationTransactionId) {
    this.submissionAuthorizationTransactionId = submissionAuthorizationTransactionId;
  }

  public String getAuthTransactionDateTime() {
    return authTransactionDateTime;
  }

  public void setAuthTransactionDateTime(String authTransactionDateTime) {
    this.authTransactionDateTime = authTransactionDateTime;
  }

  public String getSocId() {
    return socId;
  }

  public void setSocId(String socId) {
    this.socId = socId;
  }

  public String getRocSubmissionDateTime() {
    return rocSubmissionDateTime;
  }

  public void setRocSubmissionDateTime(String rocSubmissionDateTime) {
    this.rocSubmissionDateTime = rocSubmissionDateTime;
  }

  public String getRocAmountUSD() {
    return rocAmountUSD;
  }

  public void setRocAmountUSD(String rocAmountUSD) {
    this.rocAmountUSD = rocAmountUSD;
  }

  public String getRocAmountLocal() {
    return rocAmountLocal;
  }

  public void setRocAmountLocal(String rocAmountLocal) {
    this.rocAmountLocal = rocAmountLocal;
  }

  public String getRocAmountCurrencyCode() {
    return rocAmountCurrencyCode;
  }

  public void setRocAmountCurrencyCode(String rocAmountCurrencyCode) {
    this.rocAmountCurrencyCode = rocAmountCurrencyCode;
  }

  public String getSeIndustryCategoryCode() {
    return seIndustryCategoryCode;
  }

  public void setSeIndustryCategoryCode(String seIndustryCategoryCode) {
    this.seIndustryCategoryCode = seIndustryCategoryCode;
  }

  public String getInvoiceRocReferenceNumber() {
    return invoiceRocReferenceNumber;
  }

  public void setInvoiceRocReferenceNumber(String invoiceRocReferenceNumber) {
    this.invoiceRocReferenceNumber = invoiceRocReferenceNumber;
  }

  public String getAcquirerReferenceNumber() {
    return acquirerReferenceNumber;
  }

  public void setAcquirerReferenceNumber(String acquirerReferenceNumber) {
    this.acquirerReferenceNumber = acquirerReferenceNumber;
  }

  public String getSocAcquirerReferenceNumber() {
    return socAcquirerReferenceNumber;
  }

  public void setSocAcquirerReferenceNumber(String socAcquirerReferenceNumber) {
    this.socAcquirerReferenceNumber = socAcquirerReferenceNumber;
  }

  public String getTransactionType() {
    return transactionType;
  }

  public void setTransactionType(String transactionType) {
    this.transactionType = transactionType;
  }*/
  /*
  @Override
  public String toString() {
    // return String.format("CreditBean
    // [cardNumber=%s,seNumber=%s,submissionAuthorizationTransactionId=%s,rocSubmissionDateTime=%s,transactionType=%s]",cardNumber,seNumber,submissionAuthorizationTransactionId,rocSubmissionDateTime,transactionType );
    StringBuilder StringBuild =
        new StringBuilder(1000)
            .append("{\"cardNumber\":\"")
            .append(cardNumber)
            .append("\",")
            .append("\"seNumber\":\"")
            .append(seNumber)
            .append("\",")
            .append("\"submissionAuthorizationTransactionId\":\"")
            .append(submissionAuthorizationTransactionId)
            .append("\",")
            .append("\"rocSubmissionDateTime\":\"")
            .append(rocSubmissionDateTime)
            .append("\"transactionType\":\"")
            .append(transactionType)
            .append("\"}");
    return StringBuild.toString();
  }*/
}
