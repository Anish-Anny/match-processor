package com.aexp.gms.risk.authmatch.dao;

import com.aexp.gmnt.imc.vo.SECharacteristics501Data;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.binary.BinaryObject;
import org.springframework.stereotype.Component;

@Component
public class SeChar501IgniteImpl implements SeChar501Dao {

  public void setIgniteProvider(IgniteProvider igniteClient) {
    this.igniteClient = igniteClient;
  }

  public SeChar501IgniteImpl() {}

  public static final String CACHE_SECHAR501DATA = "SeChar501Data";
  private IgniteProvider igniteClient;

  public SeChar501IgniteImpl(IgniteProvider igniteClient) {
    this.igniteClient = igniteClient;
  }

  public SECharacteristics501Data get(String seNumber) {
    SECharacteristics501Data seCharacteristics501Data = new SECharacteristics501Data();
    try {

      Long key = Long.parseLong(seNumber.trim());

      BinaryObject seChar501Data = getCache().get(key);

      if (seChar501Data != null && seChar501Data.hasField("topOfChain"))
        seCharacteristics501Data.setTopOfChain(seChar501Data.field("topOfChain"));
      else seCharacteristics501Data.setTopOfChain("");

      if (seChar501Data != null && seChar501Data.hasField("physAdCtryCd"))
        seCharacteristics501Data.setPhysAdCtryCd(seChar501Data.field("physAdCtryCd"));
      else seCharacteristics501Data.setPhysAdCtryCd("");

      return seCharacteristics501Data;

    } catch (Exception ex) {
      seCharacteristics501Data.setTopOfChain("");
      seCharacteristics501Data.setPhysAdCtryCd("");
      return seCharacteristics501Data;
    }
  }

  public void put(String seNumber, SECharacteristics501Data seCharacteristics501Data) {
    igniteClient
        .getIgnite()
        .cache(CACHE_SECHAR501DATA)
        .put(new Long(seNumber), seCharacteristics501Data);
  }

  private IgniteCache<Long, BinaryObject> getCache() {

    return igniteClient.getIgnite().cache(CACHE_SECHAR501DATA).withKeepBinary();
  }
}
