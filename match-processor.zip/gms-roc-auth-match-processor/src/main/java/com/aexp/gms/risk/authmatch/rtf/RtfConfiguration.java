package com.aexp.gms.risk.authmatch.rtf;

import com.aexp.rtf.client.RtfClient;
import com.aexp.rtf.client.RtfClientBuilder;
import com.aexp.rtf.client.RtfClientConfig;
import com.aexp.rtf.client.dispatch.DispatchMode;
import com.aexp.rtf.client.rest.DefaultRestAgent;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RtfConfiguration {
  /** Use private key to use RTF Security */
  @Bean
  public RtfClient rtfClient(@Value("${rtf_client_env}") String env) {

    System.setProperty(RtfClientConfig.RTF_CLIENT_OPTION, RtfClientConfig.RTF_CLIENT_OPTION_1);
    System.setProperty(RtfClientConfig.RTF_CLIENT_ENV, env);
    return RtfClientBuilder.newBuilder()
        .addDispatchAgentMap(DispatchMode.REST, new DefaultRestAgent())
        .build();
  }
}
