package com.aexp.gms.risk.authmatch.dao;

import com.aexp.gms.imc.metadata.vo.RiskThresholdKey;
import com.aexp.gms.imc.metadata.vo.RiskThresholdValue;
import com.aexp.gms.risk.authmatch.util.AuthMatchConstants;
import java.util.Calendar;
import org.apache.ignite.IgniteBinary;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.IgniteCountDownLatch;
import org.apache.ignite.binary.BinaryObject;
import org.apache.ignite.binary.BinaryObjectBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class RiskAssessmentThresholdIgniteImpl implements RiskAssessmentThresholdDao {
  public static final String CACHE_RISK_ASSESSMENT = "RiskAssessmentThresholdIgniteImpl";
  private final Logger LOGGER = LoggerFactory.getLogger(RiskAssessmentThresholdIgniteImpl.class);

  private IgniteProvider igniteClient;

  public RiskAssessmentThresholdIgniteImpl() {}

  public void setIgniteProvider(IgniteProvider igniteClient) {
    this.igniteClient = igniteClient;
  }

  public RiskAssessmentThresholdIgniteImpl(IgniteProvider igniteClient) {
    this.igniteClient = igniteClient;
  }

  public boolean isThresholdReached() {
    final IgniteCountDownLatch countDownLatch = getThresholdCountDownLatch();

    int countDown = countDownLatch.count();

    if (countDown == 0) {
      LOGGER.debug("Threshold  for {}: met", countDownLatch.name());

      return true;
    } else {
      countDownLatch.countDown();
      LOGGER.debug("Threshold  for {}: {}", countDownLatch.name(), countDownLatch.count());
      return false;
    }
  }

  private IgniteCountDownLatch getThresholdCountDownLatch() {

    int dayOfYear = Calendar.getInstance().get(Calendar.DAY_OF_YEAR);
    if (dayOfYear <= AuthMatchConstants.RISK_ASSESSMENT_THRESHOLD_TTL) {
      Calendar previousYear = Calendar.getInstance();
      dayOfYear =
          previousYear.getActualMaximum(Calendar.DAY_OF_YEAR)
              - (AuthMatchConstants.RISK_ASSESSMENT_THRESHOLD_TTL + dayOfYear);
    }

    purgeThresholdCountDownLatch(
        String.format(
            "%s-%d",
            AuthMatchConstants.IGNITE_COUNT_DOWN_CACHE,
            dayOfYear - AuthMatchConstants.RISK_ASSESSMENT_THRESHOLD_TTL));

    String newThresholdName =
        String.format(
            "%s-%d",
            AuthMatchConstants.IGNITE_COUNT_DOWN_CACHE,
            Calendar.getInstance().get(Calendar.DAY_OF_YEAR));

    createThresholdCountDownLatch(newThresholdName);

    return igniteClient
        .getIgnite()
        .countDownLatch(
            newThresholdName, // Latch name.
            AuthMatchConstants.RISK_ASSESSMENT_THRESHOLD_LIMIT, // Initial count.
            false, // Auto remove, when counter has reached zero.
            false // Create if it does not exist.
            );
  }

  public void purgeThresholdCountDownLatch(String lastThresholdCountDownLatchName) {

    IgniteCountDownLatch lastThresholdCountDownLatch =
        igniteClient
            .getIgnite()
            .countDownLatch(
                lastThresholdCountDownLatchName, // Latch name.
                AuthMatchConstants.RISK_ASSESSMENT_THRESHOLD_LIMIT, // Initial count.
                false, // Auto remove, when counter has reached zero.
                false // Create if it does not exist.
                );
    if (lastThresholdCountDownLatch != null) {
      lastThresholdCountDownLatch.countDownAll();
      lastThresholdCountDownLatch.close();
      LOGGER.debug("{} - Count Down Latch  Purged", lastThresholdCountDownLatchName);
    }
  }

  public RiskThresholdValue getThresholdValue() {

    IgniteCache<BinaryObject, BinaryObject> thresholdValuesCache =
        igniteClient.getIgnite().cache("RAM_RISK_ASSESSMENT_THRESHOLD_CACHE_V1").withKeepBinary();

    IgniteBinary binary = igniteClient.getIgnite().binary();
    BinaryObjectBuilder builder = binary.builder("com.aexp.gms.imc.metadata.vo.RiskThresholdKey");
    builder.setField("metaDataKey", RiskThresholdKey.DEFAULT_METADATA_KEY);

    RiskThresholdValue riskThresholdValue = null;
    BinaryObject riskThrosholdValueBean = thresholdValuesCache.get(builder.build());
    if (riskThrosholdValueBean != null) {

      riskThresholdValue =
          new RiskThresholdValue(
              RiskThresholdKey.DEFAULT_METADATA_KEY,
              riskThrosholdValueBean.field("riskAssessmentThresholdAmount"),
              riskThrosholdValueBean.field("riskAssessmentPerDayThreshold"),
              riskThrosholdValueBean.field("modifiedTime"));

      LOGGER.debug(
          "{} Threshold : {} - Threshold Count ,{} - Threshold Amount, {} - Modified Time",
          RiskThresholdKey.DEFAULT_METADATA_KEY,
          riskThresholdValue.getRiskAssessmentPerDayThreshold(),
          riskThresholdValue.getRiskAssessmentThresholdAmount(),
          riskThresholdValue.getModifiedTime());
    } else {

      LOGGER.error(
          "Risk Assessment Threshold Not Defined for Key - {}",
          RiskThresholdKey.DEFAULT_METADATA_KEY);
    }

    return riskThresholdValue;
  }

  public void createThresholdCountDownLatch(String thresholdCountDownLatchName) {

    RiskThresholdValue riskThresholdValue = getThresholdValue();
    igniteClient
        .getIgnite()
        .countDownLatch(
            thresholdCountDownLatchName, // Latch name.
            riskThresholdValue != null
                ? riskThresholdValue.getRiskAssessmentPerDayThreshold()
                : 0, // Initial count.
            false, // Auto remove, when counter has reached zero.
            true); // Create if it does not exist.

    LOGGER.debug("{} - Count Down Latch  CREATED", thresholdCountDownLatchName);
  }
}
