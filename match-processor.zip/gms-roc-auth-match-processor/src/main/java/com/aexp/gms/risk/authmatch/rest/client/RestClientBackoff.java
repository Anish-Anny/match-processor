package com.aexp.gms.risk.authmatch.rest.client;

import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RestClientBackoff {

  private final Logger log = LoggerFactory.getLogger(RestClientBackoff.class);

  public void backoffJitter(int tryNumber, int backoffTime, int jitterRange) {
    if (tryNumber == 0) // don't wait on first try
    return;

    long waitTime =
        ThreadLocalRandom.current()
            .nextLong(
                (backoffTime * tryNumber) - jitterRange, (backoffTime * tryNumber) + jitterRange);
    try {
      TimeUnit.MILLISECONDS.sleep(waitTime);
    } catch (InterruptedException e) {
      log.error("{} Backoff/jitter thread interrupted:", e.getMessage());
    }
  }
}
