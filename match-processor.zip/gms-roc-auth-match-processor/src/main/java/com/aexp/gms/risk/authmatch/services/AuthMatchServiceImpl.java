package com.aexp.gms.risk.authmatch.services;

import com.aexp.gmnt.imc.compute.global.IGmntIMCompute;
import com.aexp.gms.imc.risk.rules.vo.keys.CasAuthCardAccessCode2CacheKey;
import com.aexp.gms.imc.risk.rules.vo.keys.CasAuthCardAccessCode6CacheKey;
import com.aexp.gms.imc.risk.rules.vo.keys.CasAuthTransIdCardCacheKey;
import com.aexp.gms.risk.authmatch.dao.AuthMatchDAO;
import com.aexp.gms.risk.authmatch.dao.RiskAssessmentThresholdDao;
import com.aexp.gms.risk.authmatch.dao.RocAuthSEHistoryDao;
import com.aexp.gms.risk.authmatch.dao.SeChar501Dao;
import com.aexp.gms.risk.authmatch.exception.AuthMatchSystemException;
import com.aexp.gms.risk.authmatch.model.*;
import com.aexp.gms.risk.authmatch.model.ignite.key.RocAuthSEHistoryKey;
import com.aexp.gms.risk.authmatch.model.ignite.value.RocAuthSEHistoryValue;
import com.aexp.gms.risk.authmatch.rest.client.AuthLoadClient;
import com.aexp.gms.risk.authmatch.rest.client.AuthMatchClusterUpdateAPI;
import com.aexp.gms.risk.authmatch.rest.client.CasHighRiskAssessApi;
import com.aexp.gms.risk.authmatch.util.*;
import com.aexp.gms.risk.data.CassandraMatchResultDAOImpl;
import com.aexp.gms.risk.data.RocAuthSeSubmissionHistoryDAOImpl;
import com.fasterxml.jackson.databind.MapperFeature;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.IntStream;
import org.apache.commons.lang.StringUtils;
import org.apache.ignite.binary.BinaryObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

public class AuthMatchServiceImpl implements AuthMatchService {

  private final String CLASS_NAME = "AuthMatchServiceImpl";
  private AuthMatchLog authMatchLog =
      new AuthMatchLog(AuthMatchServiceImpl.class.getPackage().getName());
  private final Logger LOGGER = LoggerFactory.getLogger(AuthMatchServiceImpl.class);
  ExecutorService executor = Executors.newFixedThreadPool(50);

  @Value("${cassandraDisableFlag}")
  private String cassandraDisableFlag;

  // @Autowired
  private AuthMatchDAO authMatchDAOImpl;

  private SeChar501Dao seChar501Dao;

  private AuthMatchCassBL authMatchCassBL;

  private com.aexp.gms.risk.data.CassandraMatchResultDAOImpl cassandraMatchResultDAO;

  private IGmntIMCompute igmntIMCCompute = new AuthMatchIgniteCompute();

  private RocAuthSEHistoryDao rocAuthSEHistoryDao;

  private RocAuthSeSubmissionHistoryDAOImpl rocAuthCassandraSeSubmissionHistoryDAO;

  private CasHighRiskAssessApi casHighRiskAssessApi;
  private RiskAssessmentThresholdDao riskAssessmentThresholdDao;

  private KafkaProducerConfig kafkaProducerConfig;

  @Value("${cacheSynchUpFlag:N}")
  private String cacheSynchUpFlag;

  @Value("${igniteTimeOut:250}")
  private Long igniteTimeOut;

  @Autowired AuthLoadClient authLoadClient;

  public AuthMatchDAO getAuthMatchDAOImpl() {
    return authMatchDAOImpl;
  }

  public void setAuthMatchDAOImpl(AuthMatchDAO authMatchDAOImpl) {
    this.authMatchDAOImpl = authMatchDAOImpl;
  }

  public CassandraMatchResultDAOImpl getCassandraMatchResultDAO() {
    return cassandraMatchResultDAO;
  }

  public void setCassandraMatchResultDAO(CassandraMatchResultDAOImpl cassandraMatchResultDAO) {
    this.cassandraMatchResultDAO = cassandraMatchResultDAO;
  }

  public IGmntIMCompute getIgmntIMCCompute() {
    return igmntIMCCompute;
  }

  public void setIgmntIMCCompute(IGmntIMCompute igmntIMCCompute) {
    this.igmntIMCCompute = igmntIMCCompute;
  }

  public CasHighRiskAssessApi getCasHighRiskAssessApi() {
    return casHighRiskAssessApi;
  }

  public void setCasHighRiskAssessApi(CasHighRiskAssessApi casHighRiskAssessApi) {
    this.casHighRiskAssessApi = casHighRiskAssessApi;
  }

  private AuthMatchClusterUpdateAPI authMatchClusterUpdateAPI;
  private com.fasterxml.jackson.databind.ObjectMapper mapper =
      new com.fasterxml.jackson.databind.ObjectMapper();

  public AuthMatchServiceImpl(
      AuthMatchDAO authMatchDAOImpl,
      SeChar501Dao seChar501Dao,
      CassandraMatchResultDAOImpl cassandraMatchResultDAO,
      AuthMatchCassBL authMatchCassBL,
      RocAuthSEHistoryDao rocAuthSEHistoryDao,
      RocAuthSeSubmissionHistoryDAOImpl rocAuthCassandraSeSubmissionHistoryDAO,
      CasHighRiskAssessApi casHighRiskAssessApi,
      RiskAssessmentThresholdDao riskAssessmentThresholdDao,
      KafkaProducerConfig kafkaProducerConfig,
      AuthMatchClusterUpdateAPI authMatchClusterUpdateAPI) {
    LOGGER.debug(
        "{}\"Message\":\"AuthMatchServiceImpl constructor\"}",
        authMatchLog.getCommonLogAttributes("S", "GR00643"),
        ITier.REQUESTHANDLER,
        CLASS_NAME,
        CLASS_NAME);
    this.authMatchDAOImpl = authMatchDAOImpl;
    this.seChar501Dao = seChar501Dao;
    this.cassandraMatchResultDAO = cassandraMatchResultDAO;
    this.authMatchCassBL = authMatchCassBL;
    this.rocAuthSEHistoryDao = rocAuthSEHistoryDao;
    this.rocAuthCassandraSeSubmissionHistoryDAO = rocAuthCassandraSeSubmissionHistoryDAO;
    this.casHighRiskAssessApi = casHighRiskAssessApi;
    this.riskAssessmentThresholdDao = riskAssessmentThresholdDao;
    this.kafkaProducerConfig = kafkaProducerConfig;
    this.authMatchClusterUpdateAPI = authMatchClusterUpdateAPI;
  }

  @Override
  public void getMessages() {}

  @Override
  public void validateAuthMatchBean() {
    System.out.println("validate bean");
  }

  @Override
  public boolean checkIgniteHealth() {
    return authMatchDAOImpl.checkIgniteHealth();
  }

  /** Makes ignite compute call. */
  @Override
  public SubmissionMatchResponse matchRequest(RocMatchRequest rocMatchRequest) {
    SubmissionMatchResponse response = null;
    long igniteStartTime = 0;
    long cassandraStartTime = 0;
    String igniteResponseTime = "";
    long casApiStarttime = 0;
    String casHighRiskAssessApiResponsetime = "";
    StringBuilder stringBuild = new StringBuilder(1000);

    try {
      igniteStartTime = Instant.now().toEpochMilli();
      populateEligibleMatchTiersList(rocMatchRequest);
      response =
          (SubmissionMatchResponse)
              igmntIMCCompute.affinityCall(
                  rocMatchRequest, rocMatchRequest.getRocCardNumber(), igniteTimeOut);
    } catch (Exception e) {
      LOGGER.error(
          "{}\"Message\":\"matchRequest Ignite {}\"}",
          authMatchLog.getCommonLogAttributes("S", "GR50231", rocMatchRequest),
          e.getMessage(),
          e);
      response = new SubmissionMatchResponse();
      response.setRamTier("T00");
    } finally {
      stringBuild
          .append("\"ARN\":\"")
          .append(rocMatchRequest.getRocAcquirerReferenceNumber())
          .append("\",")
          .append("\"Ignite Response time\":\"")
          .append(AuthMatchUtil.getAPIResponseTime(igniteStartTime))
          .append("\"");
    }

    final boolean casApiCalled = response != null ? response.isRiskAssessmentThreshold() : false;
    final boolean donotDeleteFlag = response != null ? response.isDoNotDeleteFlag() : false;
    try {
      if (((response != null && response.getRamTier().equals("T00")))
          && (cassandraDisableFlag != null && !cassandraDisableFlag.equals("Y"))) {
        cassandraStartTime = Instant.now().toEpochMilli();
        response = authMatchCassBL.process(rocMatchRequest);

        stringBuild
            .append("\"Cassandra Response time\":\"")
            .append(AuthMatchUtil.getAPIResponseTime(cassandraStartTime))
            .append("\"");
      }
    } catch (Exception e) {
      stringBuild
          .append("\"Cassandra Response time\":\"")
          .append(AuthMatchUtil.getAPIResponseTime(cassandraStartTime));
      LOGGER.error(
          "{}\"Message\": {} \"MatchRequest Service {}, {}\"}",
          authMatchLog.getCommonLogAttributes("S", "GR5501"),
          stringBuild,
          e.getMessage(),
          e);
    }
    try {
      final boolean isMatched = response != null ? response.isMatched() : false;
      if (!isMatched) {
        long prevMatchStartTime = Instant.now().toEpochMilli();
        response = authMatchCassBL.matchByPreviousRecords(rocMatchRequest, response);
        if (response.isFromPrevMatch()) {
          stringBuild
              .append("\"Previous Match Response time\":\"")
              .append(AuthMatchUtil.getAPIResponseTime(prevMatchStartTime))
              .append("\"");
          LOGGER.info(
              "{} Remarks {} {}",
              authMatchLog.getCommonLogAttributes("S", "GR0013_PREVIOUS_MATCH", rocMatchRequest),
              response.getResultRemarks(),
              stringBuild);
          return response;
        }
        if (casApiCalled) {
          RiskAssessmentRequest request = new RiskAssessmentRequest();
          request.setPrimary_account_number(rocMatchRequest.getRocCardNumber());
          request.setMerchant_number(rocMatchRequest.getRocSENumber());
          request.setRequested_amount(new BigDecimal(rocMatchRequest.getRocAmountUSD()));
          request.setTransaction_id(rocMatchRequest.getRocAuthorizationTransactionId());
          casApiStarttime = Instant.now().toEpochMilli();

          HighRiskAssesmentResponse riskAssessmentResponse =
              casHighRiskAssessApi.callApi(new HighRiskAssesmentRequest(request));

          stringBuild
              .append("\"Cas Risk Assessment API Response time\":\"")
              .append(AuthMatchUtil.getAPIResponseTime(casApiStarttime))
              .append("\"");

          if (riskAssessmentResponse != null
              && riskAssessmentResponse.getRisk_assessment() != null
              && riskAssessmentResponse.getRisk_assessment().getResponse_message() != null) {
            String responseMessage =
                riskAssessmentResponse.getRisk_assessment().getResponse_message();
            response.setRejIndicator(RejectIndicator.fromCode(responseMessage));
          }
        }
      }
      this.populateProcessDate(response);
      final SubmissionMatchResponse submissionMatchResponse = response;
      final String responseTime = stringBuild.toString();
      // Make async call to remove records from cache for matched records.
      Runnable cleanupProcess =
          () -> {
            boolean csPublishInd = false;
            boolean cassandraInd = false;
            boolean cacheRemoveInd = false;
            try {
              String seCountryCode = null;
              try {
                //					 if (cassandraDisableFlag != null && !cassandraDisableFlag.equals("Y"))
                if (seChar501Dao != null && !isMatched) {
                  seCountryCode =
                      seChar501Dao.get(rocMatchRequest.getRocSENumber()).getPhysAdCtryCd();
                }
                cassandraMatchResultDAO.insertMatchResult(
                    rocMatchRequest, submissionMatchResponse, casApiCalled, seCountryCode);
                cassandraInd = true;
              } catch (Exception e) {
                LOGGER.error(
                    "{}\"Message\":\"insertMatchResult Cassandra {}\"} ",
                    authMatchLog.getCommonLogAttributes("S", "GR5011"),
                    e.getMessage(),
                    e);
              }

              csPublishInd =
                  this.sendResultsCornerstone(
                      rocMatchRequest,
                      casApiCalled,
                      submissionMatchResponse,
                      csPublishInd,
                      seCountryCode);
              // Run cleanup process if there is a successful match

              if (isMatched) {
                if (!donotDeleteFlag) {
                  removeCacheData(rocMatchRequest, submissionMatchResponse, true);
                  cacheRemoveInd = true;
                }
                // Fix for Invalid null value in condition for column auth_se_no
                if (rocMatchRequest.getRocSENumber() != null
                    && submissionMatchResponse.getAuthSeNumber() != null) {
                  RocAuthSEHistoryKey rocAuthSEHistoryKey =
                      new RocAuthSEHistoryKey(
                          (rocMatchRequest.getRocSENumber()),
                          StringUtils.trim(submissionMatchResponse.getAuthSeNumber()));
                  RocAuthSEHistoryValue rocAuthSEHistoryValue =
                      new RocAuthSEHistoryValue(
                          rocMatchRequest.getRocSENumber(),
                          submissionMatchResponse.getAuthSeNumber(),
                          rocMatchRequest.getRocTransactionDate());
                  rocAuthSEHistoryDao.put(rocAuthSEHistoryKey, rocAuthSEHistoryValue);
                  rocAuthCassandraSeSubmissionHistoryDAO.insertRocAuthSEHistory(
                      rocAuthSEHistoryValue);
                }
                if (this.cacheSynchUpFlag != null && this.cacheSynchUpFlag.equalsIgnoreCase("Y")) {
                  try {
                    this.authMatchClusterUpdateAPI.cacheSynchUpCall(submissionMatchResponse);
                  } catch (Exception e) {
                    LOGGER.error("Cache synchup Processing Error:", e);
                  }
                }
              }
            } catch (Exception e) {
              LOGGER.error("Async Processing Error:", e);

            } finally {
              LOGGER.info(
                  "{}\"Message\":\"Thread end {}\":Cassandra Ind {}: CS Ind {}: Cache Remove Ind {}: donotDeleteFlag {}: Remarks {}: Risk Assessment Threshold {}:{}: }",
                  authMatchLog.getCommonLogAttributes("S", "GR0013", rocMatchRequest),
                  Thread.currentThread().getName(),
                  csPublishInd,
                  cassandraInd,
                  cacheRemoveInd,
                  donotDeleteFlag,
                  submissionMatchResponse.getResultRemarks(),
                  casApiCalled,
                  responseTime,
                  ITier.REQUESTHANDLER,
                  CLASS_NAME,
                  "removeCacheData");
            }
          };
      executor.execute(cleanupProcess);
    } catch (Exception e) {
      LOGGER.error(
          "{}\"Message\": {} \"MatchRequest Service {}, {}\"}",
          authMatchLog.getCommonLogAttributes("S", "GR5501"),
          stringBuild,
          e.getMessage(),
          e);
      // cassandraResponseTime = "|Cassandra Response time :" +
      // AuthMatchUtil.getAPIResponseTime(cassandraStartTime);
    }

    return response;
  }

  public SubmissionMatchResponse reversalRequest(RocMatchRequest rocMatchRequest) {
    StringBuilder stringBuild = new StringBuilder(1000);
    String authTimeStamp = null;
    long prevMatchStartTime = Instant.now().toEpochMilli();
    SubmissionMatchResponse response = null;
    rocMatchRequest.setRocAcquirerReferenceNumber(
        rocMatchRequest.getOriRocAcquirerReferenceNumber());

    response = authMatchCassBL.matchByPreviousRecords(rocMatchRequest, response);

    if (response.isFromPrevMatch()) {
      authTimeStamp = response.getAuthDate() + " " + response.getAuthTime();
      if (!response.getRamTier().equals("T00") && isAuthLessThanTenDaysOld(authTimeStamp)) {
        response =
            authLoadClient.callAuthLoadApi(
                cassandraMatchResultDAO, response, rocMatchRequest.getRocAcquirerReferenceNumber());
        this.sendResultsCornerstone(rocMatchRequest, false, response, false, null);
      }
      stringBuild
          .append("\"Previous Match Response time\":\"")
          .append(AuthMatchUtil.getAPIResponseTime(prevMatchStartTime))
          .append("\"");
    }
    LOGGER.info(
        "{} Matched AuthTime {}  IsReversed {} Remarks {} {}",
        authMatchLog.getCommonLogAttributes("S", "GR0013_PREVIOUS_MATCH", rocMatchRequest),
        authTimeStamp,
        response.isReversed(),
        response.getResultRemarks(),
        stringBuild);
    return response;
  }

  private boolean sendResultsCornerstone(
      RocMatchRequest rocMatchRequest,
      final boolean casApiCalled,
      final SubmissionMatchResponse submissionMatchResponse,
      boolean csPublishInd,
      String seCountryCode) {
    try {
      RocAuthMatchResult message =
          this.preprareMatchResultMessage(
              rocMatchRequest, casApiCalled, submissionMatchResponse, seCountryCode);
      this.kafkaProducerConfig.publishROCResult(message);
      csPublishInd = true;
    } catch (Exception e) {
      LOGGER.error(
          "{}\"Message\":\"sendResultsCornerstone Error {}\"} ",
          authMatchLog.getCommonLogAttributes("S", "GR5012"),
          e.getMessage(),
          e);
    }
    return csPublishInd;
  }

  public void populateEligibleMatchTiersList(RocMatchRequest rocMatchRequest) {
    List<String> elibigleTiersList = new ArrayList<String>();
    String transactionId = rocMatchRequest.getRocAuthorizationTransactionId();
    String authDAC = rocMatchRequest.getRocAuthDAC();

    if (isTransactionIdContainAllZeroOrSpaces(transactionId)
        && isAuthDacContainAllZeroOrSpaces(authDAC)) {
      elibigleTiersList.add(AuthMatchUtil.MatchTiers.TIER_9.getValue());
      elibigleTiersList.add(AuthMatchUtil.MatchTiers.TIER_11.getValue());
    } else if (!(isTransactionIdContainAllZeroOrSpaces(transactionId))
        && (isAuthDacContainAllZeroOrSpaces(authDAC))) {
      elibigleTiersList.add(AuthMatchUtil.MatchTiers.TIER_1.getValue());
      elibigleTiersList.add(AuthMatchUtil.MatchTiers.TIER_2.getValue());
      elibigleTiersList.add(AuthMatchUtil.MatchTiers.TIER_3.getValue());
      elibigleTiersList.add(AuthMatchUtil.MatchTiers.TIER_8.getValue());
    } else if (isTransactionIdContainAllZeroOrSpaces(transactionId)
        && (!(isAuthDacContainAllZeroOrSpaces(authDAC)))) {
      elibigleTiersList.add(AuthMatchUtil.MatchTiers.TIER_4.getValue());
      elibigleTiersList.add(AuthMatchUtil.MatchTiers.TIER_5.getValue());
      elibigleTiersList.add(AuthMatchUtil.MatchTiers.TIER_6.getValue());
      elibigleTiersList.add(AuthMatchUtil.MatchTiers.TIER_7.getValue());
    } else {
      elibigleTiersList.add(AuthMatchUtil.MatchTiers.TIER_1.getValue());
      elibigleTiersList.add(AuthMatchUtil.MatchTiers.TIER_2.getValue());
      elibigleTiersList.add(AuthMatchUtil.MatchTiers.TIER_3.getValue());
      elibigleTiersList.add(AuthMatchUtil.MatchTiers.TIER_4.getValue());
      elibigleTiersList.add(AuthMatchUtil.MatchTiers.TIER_5.getValue());
      elibigleTiersList.add(AuthMatchUtil.MatchTiers.TIER_6.getValue());
      elibigleTiersList.add(AuthMatchUtil.MatchTiers.TIER_7.getValue());
      elibigleTiersList.add(AuthMatchUtil.MatchTiers.TIER_8.getValue());
    }
    rocMatchRequest.setEligibleTiersList(elibigleTiersList);
  }

  public boolean isTransactionIdContainAllZeroOrSpaces(String transactionId) {
    if (StringUtils.isEmpty(transactionId)) return true;
    Long transactionIdLong = 0L;
    try {
      transactionIdLong = Long.parseLong(transactionId);
    } catch (Exception ex) {
      transactionIdLong = 0L;
    }
    if (transactionIdLong == 0) return true;
    return false;
  }

  public boolean isAuthDacContainAllZeroOrSpaces(String authDAC) {
    Integer authDACInteger = 0;
    authDAC = StringUtils.trim(authDAC);
    if (StringUtils.isEmpty(authDAC)) return true;

    try {
      authDACInteger = Integer.parseInt(authDAC);
    } catch (Exception e) {
      return false;
    }
    if (authDACInteger == 0) return true;
    return false;
  }

  private void populateProcessDate(SubmissionMatchResponse response) {
    DateTimeFormatter sdfMatch = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    LocalDate localDate = LocalDate.now();
    String dateString = sdfMatch.format(localDate);
    DateTimeFormatter sdfTimeMatch = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    LocalDateTime localDateTime = LocalDateTime.now();
    String localDateTimeString = sdfTimeMatch.format(localDateTime);
    response.setProcessDate(dateString);
    response.setMatchTimeStamp(localDateTimeString);
  }

  private RocAuthMatchResult preprareMatchResultMessage(
      RocMatchRequest rocMatchRequest,
      final boolean casApiCalled,
      final SubmissionMatchResponse submissionMatchResponse,
      String seCountryCodeFromCache) {
    Authorization authorization = null;
    // Fix for Invalid null value in condition for column cas_pkey
    if (submissionMatchResponse.isMatched()
        && submissionMatchResponse.getAuthUniqueIdentifer() != null) {
      authorization =
          cassandraMatchResultDAO.getAuthorizationDetails(
              submissionMatchResponse.getAuthUniqueIdentifer());
    }
    if (authorization == null) {
      authorization = new Authorization();
      authorization.setCasLogIdentifier("");
      authorization.setAuthUniqeIdentifer("Not Found");
    }
    RocAuthMatchResult message =
        new RocAuthMatchResult().build(rocMatchRequest, authorization, submissionMatchResponse);
    message.setHi_risk_api_ivkd_in(casApiCalled);
    if (!submissionMatchResponse.isMatched()) {
      message.setCtry_cd(seCountryCodeFromCache);
    }

    return message;
  }

  private void removeCacheData(
      RocMatchRequest rocMatchRequest,
      SubmissionMatchResponse submissionMatchResponse,
      boolean cassandraUpdate) {
    try {
      // Delete records from cache
      if (submissionMatchResponse.getTidCardKey() != null) {
        authMatchDAOImpl.removeCacheData(
            AuthMatchConstants.CAS_AUTH_TID_CM_CACHE,
            new CasAuthTransIdCardCacheKey(submissionMatchResponse.getTidCardKey()));
      }
      if (submissionMatchResponse.getDac6CardKey() != null) {
        authMatchDAOImpl.removeCacheData(
            AuthMatchConstants.CAS_AUTH_CM_DAC6_CACHE,
            new CasAuthCardAccessCode6CacheKey(submissionMatchResponse.getDac6CardKey()));
      }
      if (submissionMatchResponse.getDac2CardKey() != null) {
        authMatchDAOImpl.removeCacheData(
            AuthMatchConstants.CAS_AUTH_CM_DAC2_CACHE,
            new CasAuthCardAccessCode2CacheKey(submissionMatchResponse.getDac2CardKey()));
      }

      // if (cassandraDisableFlag != null && !cassandraDisableFlag.equals("Y"))
      if (cassandraUpdate) {
        cassandraMatchResultDAO.deleteFromCassandraCache(
            submissionMatchResponse.getTidCardKey(),
            submissionMatchResponse.getDac6CardKey(),
            submissionMatchResponse.getDac2CardKey(),
            submissionMatchResponse.getAuthUniqueIdentifer());
        cassandraMatchResultDAO.deleteFromAuthCardAndSe(
            rocMatchRequest.getRocSENumber(), rocMatchRequest.getRocCardNumber());
      }

      String[] dac6KeyParts = submissionMatchResponse.getDac6CardKey().split("\\|");
      String[] dac2KeyParts = submissionMatchResponse.getDac2CardKey().split("\\|");

      BinaryObject transCardBinaryKey =
          (submissionMatchResponse.getTransactionId() != null)
              ? authMatchDAOImpl.getTransCardBinaryKey(
                  submissionMatchResponse.getTransactionId(),
                  rocMatchRequest.getRocCardNumber(),
                  "D")
              : null;

      if (!submissionMatchResponse.getRamTier().equals("T01") && transCardBinaryKey != null) {

        String rejectedTidCardKey =
            submissionMatchResponse.getTransactionId()
                + "|"
                + rocMatchRequest.getRocCardNumber()
                + "|"
                + "D";
        String rejectedDac2CardKey = dac2KeyParts[0] + "|" + "00" + "|" + "D";
        String rejectedDac6CardKey = dac6KeyParts[0] + "|" + "000000" + "|" + "D";

        if (authMatchDAOImpl.checkCacheData(
            transCardBinaryKey, AuthMatchConstants.CAS_AUTH_TID_CM_CACHE)) {
          authMatchDAOImpl.removeCacheData(
              AuthMatchConstants.CAS_AUTH_TID_CM_CACHE,
              new CasAuthTransIdCardCacheKey(rejectedTidCardKey));
          authMatchDAOImpl.removeCacheData(
              AuthMatchConstants.CAS_AUTH_CM_DAC6_CACHE,
              new CasAuthCardAccessCode6CacheKey(rejectedDac6CardKey));
          authMatchDAOImpl.removeCacheData(
              AuthMatchConstants.CAS_AUTH_CM_DAC2_CACHE,
              new CasAuthCardAccessCode2CacheKey(rejectedDac2CardKey));
        }
        if (cassandraUpdate
            && cassandraMatchResultDAO.checkCassandraForDeclinedTransaction(
                submissionMatchResponse.getTransactionId(), rocMatchRequest.getRocCardNumber())) {
          cassandraMatchResultDAO.deleteFromCassandraCache(
              rejectedTidCardKey,
              rejectedDac6CardKey,
              rejectedDac2CardKey,
              submissionMatchResponse.getAuthUniqueIdentifer());
        }
      }

      if (submissionMatchResponse.getRamTier().equals("T03")
          || submissionMatchResponse.getRamTier().equals("T08")) {
        if (submissionMatchResponse.getTidCardKeysList() != null
            && submissionMatchResponse.getTidCardKeysList().size() > 0) {
          submissionMatchResponse
              .getTidCardKeysList()
              .forEach(
                  key -> {
                    try {
                      authMatchDAOImpl.removeCacheData(
                          AuthMatchConstants.CAS_AUTH_TID_CM_CACHE,
                          new CasAuthTransIdCardCacheKey(key));

                      String[] keyParts = key.split("\\|");
                      String rejectedTidCardKey = keyParts[0] + "|" + keyParts[1] + "|" + "D";
                      if (transCardBinaryKey != null
                          && authMatchDAOImpl.checkCacheData(
                              transCardBinaryKey, AuthMatchConstants.CAS_AUTH_TID_CM_CACHE)) {
                        authMatchDAOImpl.removeCacheData(
                            AuthMatchConstants.CAS_AUTH_TID_CM_CACHE,
                            new CasAuthTransIdCardCacheKey(rejectedTidCardKey));
                      }
                    } catch (AuthMatchSystemException e) {
                      LOGGER.error(
                          "{}\"Message\":\"System Error {}\"}",
                          authMatchLog.getCommonLogAttributes("S", "GR0016"),
                          e.getMessage());
                    }
                  });
        }
        if (submissionMatchResponse.getDac6CardKeysList() != null
            && submissionMatchResponse.getDac6CardKeysList().size() > 0) {
          submissionMatchResponse
              .getDac6CardKeysList()
              .forEach(
                  dac6Key -> {
                    try {
                      authMatchDAOImpl.removeCacheData(
                          AuthMatchConstants.CAS_AUTH_CM_DAC6_CACHE,
                          new CasAuthCardAccessCode6CacheKey(dac6Key));

                      String[] keyParts = dac6Key.split("\\|");
                      String rejectedDac6CardKey = keyParts[0] + "|" + "000000" + "|" + "D";

                      authMatchDAOImpl.removeCacheData(
                          AuthMatchConstants.CAS_AUTH_CM_DAC6_CACHE,
                          new CasAuthCardAccessCode6CacheKey(rejectedDac6CardKey));

                    } catch (AuthMatchSystemException e) {
                      LOGGER.error(
                          "{}\"Message\":\"System Error {}\"}",
                          authMatchLog.getCommonLogAttributes("S", "GR0016"),
                          e.getMessage());
                    }
                  });
        }
        if (submissionMatchResponse.getDac2CardKeysList() != null
            && submissionMatchResponse.getDac2CardKeysList().size() > 0) {
          submissionMatchResponse
              .getDac2CardKeysList()
              .forEach(
                  dac2Key -> {
                    try {
                      authMatchDAOImpl.removeCacheData(
                          AuthMatchConstants.CAS_AUTH_CM_DAC2_CACHE,
                          new CasAuthCardAccessCode2CacheKey(dac2Key));

                      String[] keyParts = dac2Key.split("\\|");
                      String rejectedDac2CardKey = keyParts[0] + "|" + "00" + "|" + "D";

                      authMatchDAOImpl.removeCacheData(
                          AuthMatchConstants.CAS_AUTH_CM_DAC2_CACHE,
                          new CasAuthCardAccessCode2CacheKey(rejectedDac2CardKey));
                    } catch (AuthMatchSystemException e) {
                      LOGGER.error(
                          "{}\"Message\":\"System Error {}\"}",
                          authMatchLog.getCommonLogAttributes("S", "GR0016"),
                          e.getMessage());
                    }
                  });
        }

        int maxNumberOfElements = getMaxNumberOfElementsFromAllCaches(submissionMatchResponse);
        if (cassandraUpdate && maxNumberOfElements > 0) {
          IntStream.range(0, maxNumberOfElements)
              .forEach(
                  i -> {
                    String tidCardKey = null;
                    String rejectedTidCardKey = null;
                    String dac6Key = null;
                    String rejectedDac6Key = null;
                    String dac2Key = null;
                    String rejectedDac2Key = null;
                    if (submissionMatchResponse.getTidCardKeysList().get(i) != null) {
                      tidCardKey = submissionMatchResponse.getTidCardKeysList().get(i);
                      String[] tidKeyPartsArray = tidCardKey.split("\\|");
                      rejectedTidCardKey =
                          tidKeyPartsArray[0] + tidKeyPartsArray[1] + tidKeyPartsArray[2];
                    }
                    if (submissionMatchResponse.getDac6CardKeysList().get(i) != null) {
                      dac6Key = submissionMatchResponse.getDac6CardKeysList().get(i);
                      String[] dacc6keyPartsArray = dac6Key.split("\\|");
                      rejectedDac6Key = dacc6keyPartsArray[0] + "|" + "000000" + "|" + "D";
                    }
                    if (submissionMatchResponse.getDac2CardKeysList().get(i) != null) {
                      dac2Key = submissionMatchResponse.getDac2CardKeysList().get(i);
                      String[] dacc2keyPartsArray = dac2Key.split("\\|");
                      rejectedDac2Key = dacc2keyPartsArray[0] + "|" + "00" + "|" + "D";
                    }
                    cassandraMatchResultDAO.deleteFromCassandraCache(
                        tidCardKey,
                        dac6Key,
                        dac2Key,
                        submissionMatchResponse.getAuthUniqueIdentifer());
                    cassandraMatchResultDAO.deleteFromCassandraCache(
                        rejectedTidCardKey,
                        rejectedDac6Key,
                        rejectedDac2Key,
                        submissionMatchResponse.getAuthUniqueIdentifer());
                  });
        }
      }

    } catch (AuthMatchSystemException e) {
      LOGGER.error(
          "{}\"Message\":\"System Error {}\"}",
          authMatchLog.getCommonLogAttributes("S", "GR0016"),
          e.getMessage());
    }
  }

  private int getMaxNumberOfElementsFromAllCaches(SubmissionMatchResponse submissionMatchResponse) {
    int maxNumberOfElements = 0;
    int tidKeyListSize = 0;
    int dac6KeyListSize = 0;
    int dac2KeyListSize = 0;

    if (submissionMatchResponse.getTidCardKeysList() != null) {
      tidKeyListSize = submissionMatchResponse.getTidCardKeysList().size();
    }
    if (submissionMatchResponse.getDac6CardKeysList() != null) {
      dac6KeyListSize = submissionMatchResponse.getDac6CardKeysList().size();
    }
    if (submissionMatchResponse.getDac2CardKeysList() != null) {
      dac2KeyListSize = submissionMatchResponse.getDac2CardKeysList().size();
    }

    maxNumberOfElements = tidKeyListSize;

    if (dac6KeyListSize > tidKeyListSize && dac6KeyListSize > dac2KeyListSize) {
      maxNumberOfElements = dac6KeyListSize;
    }
    if (dac2KeyListSize > tidKeyListSize && dac2KeyListSize > dac6KeyListSize) {
      maxNumberOfElements = dac2KeyListSize;
    }
    return maxNumberOfElements;
  }

  @Override
  public void broadCastCacheVersion() {
    new AuthMatchIgniteCompute().broadCastCacheVersion();
  }

  public void refreshCountDownLatch(String thresholdCountDownLatchName) {
    riskAssessmentThresholdDao.purgeThresholdCountDownLatch(thresholdCountDownLatchName);
    riskAssessmentThresholdDao.createThresholdCountDownLatch(thresholdCountDownLatchName);
  }

  public boolean isAuthLessThanTenDaysOld(String authTImeStamp) {
    Date currentDate = new Date();

    Timestamp authTimestamp =
        org.apache.commons.lang.StringUtils.isNotEmpty(authTImeStamp)
            ? Timestamp.valueOf(authTImeStamp)
            : null;

    LocalDateTime localDateTime =
        currentDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
    Date fromDate =
        Date.from(localDateTime.minusDays(10).atZone(ZoneId.systemDefault()).toInstant());

    if (authTimestamp.after(fromDate)) return true;

    return false;
  }

  public void processCacheUpdate(String request, String rtfClientPath, String axCorrelationId)
      throws AuthMatchSystemException {
    mapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
    CacheSynchUpRequest cacheRequest = null;
    boolean updateFlag = false;
    try {
      cacheRequest = mapper.readValue(request, CacheSynchUpRequest.class);
      if (cacheRequest.isDonotDeleteFlag()) {
        if (cacheRequest
            .getCacheName()
            .equalsIgnoreCase(AuthMatchConstants.CAS_AUTH_TID_CM_CACHE)) {
          CasAuthTransIdCardCacheBean transCardBean =
              authMatchDAOImpl.getTransCardBean(
                  AuthMatchConstants.CAS_AUTH_TID_CM_CACHE,
                  authMatchDAOImpl.getTransCardBinaryKey(
                      cacheRequest.getTransactionId(), cacheRequest.getRocCardNumber(), "A"));
          if (transCardBean != null) {
            transCardBean.setMatchedAmountUSD(cacheRequest.getMatchedAmountUSD());
            authMatchDAOImpl.putCache(
                cacheRequest.getCacheName(),
                authMatchDAOImpl.getTransCardBinaryKey(
                    cacheRequest.getTransactionId(), cacheRequest.getRocCardNumber(), "A"),
                authMatchDAOImpl.getTransCardBinaryBean(transCardBean));
            updateFlag = true;
          }
        }
        if (cacheRequest
            .getCacheName()
            .equalsIgnoreCase(AuthMatchConstants.CAS_AUTH_CM_DAC2_CACHE)) {
          CasAuthCardAccessCode2CacheBean dac2Bean =
              authMatchDAOImpl.getCardDac2Bean(
                  AuthMatchConstants.CAS_AUTH_CM_DAC2_CACHE,
                  authMatchDAOImpl.getCardDac2BinaryKey(
                      cacheRequest.getTransactionId(), cacheRequest.getRocAuthDAC(), "A"));
          if (dac2Bean != null) {
            dac2Bean.setMatchedAmountUSD(cacheRequest.getMatchedAmountUSD());
            authMatchDAOImpl.putCache(
                cacheRequest.getCacheName(),
                authMatchDAOImpl.getCardDac2BinaryKey(
                    cacheRequest.getTransactionId(), cacheRequest.getRocCardNumber(), "A"),
                authMatchDAOImpl.getCardDac2BinaryBean(dac2Bean));
            updateFlag = true;
          }
        }
        if (cacheRequest
            .getCacheName()
            .equalsIgnoreCase(AuthMatchConstants.CAS_AUTH_CM_DAC6_CACHE)) {
          CasAuthCardAccessCode6CacheBean dac6Bean =
              authMatchDAOImpl.getCardDac6Bean(
                  AuthMatchConstants.CAS_AUTH_CM_DAC6_CACHE,
                  authMatchDAOImpl.getCardDac6BinaryKey(
                      cacheRequest.getTransactionId(), cacheRequest.getRocAuthDAC(), "A"));
          if (dac6Bean != null) {
            dac6Bean.setMatchedAmountUSD(cacheRequest.getMatchedAmountUSD());
            authMatchDAOImpl.putCache(
                cacheRequest.getCacheName(),
                authMatchDAOImpl.getCardDac6BinaryKey(
                    cacheRequest.getTransactionId(), cacheRequest.getRocCardNumber(), "A"),
                authMatchDAOImpl.getCardDac6BinaryBean(dac6Bean));
            updateFlag = true;
          }
        }
        LOGGER.info(
            "Cahce Synch Up Request Process Update  {} , {} Updated {} ",
            rtfClientPath,
            axCorrelationId,
            updateFlag);
      } else {
        RocMatchRequest rocMatchRequest = new RocMatchRequest();
        SubmissionMatchResponse reponse = new SubmissionMatchResponse();
        cacheRequest.objectMapper(cacheRequest, rocMatchRequest, reponse);
        this.removeCacheData(rocMatchRequest, reponse, false);
        LOGGER.info(
            "Cahce Synch Up Request Process delete {} , {} ", rtfClientPath, axCorrelationId);
      }
    } catch (IOException e) {
      LOGGER.error("Exception in Cache SynchUp", e.getMessage());
    }
  }
}
