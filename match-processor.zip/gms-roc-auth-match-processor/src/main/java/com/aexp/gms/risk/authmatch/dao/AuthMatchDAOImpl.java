package com.aexp.gms.risk.authmatch.dao;

import com.aexp.gms.imc.risk.rules.vo.keys.GenericKey;
import com.aexp.gms.imc.risk.rules.vo.keys.ICacheKey;
import com.aexp.gms.imc.risk.rules.vo.values.ICacheBean;
import com.aexp.gms.imc.risk.rules.vo.values.IndustryLeverageBean;
import com.aexp.gms.risk.authmatch.exception.AuthMatchSystemException;
import com.aexp.gms.risk.authmatch.model.CasAuthCardAccessCode2CacheBean;
import com.aexp.gms.risk.authmatch.model.CasAuthCardAccessCode6CacheBean;
import com.aexp.gms.risk.authmatch.model.CasAuthTransIdCardCacheBean;
import com.aexp.gms.risk.authmatch.util.AuthMatchLog;
import com.aexp.gms.risk.authmatch.util.ITier;
import java.util.ArrayList;
import java.util.List;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteBinary;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.Ignition;
import org.apache.ignite.binary.BinaryObject;
import org.apache.ignite.binary.BinaryObjectBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AuthMatchDAOImpl implements AuthMatchDAO {

  private AuthMatchLog authMatchLog =
      new AuthMatchLog(AuthMatchDAOImpl.class.getPackage().getName());
  private final Logger LOGGER = LoggerFactory.getLogger(AuthMatchDAOImpl.class);
  private static final String CLASS_NAME = "AuthMatchDAOImpl";
  private IgniteProvider cacheProvider;
  private boolean cacheStarted = false;

  IgniteCache<Long, Object> casAuthCache;

  public AuthMatchDAOImpl() {
    //		LOGGER.info(authMatchLog.getCommonLogAttributes("S", "GR0000") + "|AuthMatchDAOImpl
    // constructor", ITier.REQUESTHANDLER, CLASS_NAME, "AuthMatchDAOImpl");
  }

  public IgniteProvider getCacheProvider() {
    return cacheProvider;
  }

  public void setCacheProvider(IgniteProvider cacheProvider) {
    this.cacheProvider = cacheProvider;
  }

  public boolean isCacheStarted() {
    return cacheStarted;
  }

  @Override
  public boolean checkIgniteHealth() {
    Ignite ignite = Ignition.ignite();
    boolean igniteClientStatus = ignite.active();
    return igniteClientStatus;
  }

  @Override
  public boolean getCache() {
    return true;
  }

  @Override
  public boolean loadCache(ICacheKey key, ICacheBean casBean) throws AuthMatchSystemException {
    cacheProvider.putCache(casBean.getCacheName(), key, casBean);
    return true;
  }

  @Override
  public void putCache(String cacheName, Object key, Object value) throws AuthMatchSystemException {
    cacheProvider.putCache(cacheName, key, value);
  }

  @Override
  public int getCacheCount(String cacheName) throws AuthMatchSystemException {

    return cacheProvider.getCacheCount(cacheName);
  }

  @Override
  public boolean updateCache(String cacheName, String keyList) throws AuthMatchSystemException {
    String sql = null;
    // System.out.println("updateCache :" + cacheName + " " + keyList);

    LOGGER.info("updateCache: {} ", " {} ", cacheName, keyList);
    LOGGER.info(
        "{}|updateCache {} , {} ",
        authMatchLog.getCommonLogAttributes("S", "GR2014"),
        cacheName,
        keyList,
        ITier.REQUESTHANDLER,
        CLASS_NAME,
        "updateCache");

    boolean updatedCache = true;
    sql =
        "UPDATE CasAuthTransIdCardCacheBean set RocAuthMatchedFlag = 'Y', rocAuthMatchedCriteriaId = '3' WHERE _key in ("
            + keyList
            + ")";
    int updateCount = cacheProvider.updateCache(cacheName, sql);
    if (updateCount <= 0) updatedCache = false;

    return updatedCache;
  }

  @Override
  public List<List<?>> getCacheData(ICacheBean bean, String command)
      throws AuthMatchSystemException {
    return cacheProvider.getCacheData(bean.getCacheName(), bean, command);
  }

  @Override
  public List<List<?>> getCacheData(String cacheName, String sql) throws AuthMatchSystemException {
    return cacheProvider.getCacheData(cacheName, sql);
  }

  @Override
  public String getAuthUniqueIdentifer(ICacheBean bean) throws AuthMatchSystemException {
    Object next = null;
    String authUniqueIdentifier = null;
    List<List<?>> resultSet = getCacheData(bean, "GetAuthData");
    if (resultSet != null && resultSet.size() > 0) {
      next = resultSet.get(0);
      authUniqueIdentifier = (String) ((ArrayList) next).get(0);
    }
    return authUniqueIdentifier;
  }

  @Override
  public void removeCacheData(String cacheName, ICacheBean cacheBean)
      throws AuthMatchSystemException {
    cacheProvider.removeCacheData(cacheName, cacheBean);
  }

  @Override
  public void removeCacheData(String cacheName, String cacheKey) throws AuthMatchSystemException {
    cacheProvider.removeCacheData(cacheName, cacheKey);
  }

  @Override
  public boolean checkCacheData(BinaryObject cacheKey, String cacheName)
      throws AuthMatchSystemException {
    return cacheProvider.checkCache(cacheKey, cacheName);
  }

  @Override
  public void removeCacheData(String cacheName, ICacheKey key) throws AuthMatchSystemException {
    cacheProvider.removeCacheData(cacheName, key);
  }

  @Override
  public ICacheBean getCacheData(String cacheName, ICacheKey key) throws AuthMatchSystemException {
    return cacheProvider.getCache(cacheName, key);
  }

  @Override
  public IndustryLeverageBean getIndustryLeverageByCode(String cacheName, ICacheKey key)
      throws AuthMatchSystemException {
    IndustryLeverageBean bean = (IndustryLeverageBean) cacheProvider.getCache(cacheName, key);
    if (bean == null) {
      bean = (IndustryLeverageBean) cacheProvider.getCache(cacheName, new GenericKey("Others"));
    }
    return bean;
  }

  @Override
  public CasAuthTransIdCardCacheBean getTransCardBean(String cacheName, BinaryObject key)
      throws AuthMatchSystemException {
    CasAuthTransIdCardCacheBean transCardBean = null;
    IgniteCache<BinaryObject, BinaryObject> casAuthCache =
        cacheProvider.getIgnite().cache(cacheName).withKeepBinary();
    BinaryObject transCardBinaryBean = casAuthCache.get(key);
    if (transCardBinaryBean != null) {
      transCardBean = new CasAuthTransIdCardCacheBean();
      if (transCardBinaryBean.hasField("transactionId"))
        transCardBean.setTransactionId(transCardBinaryBean.field("transactionId"));
      if (transCardBinaryBean.hasField("cardNumber"))
        transCardBean.setCardNumber(transCardBinaryBean.field("cardNumber"));
      if (transCardBinaryBean.hasField("approveDenyCode"))
        transCardBean.setApproveDenyCode(transCardBinaryBean.field("approveDenyCode"));
      if (transCardBinaryBean.hasField("authAmountUSD"))
        transCardBean.setAuthAmountUSD(transCardBinaryBean.field("authAmountUSD"));
      if (transCardBinaryBean.hasField("rocAuthMatchedFlag"))
        transCardBean.setRocAuthMatchedFlag(
            transCardBinaryBean.field("rocAuthMatchedFlag")); // Y -> Matched, N -> Not matched
      if (transCardBinaryBean.hasField("rocAuthMatchedCriteriaId"))
        transCardBean.setRocAuthMatchedCriteriaId(
            transCardBinaryBean.field("rocAuthMatchedCriteriaId")); // 1 - Matched by TID
      if (transCardBinaryBean.hasField("persistedFlag"))
        transCardBean.setPersistedFlag(
            transCardBinaryBean.field("persistedFlag")); // Y -> Cassandra updated
      if (transCardBinaryBean.hasField("cardDac6PrimaryKey"))
        transCardBean.setCardDac6PrimaryKey(transCardBinaryBean.field("cardDac6PrimaryKey"));
      if (transCardBinaryBean.hasField("cardDac2PrimaryKey"))
        transCardBean.setCardDac2PrimaryKey(transCardBinaryBean.field("cardDac2PrimaryKey"));
      if (transCardBinaryBean.hasField("authUniqueIdentifier"))
        transCardBean.setAuthUniqueIdentifier(transCardBinaryBean.field("authUniqueIdentifier"));
      if (transCardBinaryBean.hasField("seNumber"))
        transCardBean.setSeNumber(transCardBinaryBean.field("seNumber"));
      if (transCardBinaryBean.hasField("authTransactionDateTime"))
        transCardBean.setAuthTransactionDateTime(
            transCardBinaryBean.field("authTransactionDateTime"));
      if (transCardBinaryBean.hasField("matchedAmountUSD"))
        transCardBean.setMatchedAmountUSD(transCardBinaryBean.field("matchedAmountUSD"));
      if (transCardBinaryBean.hasField("sourceIdentifier"))
        transCardBean.setSourceIdentifier(transCardBinaryBean.field("sourceIdentifier"));
      if (transCardBinaryBean.hasField("authAmountLocal"))
        transCardBean.setAuthAmountLocal(transCardBinaryBean.field("authAmountLocal"));
      if (transCardBinaryBean.hasField("voiceAuthIndicator"))
        transCardBean.setVoiceAuthIndicator(transCardBinaryBean.field("voiceAuthIndicator"));
      if (transCardBinaryBean.hasField("posDataCode"))
        transCardBean.setPosDataCode(transCardBinaryBean.field("posDataCode"));
      if (transCardBinaryBean.hasField("eciIndicator"))
        transCardBean.setEciIndicator(transCardBinaryBean.field("eciIndicator"));
      if (transCardBinaryBean.hasField("mccMerchant"))
        transCardBean.setMccMerchant(transCardBinaryBean.field("mccMerchant"));
      if (transCardBinaryBean.hasField("creditDeniedcode"))
        transCardBean.setCreditDeniedcode(transCardBinaryBean.field("creditDeniedcode"));
      if (transCardBinaryBean.hasField("fraudDeniedCode"))
        transCardBean.setFraudDeniedCode(transCardBinaryBean.field("fraudDeniedCode"));
      if (transCardBinaryBean.hasField("transactionTimeStamp"))
        transCardBean.setTransactionTimeStamp(transCardBinaryBean.field("transactionTimeStamp"));
    }
    return transCardBean;
  }

  @Override
  public CasAuthCardAccessCode6CacheBean getCardDac6Bean(String cacheName, BinaryObject key)
      throws AuthMatchSystemException {
    IgniteCache<BinaryObject, BinaryObject> casAuthCache =
        cacheProvider.getIgnite().cache(cacheName).withKeepBinary();
    BinaryObject cardDac6BinaryBean = casAuthCache.get(key);
    CasAuthCardAccessCode6CacheBean cardDac6Bean = null;
    if (cardDac6BinaryBean != null) {
      cardDac6Bean = new CasAuthCardAccessCode6CacheBean();
      if (cardDac6BinaryBean.hasField("cardNumber"))
        cardDac6Bean.setCardNumber(cardDac6BinaryBean.field("cardNumber"));
      if (cardDac6BinaryBean.hasField("auth6Dac"))
        cardDac6Bean.setAuth6Dac(cardDac6BinaryBean.field("auth6Dac"));
      if (cardDac6BinaryBean.hasField("approveDenyCode"))
        cardDac6Bean.setApproveDenyCode(cardDac6BinaryBean.field("approveDenyCode"));
      if (cardDac6BinaryBean.hasField("strAuthTransactionDateTime"))
        cardDac6Bean.setStrAuthTransactionDateTime(
            cardDac6BinaryBean.field("strAuthTransactionDateTime"));
      if (cardDac6BinaryBean.hasField("seNumber"))
        cardDac6Bean.setSeNumber(cardDac6BinaryBean.field("seNumber"));
      if (cardDac6BinaryBean.hasField("authAmountLocal"))
        cardDac6Bean.setAuthAmountLocal(cardDac6BinaryBean.field("authAmountLocal"));
      if (cardDac6BinaryBean.hasField("authAmountCurrencyCode"))
        cardDac6Bean.setAuthAmountCurrencyCode(cardDac6BinaryBean.field("authAmountCurrencyCode"));
      if (cardDac6BinaryBean.hasField("authTransactionDateTime"))
        cardDac6Bean.setAuthTransactionDateTime(
            cardDac6BinaryBean.field("authTransactionDateTime"));
      if (cardDac6BinaryBean.hasField("matchedAmountUSD"))
        cardDac6Bean.setMatchedAmountUSD(cardDac6BinaryBean.field("matchedAmountUSD"));
      if (cardDac6BinaryBean.hasField("authAmountUSD"))
        cardDac6Bean.setAuthAmountUSD(cardDac6BinaryBean.field("authAmountUSD"));
      if (cardDac6BinaryBean.hasField("rocAuthMatchedFlag"))
        cardDac6Bean.setRocAuthMatchedFlag(cardDac6BinaryBean.field("rocAuthMatchedFlag"));
      if (cardDac6BinaryBean.hasField("rocAuthMatchedCriteriaId"))
        cardDac6Bean.setRocAuthMatchedCriteriaId(
            cardDac6BinaryBean.field("rocAuthMatchedCriteriaId"));
      if (cardDac6BinaryBean.hasField("persistedFlag"))
        cardDac6Bean.setPersistedFlag(cardDac6BinaryBean.field("persistedFlag"));
      if (cardDac6BinaryBean.hasField("tidCMPrimaryKey"))
        cardDac6Bean.setTidCMPrimaryKey(cardDac6BinaryBean.field("tidCMPrimaryKey"));
      if (cardDac6BinaryBean.hasField("cardDac2PrimaryKey"))
        cardDac6Bean.setCardDac2PrimaryKey(cardDac6BinaryBean.field("cardDac2PrimaryKey"));
      if (cardDac6BinaryBean.hasField("authUniqueIdentifier"))
        cardDac6Bean.setAuthUniqueIdentifier(cardDac6BinaryBean.field("authUniqueIdentifier"));
    }

    return cardDac6Bean;
  }

  @Override
  public CasAuthCardAccessCode2CacheBean getCardDac2Bean(String cacheName, BinaryObject key)
      throws AuthMatchSystemException {
    IgniteCache<BinaryObject, BinaryObject> casAuthCache =
        cacheProvider.getIgnite().cache(cacheName).withKeepBinary();
    BinaryObject cardDac2BinaryBean = casAuthCache.get(key);
    CasAuthCardAccessCode2CacheBean cardDac2Bean = null;
    if (cardDac2BinaryBean != null) {
      cardDac2Bean = new CasAuthCardAccessCode2CacheBean();
      if (cardDac2BinaryBean.hasField("cardNumber"))
        cardDac2Bean.setCardNumber(cardDac2BinaryBean.field("cardNumber"));
      if (cardDac2BinaryBean.hasField("auth2Dac"))
        cardDac2Bean.setAuth2Dac(cardDac2BinaryBean.field("auth2Dac"));
      if (cardDac2BinaryBean.hasField("approveDenyCode"))
        cardDac2Bean.setApproveDenyCode(cardDac2BinaryBean.field("approveDenyCode"));
      if (cardDac2BinaryBean.hasField("seNumber"))
        cardDac2Bean.setSeNumber(cardDac2BinaryBean.field("seNumber"));
      if (cardDac2BinaryBean.hasField("authAmountLocal"))
        cardDac2Bean.setAuthAmountLocal(cardDac2BinaryBean.field("authAmountLocal"));
      if (cardDac2BinaryBean.hasField("authAmountCurrencyCode"))
        cardDac2Bean.setAuthAmountCurrencyCode(cardDac2BinaryBean.field("authAmountCurrencyCode"));
      if (cardDac2BinaryBean.hasField("authTransactionDateTime"))
        cardDac2Bean.setAuthTransactionDateTime(
            cardDac2BinaryBean.field("authTransactionDateTime"));
      if (cardDac2BinaryBean.hasField("matchedAmountUSD"))
        cardDac2Bean.setMatchedAmountUSD(cardDac2BinaryBean.field("matchedAmountUSD"));
      if (cardDac2BinaryBean.hasField("authAmountUSD"))
        cardDac2Bean.setAuthAmountUSD(cardDac2BinaryBean.field("authAmountUSD"));
      if (cardDac2BinaryBean.hasField("rocAuthMatchedFlag"))
        cardDac2Bean.setRocAuthMatchedFlag(cardDac2BinaryBean.field("rocAuthMatchedFlag"));
      if (cardDac2BinaryBean.hasField("rocAuthMatchedCriteriaId"))
        cardDac2Bean.setRocAuthMatchedCriteriaId(
            cardDac2BinaryBean.field("rocAuthMatchedCriteriaId"));
      if (cardDac2BinaryBean.hasField("persistedFlag"))
        cardDac2Bean.setPersistedFlag(cardDac2BinaryBean.field("persistedFlag"));
      if (cardDac2BinaryBean.hasField("tidCMPrimaryKey"))
        cardDac2Bean.setTidCMPrimaryKey(cardDac2BinaryBean.field("tidCMPrimaryKey"));
      if (cardDac2BinaryBean.hasField("cardDac6PrimaryKey"))
        cardDac2Bean.setCardDac6PrimaryKey(cardDac2BinaryBean.field("cardDac6PrimaryKey"));
      if (cardDac2BinaryBean.hasField("authUniqueIdentifier"))
        cardDac2Bean.setAuthUniqueIdentifier(cardDac2BinaryBean.field("authUniqueIdentifier"));
    }
    return cardDac2Bean;
  }

  @Override
  public BinaryObject getTransCardBinaryBean(CasAuthTransIdCardCacheBean transCardBean)
      throws AuthMatchSystemException {
    IgniteBinary binary = cacheProvider.getIgnite().binary();
    return binary
        .builder("com.aexp.gms.imc.risk.rules.vo.values.CasAuthTransIdCardCacheBean2")
        .setField("transactionId", transCardBean.getTransactionId())
        .setField("cardNumber", transCardBean.getCardNumber())
        .setField("approveDenyCode", transCardBean.getApproveDenyCode())
        .setField("authAmountUSD", transCardBean.getAuthAmountUSD())
        .setField("rocAuthMatchedFlag", transCardBean.getRocAuthMatchedFlag())
        .setField("rocAuthMatchedCriteriaId", transCardBean.getRocAuthMatchedCriteriaId())
        .setField("persistedFlag", transCardBean.getPersistedFlag())
        .setField("cardDac6PrimaryKey", transCardBean.getCardDac6PrimaryKey())
        .setField("cardDac2PrimaryKey", transCardBean.getCardDac2PrimaryKey())
        .setField("authUniqueIdentifier", transCardBean.getAuthUniqueIdentifier())
        .setField("seNumber", transCardBean.getSeNumber())
        .setField("authTransactionDateTime", transCardBean.getAuthTransactionDateTime())
        .setField("matchedAmountUSD", transCardBean.getMatchedAmountUSD())
        .setField("sourceIdentifier", transCardBean.getSourceIdentifier())
        .setField("authAmountLocal", transCardBean.getAuthAmountLocal())
        .setField("voiceAuthIndicator", transCardBean.getVoiceAuthIndicator())
        .setField("posDataCode", transCardBean.getPosDataCode())
        .setField("eciIndicator", transCardBean.getEciIndicator())
        .setField("mccMerchant", transCardBean.getMccMerchant())
        .setField("creditDeniedcode", transCardBean.getCreditDeniedcode())
        .setField("fraudDeniedCode", transCardBean.getFraudDeniedCode())
        .build();
  }

  @Override
  public BinaryObject getCardDac6BinaryBean(CasAuthCardAccessCode6CacheBean cardDac6Bean)
      throws AuthMatchSystemException {
    IgniteBinary binary = cacheProvider.getIgnite().binary();
    BinaryObjectBuilder builder =
        binary.builder("com.aexp.gms.imc.risk.rules.vo.values.CasAuthCardAccessCode6CacheBean");
    builder.setField("cardNumber", cardDac6Bean.getCardNumber());
    builder.setField("auth6Dac", cardDac6Bean.getAuth6Dac());
    builder.setField("approveDenyCode", cardDac6Bean.getApproveDenyCode());
    builder.setField("strAuthTransactionDateTime", cardDac6Bean.getStrAuthTransactionDateTime());
    builder.setField("seNumber", cardDac6Bean.getSeNumber());
    builder.setField("authAmountLocal", cardDac6Bean.getAuthAmountLocal());
    builder.setField("authAmountCurrencyCode", cardDac6Bean.getAuthAmountCurrencyCode());
    builder.setField("authTransactionDateTime", cardDac6Bean.getAuthTransactionDateTime());
    builder.setField("matchedAmountUSD", cardDac6Bean.getMatchedAmountUSD());
    builder.setField("authAmountUSD", cardDac6Bean.getAuthAmountUSD());
    builder.setField("rocAuthMatchedFlag", cardDac6Bean.getRocAuthMatchedFlag());
    builder.setField("rocAuthMatchedCriteriaId", cardDac6Bean.getRocAuthMatchedCriteriaId());
    builder.setField("persistedFlag", cardDac6Bean.getPersistedFlag());
    builder.setField("tidCMPrimaryKey", cardDac6Bean.getTidCMPrimaryKey());
    builder.setField("cardDac2PrimaryKey", cardDac6Bean.getCardDac2PrimaryKey());
    builder.setField("authUniqueIdentifier", cardDac6Bean.getAuthUniqueIdentifier());
    return builder.build();
  }

  @Override
  public BinaryObject getCardDac2BinaryBean(CasAuthCardAccessCode2CacheBean cardDac2Bean)
      throws AuthMatchSystemException {
    IgniteBinary binary = cacheProvider.getIgnite().binary();
    BinaryObjectBuilder builder =
        binary.builder("com.aexp.gms.imc.risk.rules.vo.values.CasAuthCardAccessCode2CacheBean");
    builder.setField("cardNumber", cardDac2Bean.getCardNumber());
    builder.setField("auth2Dac", cardDac2Bean.getAuth2Dac());
    builder.setField("approveDenyCode", cardDac2Bean.getApproveDenyCode());
    builder.setField("seNumber", cardDac2Bean.getSeNumber());
    builder.setField("authAmountLocal", cardDac2Bean.getAuthAmountLocal());
    builder.setField("authAmountCurrencyCode", cardDac2Bean.getAuthAmountCurrencyCode());
    builder.setField("authTransactionDateTime", cardDac2Bean.getAuthTransactionDateTime());
    builder.setField("matchedAmountUSD", cardDac2Bean.getMatchedAmountUSD());
    builder.setField("authAmountUSD", cardDac2Bean.getAuthAmountUSD());
    builder.setField("rocAuthMatchedFlag", cardDac2Bean.getRocAuthMatchedFlag());
    builder.setField("rocAuthMatchedCriteriaId", cardDac2Bean.getRocAuthMatchedCriteriaId());
    builder.setField("persistedFlag", cardDac2Bean.getPersistedFlag());
    builder.setField("tidCMPrimaryKey", cardDac2Bean.getTidCMPrimaryKey());
    builder.setField("cardDac6PrimaryKey", cardDac2Bean.getCardDac6PrimaryKey());
    builder.setField("authUniqueIdentifier", cardDac2Bean.getAuthUniqueIdentifier());
    return builder.build();
  }

  @Override
  public BinaryObject getTransCardBinaryKey(
      String transactionId, String cardNumber, String approveDenyCode)
      throws AuthMatchSystemException {
    IgniteBinary binary = cacheProvider.getIgnite().binary();
    BinaryObjectBuilder builder =
        binary.builder("com.aexp.gms.imc.risk.rules.vo.keys.CasAuthTransIdCardCacheKey");
    builder.setField("transactionId", transactionId);
    builder.setField("cardNumber", cardNumber);
    builder.setField("approveDenyCode", approveDenyCode);
    return builder.build();
  }

  @Override
  public BinaryObject getCardDac6BinaryKey(
      String cardNumber, String auth6Dac, String approveDenyCode) throws AuthMatchSystemException {
    IgniteBinary binary = cacheProvider.getIgnite().binary();
    BinaryObjectBuilder builder =
        binary.builder("com.aexp.gms.imc.risk.rules.vo.keys.CasAuthCardAccessCode6CacheKey");
    builder.setField("cardNumber", cardNumber);
    builder.setField("auth6Dac", auth6Dac);
    builder.setField("approveDenyCode", approveDenyCode);
    return builder.build();
  }

  @Override
  public BinaryObject getCardDac2BinaryKey(
      String cardNumber, String auth2Dac, String approveDenyCode) throws AuthMatchSystemException {
    IgniteBinary binary = cacheProvider.getIgnite().binary();
    BinaryObjectBuilder builder =
        binary.builder("com.aexp.gms.imc.risk.rules.vo.keys.CasAuthCardAccessCode2CacheKey");
    builder.setField("cardNumber", cardNumber);
    builder.setField("auth2Dac", auth2Dac);
    builder.setField("approveDenyCode", approveDenyCode);
    return builder.build();
  }
}
