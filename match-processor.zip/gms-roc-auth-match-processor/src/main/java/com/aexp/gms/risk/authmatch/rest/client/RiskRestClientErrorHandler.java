package com.aexp.gms.risk.authmatch.rest.client;

import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.DefaultResponseErrorHandler;

public class RiskRestClientErrorHandler extends DefaultResponseErrorHandler {
  public RiskRestClientErrorHandler() {
    super();
  }

  @Override
  public void handleError(ClientHttpResponse clientHttpResponse) {
    // do nothing... I have found no useful behavior to add here because the rest client should be
    // responsible for looking at the response for retry purposes
    // and logging the response from here closes the inputstream making it unusable in the rest
    // client, causing it throw an exception because it tries reading from a closed inputstream
  }
}
