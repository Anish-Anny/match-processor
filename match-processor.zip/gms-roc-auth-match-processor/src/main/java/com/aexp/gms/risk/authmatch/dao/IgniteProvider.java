package com.aexp.gms.risk.authmatch.dao;

import com.aexp.gms.imc.risk.rules.vo.keys.ICacheKey;
import com.aexp.gms.imc.risk.rules.vo.values.ICacheBean;
import com.aexp.gms.risk.authmatch.exception.AuthMatchSystemException;
import com.aexp.gms.risk.authmatch.util.AuthMatchLog;
import com.aexp.gms.risk.authmatch.util.ITier;
import com.aexp.gms.risk.authmatch.util.PropertyLoaderUtils;
import java.util.List;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.IgniteException;
import org.apache.ignite.Ignition;
import org.apache.ignite.binary.BinaryObject;
import org.apache.ignite.cache.CachePeekMode;
import org.apache.ignite.cache.query.SqlFieldsQuery;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class IgniteProvider implements ICacheProvider {

  private static Ignite ignite;

  private AuthMatchLog authMatchLog = new AuthMatchLog(IgniteProvider.class.getPackage().getName());
  private final Logger LOGGER = LoggerFactory.getLogger(IgniteProvider.class);
  private static final String CLASS_NAME = "IgniteProvider";

  public IgniteProvider() {
    startCacheProvider();
  }

  public IgniteProvider(boolean startIndicator) {}

  public Ignite getIgnite() {
    return this.ignite;
  }

  public void setIgnite(Ignite ignite) {
    this.ignite = ignite;
  }

  @Override
  public boolean startCacheProvider() {
    LOGGER.info(
        "{}\"Message\":\"Start Ignite\"}",
        authMatchLog.getCommonLogAttributes("S", "GR0000"),
        ITier.REQUESTHANDLER,
        CLASS_NAME,
        "Start Ignite");
    String igniteConfigFile =
        PropertyLoaderUtils.resolveFileName("imc-ignite-client-config-${env}.xml");

    this.ignite =
        Ignition.getOrStart(
            Ignition.loadSpringBean(
                this.getClass().getClassLoader().getResourceAsStream(igniteConfigFile),
                "ignite.cfg")); // start(this.getClass().getClassLoader().getResourceAsStream(igniteConfigFile));
    return true;
  }

  @Override
  public boolean reStartCacheProvider() {
    String igniteConfigFile =
        PropertyLoaderUtils.resolveFileName("imc-ignite-client-config-${env}.xml");
    ignite.close();
    ignite = null;
    this.ignite =
        Ignition.start(this.getClass().getClassLoader().getResourceAsStream(igniteConfigFile));
    return true;
  }

  @Override
  public boolean putCache(String cacheName, Object key, Object value)
      throws AuthMatchSystemException {
    try {
      IgniteCache<Object, Object> casAuthCache = ignite.cache(cacheName);
      casAuthCache.put(key, value);
    } catch (IgniteException igniteException) {
      igniteException.printStackTrace();
      throw new AuthMatchSystemException("System Exception while updating data");
    }
    return false;
  }

  @Override
  public boolean removeCacheData(String cacheName, ICacheBean cacheBean) {
    return false;
  }

  @Override
  public int getCacheCount(String cacheName) {
    IgniteCache<ICacheKey, ICacheBean> casAuthCache = ignite.cache(cacheName);
    return casAuthCache.size(CachePeekMode.PRIMARY);
  }

  @Override
  public List<List<?>> getCacheData(String cacheName, ICacheBean cacheBean, String command) {
    return null;
  }

  @Override
  public int updateCache(String cacheName, String command) {
    return 0;
  }

  @Override
  public boolean removeCacheData(String cacheName, String cachekey)
      throws AuthMatchSystemException {
    boolean deleted = false;
    IgniteCache<Object, Object> cache = ignite.cache(cacheName);
    deleted = cache.remove(cachekey);
    return deleted;
  }

  @Override
  public List<List<?>> getCacheData(String cacheName, String command)
      throws AuthMatchSystemException {
    List<List<?>> resultList = null;
    String sql = "";
    try {
      IgniteCache<ICacheKey, ICacheBean> casAuthCache = ignite.cache(cacheName);
      sql = command;
      resultList = casAuthCache.query(new SqlFieldsQuery(sql).setDistributedJoins(true)).getAll();
    } catch (IgniteException igniteException) {
      throw new AuthMatchSystemException("Exception occurred while retrieving data from cache");
    }

    return resultList;
  }

  @Override
  public boolean checkCache(BinaryObject cacheKey, String cacheName)
      throws AuthMatchSystemException {
    boolean recordExists = false;
    IgniteCache<Object, Object> cache = ignite.cache(cacheName);

    recordExists = cache.containsKey(cacheKey);
    return recordExists;
  }

  @Override
  public BinaryObject getCache(String cacheName, BinaryObject key) throws AuthMatchSystemException {
    IgniteCache<BinaryObject, BinaryObject> casAuthCache = ignite.cache(cacheName).withKeepBinary();
    return casAuthCache.get(key);
  }

  @Override
  public BinaryObject getCache(String cacheName, String key) throws AuthMatchSystemException {
    IgniteCache<String, BinaryObject> casAuthCache = ignite.cache(cacheName).withKeepBinary();
    return casAuthCache.get(key);
  }

  @Override
  public boolean putCache(String cacheName, BinaryObject key, BinaryObject value)
      throws AuthMatchSystemException {
    try {
      IgniteCache<BinaryObject, BinaryObject> casAuthCache = ignite.cache(cacheName);
      casAuthCache.put(key, value);
    } catch (IgniteException igniteException) {
      igniteException.printStackTrace();
      throw new AuthMatchSystemException("System Exception while updating data");
    }
    return false;
  }

  @Override
  public boolean removeCacheData(String cacheName, ICacheKey key) throws AuthMatchSystemException {
    IgniteCache<ICacheKey, ICacheBean> cache = ignite.cache(cacheName);
    cache.remove(key);

    return true;
  }

  @Override
  public ICacheBean getCache(String cacheName, ICacheKey key) throws AuthMatchSystemException {
    IgniteCache<ICacheKey, ICacheBean> casAuthCache = ignite.cache(cacheName);
    return casAuthCache.get(key);
  }
}
