package com.aexp.gms.risk.authmatch.exception;

public class AuthMatchSystemException extends AuthMatchException {

  private static final long serialVersionUID = 1L;

  public AuthMatchSystemException() {
    super();
  }

  public AuthMatchSystemException(String msg, Throwable e) {
    super(msg, e);
  }

  public AuthMatchSystemException(String message) {
    super(message);
  }

  public AuthMatchSystemException(Throwable t) {
    super(t);
  }
}
