package com.aexp.gms.risk.data;

import com.aexp.gms.risk.authmatch.model.*;
import com.aexp.gms.risk.authmatch.util.AuthMatchUtil;
import com.datastax.driver.core.BoundStatement;
import com.datastax.driver.core.ConsistencyLevel;
import com.datastax.driver.core.LocalDate;
import com.datastax.driver.core.PreparedStatement;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class AuthMatchDatabaseDAOImpl implements AuthMatchDatabaseDAO {

  Session session = null;
  PreparedStatement selectTransByTid = null;
  PreparedStatement selectTransByCardAndSe = null;
  PreparedStatement selectTransByDac6 = null;
  PreparedStatement selectTransByDac2 = null;
  PreparedStatement deleteTransByTid = null;

  PreparedStatement selectMatchResult = null;
  PreparedStatement updateMatchAmount = null;

  public AuthMatchDatabaseDAOImpl() {
    session = CassandraConnectionFactory.getInstance().getCassandraSession();
    selectTransByTid = session.prepare(getSelectCassAuthByTidQuery());
    selectTransByCardAndSe = session.prepare(getSelectCassAuthByCardAndSeQuery());
    selectTransByDac6 = session.prepare(getSelectCassAuthByDac6());
    selectTransByDac2 = session.prepare(getSelectCassAuthByDac2());
    deleteTransByTid = session.prepare(getDeleteCassAuthByTid());
    selectMatchResult = session.prepare(getSelectMatchResultQuery());
    // updateMatchAmount = session.prepare(getUpdateMatchAmountQuery());
  }

  public void updateDataForLocalCassandra() {
    session = CassandraConnectionFactory.getInstance().getLocalCassandraSession();
    selectTransByTid = session.prepare(getSelectCassAuthByTidQuery());
    selectTransByCardAndSe = session.prepare(getSelectCassAuthByCardAndSeQuery());
    selectTransByDac6 = session.prepare(getSelectCassAuthByDac6());
    selectTransByDac2 = session.prepare(getSelectCassAuthByDac2());
    deleteTransByTid = session.prepare(getDeleteCassAuthByTid());
    selectMatchResult = session.prepare(getSelectMatchResultQuery());
    // updateMatchAmount = session.prepare(getUpdateMatchAmountQuery());
  }

  private String getSelectMatchResultQuery() {
    StringBuilder selectQuery = new StringBuilder();
    return selectQuery
        .append("SELECT * FROM ram_rslt_by_arn")
        .append(" WHERE ")
        .append("roc_arn=")
        .append(":roc_arn")
        .append(";")
        .toString();
  }

  private String getUpdateMatchAmountQuery() {
    StringBuilder updateQuery = new StringBuilder();
    return updateQuery
        .append("UPDATE auth_by_trans_id set match_usd_am=:match_usd_am")
        .append(" WHERE ")
        .append("trans_id=")
        .append(":trans_id")
        .append(" AND ")
        .append("cm_15=")
        .append(":cm_15")
        .append(" AND ")
        .append("aprv_deny_cd=")
        .append(":aprv_deny_cd")
        .append(";")
        .toString();
  }

  private String getSelectCassAuthByTidQuery() {
    StringBuilder selectQuery = new StringBuilder();
    return selectQuery
        .append("SELECT * FROM auth_by_trans_id")
        .append(" WHERE ")
        .append("trans_id=")
        .append(":trans_id")
        .append(" AND ")
        .append("cm_15=")
        .append(":cm_15")
        .append(" AND ")
        .append("aprv_deny_cd=")
        .append(":aprv_deny_cd")
        .append(";")
        .toString();
  }

  private String getSelectCassAuthByCardAndSeQuery() {
    StringBuilder selectQuery = new StringBuilder();
    return selectQuery
        .append("SELECT * FROM auth_by_card_and_se")
        .append(" WHERE ")
        .append("auth_se_no=")
        .append(":auth_se_no")
        .append(" AND ")
        .append("cm_15=")
        .append(":cm_15")
        .append(" AND ")
        .append("aprv_deny_cd=")
        .append(":aprv_deny_cd")
        .append(";")
        .toString();
  }

  private String getSelectCassAuthByDac6() {
    StringBuilder selectQuery = new StringBuilder();
    return selectQuery
        .append("SELECT * FROM auth_by_6dac_and_se")
        .append(" WHERE ")
        .append("cm15=")
        .append(":cm15")
        .append(" AND ")
        .append("six_dgt_aprv_cde=")
        .append(":six_dgt_aprv_cde")
        .append(" AND ")
        .append("aprv_deny_cd=")
        .append(":aprv_deny_cd")
        .append(";")
        .toString();
  }

  private String getSelectCassAuthByDac2() {
    StringBuilder selectQuery = new StringBuilder();
    return selectQuery
        .append("SELECT * FROM auth_by_2dac_and_se")
        .append(" WHERE ")
        .append("cm15=")
        .append(":cm15")
        .append(" AND ")
        .append("two_dgt_aprv_cde=")
        .append(":two_dgt_aprv_cde")
        .append(" AND ")
        .append("aprv_deny_cd=")
        .append(":aprv_deny_cd")
        .append(";")
        .toString();
  }

  private String getDeleteCassAuthByTid() {
    StringBuilder deleteQuery = new StringBuilder();
    return deleteQuery
        .append("DELETE FROM auth_by_trans_id")
        .append(" WHERE ")
        .append("trans_id=")
        .append(":trans_id")
        .append(" AND ")
        .append("cm_15=")
        .append(":cm_15")
        .append(" AND ")
        .append("aprv_deny_cd=")
        .append(":aprv_deny_cd")
        .append(";")
        .toString();
  }

  @Override
  public CasAuthTransIdCardCacheBean getTransByTidData(
      RocMatchRequest request, String approveDenyCode) {
    CasAuthTransIdCardCacheBean transCardBean = null;

    BoundStatement boundStatement = selectTransByTid.bind();
    boundStatement.setString("trans_id", request.getRocAuthorizationTransactionId());
    boundStatement.setString("cm_15", request.getRocCardNumber());
    boundStatement.setString("aprv_deny_cd", approveDenyCode);
    boundStatement.setConsistencyLevel(ConsistencyLevel.ONE);

    ResultSet resultSet = session.execute(boundStatement);
    for (Row row : resultSet) {
      transCardBean = new CasAuthTransIdCardCacheBean();
      transCardBean.setTransactionId(row.getString("trans_id"));
      transCardBean.setCardNumber(row.getString("cm_15"));
      transCardBean.setApproveDenyCode(row.getString("aprv_deny_cd"));
      transCardBean.setAuthAmountUSD(row.getDecimal("auth_usd_am"));
      transCardBean.setSeNumber(row.getString("auth_se_no"));
      transCardBean.setAuthTransactionDateTime(row.getTimestamp("auth_ts"));
      transCardBean.setAuthAmountLocal(row.getDecimal("auth_loc_am"));
      transCardBean.setCardDac2PrimaryKey(row.getString("card_2dac_cache_key"));
      transCardBean.setCardDac6PrimaryKey(row.getString("card_6dac_cache_key"));
      transCardBean.setRocAuthMatchedFlag(row.getString("auth_mtch_in"));
      transCardBean.setRocAuthMatchedCriteriaId(row.getString("ram_mtch_tier_cd"));
      transCardBean.setAuthUniqueIdentifier(row.getString("cas_pkey"));
      transCardBean.setTransactionTimeStamp(row.getTimestamp("trans_ts"));
    }

    return transCardBean;
  }

  /*@Override
    public CasAuthTransIdCardCacheBean getTransByCardAndSe(
        RocMatchRequest request, String approveDenyCode) {
      CasAuthTransIdCardCacheBean transCardBean = null;

      BoundStatement boundStatement = selectTransByCardAndSe.bind();
      boundStatement.setString("auth_se_no", request.getRocSENumber());
      boundStatement.setString("cm_15", request.getRocCardNumber());
      boundStatement.setString("aprv_deny_cd", approveDenyCode);
      boundStatement.setConsistencyLevel(ConsistencyLevel.ONE);

      ResultSet resultSet = session.execute(boundStatement);
      for (Row row : resultSet) {
        transCardBean = new CasAuthTransIdCardCacheBean();
        transCardBean.setTransactionId(row.getString("trans_id"));
        transCardBean.setCardNumber(row.getString("cm_15"));
        transCardBean.setApproveDenyCode(row.getString("aprv_deny_cd"));
        transCardBean.setAuthAmountUSD(row.getDecimal("auth_usd_am"));
        transCardBean.setSeNumber(row.getString("auth_se_no"));
        transCardBean.setAuthTransactionDateTime(row.getTimestamp("auth_ts"));
        transCardBean.setAuthAmountLocal(row.getDecimal("auth_loc_am"));
        transCardBean.setCardDac2PrimaryKey(row.getString("card_2dac_cache_key"));
        transCardBean.setCardDac6PrimaryKey(row.getString("card_6dac_cache_key"));
        transCardBean.setRocAuthMatchedFlag(row.getString("auth_mtch_in"));
        transCardBean.setRocAuthMatchedCriteriaId(row.getString("ram_mtch_tier_cd"));
        transCardBean.setAuthUniqueIdentifier(row.getString("cas_pkey"));
      }

      return transCardBean;
    }
  */
  public ResultSet getCasAuthByCardAndSe(RocMatchRequest request, String approveDenyCode)
      throws ParseException {
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    Date authDateTime = sdf.parse(request.getRocTransactionDate());

    BoundStatement boundStatement = selectTransByCardAndSe.bind();
    boundStatement.setString("auth_se_no", request.getRocSENumber());
    boundStatement.setString("cm_15", request.getRocCardNumber());
    boundStatement.setString("aprv_deny_cd", approveDenyCode);

    // Query is not able to compare authDateTime with auth_ts column
    ResultSet resultSet = session.execute(boundStatement);
    return resultSet;
  }

  public void updateMatchAmount(
      RocMatchRequest request, String approveDenyCode, BigDecimal matchAmount) {

    BoundStatement boundStatement = updateMatchAmount.bind();
    boundStatement.setDecimal("match_usd_am", matchAmount);
    boundStatement.setString("trans_id", request.getRocAuthorizationTransactionId());
    boundStatement.setString("cm_15", request.getRocCardNumber());
    boundStatement.setString("aprv_deny_cd", approveDenyCode);
    boundStatement.setConsistencyLevel(ConsistencyLevel.ONE);

    ResultSet resultSet = session.execute(boundStatement);
  }

  @Override
  public CasAuthCardAccessCode6CacheBean getAuthByDac6AndSe6(
      RocMatchRequest request, String approveDenyCode) {

    CasAuthCardAccessCode6CacheBean dac6Bean = null;

    Session session = CassandraConnectionFactory.getInstance().getCassandraSession();
    BoundStatement boundStatement = selectTransByDac6.bind();
    boundStatement.setConsistencyLevel(ConsistencyLevel.ONE);
    boundStatement.setString("cm15", request.getRocCardNumber());
    boundStatement.setString("six_dgt_aprv_cde", request.getRocAuthDAC());
    boundStatement.setString("aprv_deny_cd", approveDenyCode);

    ResultSet resultSet = session.execute(boundStatement);
    for (Row row : resultSet) {
      dac6Bean = new CasAuthCardAccessCode6CacheBean();
      dac6Bean.setCardNumber(row.getString("cm15"));
      dac6Bean.setAuth6Dac(row.getString("six_dgt_aprv_cde"));
      dac6Bean.setApproveDenyCode(row.getString("aprv_deny_cd"));
      dac6Bean.setAuthTransactionDateTime(row.getTimestamp("auth_ts"));
      dac6Bean.setAuthAmountLocal(row.getDecimal("auth_loc_am"));
      dac6Bean.setRocAuthMatchedFlag(row.getString("auth_mtch_in"));

      dac6Bean.setSeNumber(row.getString("auth_se_no"));
      dac6Bean.setAuthAmountUSD(row.getDecimal("auth_usd_am"));

      dac6Bean.setCardDac2PrimaryKey(row.getString("card_2dac_cache_key"));
      dac6Bean.setTidCMPrimaryKey(row.getString("trans_id"));
      dac6Bean.setRocAuthMatchedCriteriaId(row.getString("ram_mtch_tier_cd"));
      dac6Bean.setAuthUniqueIdentifier(row.getString("cas_pkey"));
    }

    return dac6Bean;
  }

  @Override
  public CasAuthCardAccessCode2CacheBean getAuthByDac2AndSe6(
      RocMatchRequest request, String approveDenyCode) {

    CasAuthCardAccessCode2CacheBean dac2Bean = null;

    Session session = CassandraConnectionFactory.getInstance().getCassandraSession();
    BoundStatement boundStatement = selectTransByDac2.bind();
    boundStatement.setConsistencyLevel(ConsistencyLevel.ONE);
    boundStatement.setString("cm15", request.getRocCardNumber());
    boundStatement.setString("two_dgt_aprv_cde", request.getRocAuthDAC());
    boundStatement.setString("aprv_deny_cd", approveDenyCode);

    ResultSet resultSet = session.execute(boundStatement);
    for (Row row : resultSet) {
      dac2Bean = new CasAuthCardAccessCode2CacheBean();
      dac2Bean.setCardNumber(row.getString("cm15"));
      dac2Bean.setAuth2Dac(row.getString("two_dgt_aprv_cde"));
      dac2Bean.setApproveDenyCode(row.getString("aprv_deny_cd"));
      dac2Bean.setAuthTransactionDateTime(row.getTimestamp("auth_ts"));
      dac2Bean.setAuthAmountLocal(row.getDecimal("auth_loc_am"));
      dac2Bean.setRocAuthMatchedFlag(row.getString("auth_mtch_in"));

      dac2Bean.setSeNumber(row.getString("auth_se_no"));
      dac2Bean.setAuthAmountUSD(row.getDecimal("auth_usd_am"));

      dac2Bean.setCardDac6PrimaryKey(row.getString("card_6dac_cache_key"));
      dac2Bean.setTidCMPrimaryKey(row.getString("trans_id"));
      dac2Bean.setRocAuthMatchedCriteriaId(row.getString("ram_mtch_tier_cd"));
      dac2Bean.setAuthUniqueIdentifier(row.getString("cas_pkey"));
    }

    return dac2Bean;
  }

  @Override
  public boolean deleteTransByTid(String transactionId, String cardNumber, String approveDenyCode) {

    Session session = CassandraConnectionFactory.getInstance().getCassandraSession();
    BoundStatement boundStatement = deleteTransByTid.bind();
    boundStatement.setString("trans_id", transactionId);
    boundStatement.setString("cm15", cardNumber);
    boundStatement.setString("aprv_deny_cd", approveDenyCode);

    session.execute(boundStatement);

    return true;
  }

  public String selectNtwktidByRocarn(String roc_arn) throws ParseException {

    Session session = CassandraConnectionFactory.getInstance().getCassandraSession();
    BoundStatement boundStatement = selectMatchResult.bind();
    boundStatement.setString("roc_arn", roc_arn);
    session.execute(boundStatement);

    String networkTid = null;

    ResultSet resultSet = session.execute(boundStatement);
    for (Row row : resultSet) {
      networkTid = row.getString("ntwk_gen_tid_id");
    }
    return networkTid;
  }

  public String selectSeCountryCodeByRocarn(String roc_arn) throws ParseException {

    Session session = CassandraConnectionFactory.getInstance().getCassandraSession();
    BoundStatement boundStatement = selectMatchResult.bind();
    boundStatement.setString("roc_arn", roc_arn);
    session.execute(boundStatement);

    String seCountryCode = null;

    ResultSet resultSet = session.execute(boundStatement);
    for (Row row : resultSet) {
      seCountryCode = row.getString("ctry_cd");
    }
    return seCountryCode;
  }

  @Override
  public RocAuthMatchResult getMatchResult(String roc_arn) throws ParseException {

    Session session = CassandraConnectionFactory.getInstance().getCassandraSession();
    BoundStatement boundStatement = selectMatchResult.bind();
    boundStatement.setString("roc_arn", roc_arn);
    session.execute(boundStatement);

    RocAuthMatchResult rocAuthMatchResult = new RocAuthMatchResult();
    ResultSet resultSet = session.execute(boundStatement);
    for (Row row : resultSet) {
      rocAuthMatchResult.setRoc_arn(roc_arn);
      rocAuthMatchResult.setCas_pkey(row.getString("cas_pkey"));
      rocAuthMatchResult.setAprv_cd(row.getString("aprv_cd"));

      rocAuthMatchResult.setAuth2dac_appr_cd(row.getString("auth2dac_appr_cd"));
      rocAuthMatchResult.setAuth6dac_appr_cd(row.getString("auth6dac_appr_cd"));
      rocAuthMatchResult.setAuth_am_local_curr(row.getDecimal("auth_am_in_local_curr"));
      rocAuthMatchResult.setAuth_am_in_usd(row.getDecimal("auth_am_in_usd"));
      rocAuthMatchResult.setAuth_curr(row.getString("auth_curr"));
      rocAuthMatchResult.setAuth_aprv_deny_cd(row.getString("auth_aprv_deny_cd"));
      rocAuthMatchResult.setAuth_frd_loss_prbl_score(row.getFloat("auth_frd_loss_prbl_score"));
      rocAuthMatchResult.setAuth_frgn_spend_in(row.getString("auth_frgn_spend_in"));
      rocAuthMatchResult.setAuth_lwrc_7dlog_tx(row.getString("auth_lwrcw_7dlog_tx"));
      rocAuthMatchResult.setAuth_mag_swipe_in(row.getString("auth_mag_swipe_in"));
      rocAuthMatchResult.setAuth_mcc(row.getString("auth_mcc"));
      rocAuthMatchResult.setAuth_se10(row.getString("auth_se10"));
      rocAuthMatchResult.setAuth_se_ctry_cd(row.getString("auth_se_ctry_cd"));
      rocAuthMatchResult.setAuth_se_indus_ctgy_cd(row.getString("auth_se_indus_ctgy_cd"));
      rocAuthMatchResult.setAuth_se_type_cd(row.getString("auth_se_type_cd"));
      rocAuthMatchResult.setAuth_trans_id(row.getString("auth_trans_id"));
      rocAuthMatchResult.setDpan(row.getString("dpan_no"));

      try {
        Date ecbCreationTimestamp = row.getTimestamp("trans_ts");
        String ecbCreationString =
            AuthMatchUtil.getStringFromDate(
                ecbCreationTimestamp, AuthMatchUtil.MX_AUTH_DATE_TIME_FORMAT);
        rocAuthMatchResult.setEcbCreationTime(ecbCreationString);
        LocalDate authDate = row.getDate("auth_dt");
        rocAuthMatchResult.setAuth_dt(authDate.toString());
        long authTime = row.getTime("auth_ts");
        if (authTime != 0) {
          Date date = new Date(authTime);
          DateFormat formatter = new SimpleDateFormat("HH:mm:ss.SSS");
          formatter.setTimeZone(TimeZone.getTimeZone("UTC"));
          String dateFormatted = formatter.format(date);
          rocAuthMatchResult.setAuth_ts(dateFormatted);
        }

        LocalDate chargDate = row.getDate("chrg_dt");
        if (chargDate != null) {
          rocAuthMatchResult.setChrg_dt(chargDate.toString());
        }
        LocalDate prcsDate = row.getDate("prcs_dt");
        if (prcsDate != null) {
          rocAuthMatchResult.setPrcs_dt(prcsDate.toString());
        }
        LocalDate rocTransDate = row.getDate("roc_trans_dt");
        if (rocTransDate != null) {
          rocAuthMatchResult.setRoc_trans_dt(rocTransDate.toString());
        }
        Long rocTransTime = row.getTime("roc_trans_tm");
        if (rocTransTime != 0) {

          Date date = new Date(rocTransTime);
          DateFormat formatter = new SimpleDateFormat("HH:mm:ss.SSS");
          formatter.setTimeZone(TimeZone.getTimeZone("UTC"));
          String dateFormatted = formatter.format(date);
          rocAuthMatchResult.setRoc_trans_tm(dateFormatted);
        }

      } catch (Exception e) {

      }

      rocAuthMatchResult.setCtry_cd(row.getString("ctry_cd"));
      rocAuthMatchResult.setHi_risk_api_ivkd_in(row.getBool("hi_risk_api_invkd_in"));
      rocAuthMatchResult.setHi_risk_api_resp_cd(row.getString("hi_risk_api_resp_cd"));
      rocAuthMatchResult.setNtwk_gen_tid_id(row.getString("ntwk_gen_tid_id"));

      rocAuthMatchResult.setRam_in(row.getString("ram_in"));
      rocAuthMatchResult.setRam_tier(row.getString("ram_tier"));
      rocAuthMatchResult.setRoc_auth_dac_cd(row.getString("roc_auth_dac_cd"));
      rocAuthMatchResult.setRoc_cm15(row.getString("roc_cm15"));
      rocAuthMatchResult.setRoc_loc_am(row.getDecimal("roc_loc_am"));
      rocAuthMatchResult.setRoc_loc_am_curr_cd(row.getString("roc_loc_am_curr_cd"));
      rocAuthMatchResult.setRoc_loc_am_dcml_plce_no(row.getInt("roc_loc_am_dcml_plce_no"));
      rocAuthMatchResult.setRoc_se10(row.getString("roc_se10"));

      rocAuthMatchResult.setRoc_usd_am(row.getDecimal("roc_usd_am"));
      rocAuthMatchResult.setSoc_arn(row.getString("soc_arn"));
      rocAuthMatchResult.setSoc_mcc_cd(row.getString("soc_mcc_cd"));
      rocAuthMatchResult.setSoc_se_indus_ctgy_cd(row.getString("soc_se_indus_ctgy_cd"));
      rocAuthMatchResult.setSourceid(row.getString("sourceid"));
      rocAuthMatchResult.setTrans_id(row.getString("trans_id"));
      rocAuthMatchResult.setTrans_type_tx(row.getString("trans_type_tx"));
      rocAuthMatchResult.setPosDataCode(row.getString("pos_data_cd"));
      rocAuthMatchResult.setEciIndicator(row.getString("eci_in"));
      rocAuthMatchResult.setOrig_mcc_cd(row.getString("orig_mcc_cd"));
      rocAuthMatchResult.setVoiceAuthIndicator(row.getString("voice_auth_in"));
    }
    return rocAuthMatchResult;
  }

  @Override
  public CasAuthTransIdCardCacheBean getTransByCardAndSe(
      RocMatchRequest request, String approveDenyCode) {
    // TODO Auto-generated method stub
    return null;
  }
}
