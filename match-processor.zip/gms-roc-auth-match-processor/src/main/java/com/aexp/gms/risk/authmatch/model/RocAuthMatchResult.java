package com.aexp.gms.risk.authmatch.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Builder
@Getter
@Setter
@AllArgsConstructor
@RequiredArgsConstructor
@EqualsAndHashCode
@ToString
public class RocAuthMatchResult {

  @JsonProperty("roc_arn")
  private String roc_arn;

  @JsonProperty("cas_pkey")
  private String cas_pkey;

  @JsonProperty("aprv_cd")
  private String aprv_cd;

  @JsonProperty("auth2dac_appr_cd")
  private String auth2dac_appr_cd;

  @JsonProperty("auth6dac_appr_cd")
  private String auth6dac_appr_cd;

  @JsonProperty("auth_am_local_curr")
  private BigDecimal auth_am_local_curr;

  @JsonProperty("auth_am_in_usd")
  private BigDecimal auth_am_in_usd;

  @JsonProperty("auth_curr")
  private String auth_curr;

  @JsonProperty("auth_dt")
  private String auth_dt;

  @JsonProperty("auth_frd_loss_prbl_score")
  private Float auth_frd_loss_prbl_score;

  @JsonProperty("auth_frgn_spend_in")
  private String auth_frgn_spend_in;

  @JsonProperty("auth_lwrc_7dlog_tx")
  private String auth_lwrc_7dlog_tx;

  @JsonProperty("auth_mag_swipe_in")
  private String auth_mag_swipe_in;

  @JsonProperty("auth_mcc")
  private String auth_mcc;

  @JsonProperty("auth_se10")
  private String auth_se10;

  @JsonProperty("auth_se_ctry_cd")
  private String auth_se_ctry_cd;

  @JsonProperty("auth_se_indus_ctgy_cd")
  private String auth_se_indus_ctgy_cd;

  @JsonProperty("auth_se_type_cd")
  private String auth_se_type_cd;

  @JsonProperty("auth_trans_id")
  private String auth_trans_id;

  @JsonProperty("auth_ts")
  private String auth_ts;

  @JsonProperty("chrg_dt")
  private String chrg_dt;

  @JsonProperty("ctry_cd")
  private String ctry_cd;

  @JsonProperty("hi_risk_api_ivkd_in")
  private boolean hi_risk_api_ivkd_in;

  @JsonProperty("hi_risk_api_resp_cd")
  private String hi_risk_api_resp_cd;

  @JsonProperty("ntwk_gen_tid_id")
  private String ntwk_gen_tid_id;

  @JsonProperty("prcs_dt")
  private String prcs_dt;

  @JsonProperty("ram_in")
  private String ram_in;

  @JsonProperty("ram_tier")
  private String ram_tier;

  @JsonProperty("roc_auth_dac_cd")
  private String roc_auth_dac_cd;

  @JsonProperty("roc_cm15")
  private String roc_cm15;

  @JsonProperty("roc_loc_am")
  private BigDecimal roc_loc_am;

  @JsonProperty("roc_loc_am_curr_cd")
  private String roc_loc_am_curr_cd;

  @JsonProperty("roc_loc_am_dcml_plce_no")
  private int roc_loc_am_dcml_plce_no;

  @JsonProperty("roc_se10")
  private String roc_se10;

  @JsonProperty("roc_trans_dt")
  private String roc_trans_dt;

  @JsonProperty("roc_trans_tm")
  private String roc_trans_tm;

  @JsonProperty("roc_usd_am")
  private BigDecimal roc_usd_am;

  @JsonProperty("soc_arn")
  private String soc_arn;

  @JsonProperty("soc_mcc_cd")
  private String soc_mcc_cd;

  @JsonProperty("soc_se_indus_ctgy_cd")
  private String soc_se_indus_ctgy_cd;

  @JsonProperty("sourceid")
  private String sourceid;

  @JsonProperty("trans_id")
  private String trans_id;

  @JsonProperty("trans_type_tx")
  private String trans_type_tx;

  @JsonProperty("auth_aprv_deny_cd")
  private String auth_aprv_deny_cd;

  @JsonProperty("match_ts")
  private String match_ts;

  @JsonProperty("posDataCode")
  private String posDataCode;

  @JsonProperty("eciIndicator")
  private String eciIndicator;

  @JsonProperty("orig_mcc_cd")
  private String orig_mcc_cd;

  @JsonProperty("voiceAuthIndicator")
  private String voiceAuthIndicator;

  @JsonProperty("dpan")
  private String dpan;

  @JsonProperty("ecbCreationTime")
  private String ecbCreationTime;

  @JsonProperty("prcs_cd")
  private String prcs_cd;

  @JsonProperty("reversal_in")
  private boolean reversal_in;

  public RocAuthMatchResult build(
      RocMatchRequest rocMatchRequest,
      Authorization authorization,
      SubmissionMatchResponse submissionMatchResponse) {

    if (authorization.getSeIndustryCode() != null
        && authorization.getSeIndustryCode().length() > 3) {
      authorization.setSeIndustryCode(null);
    }

    RocAuthMatchResult matchResults =
        RocAuthMatchResult.builder()
            .roc_arn(rocMatchRequest.getRocAcquirerReferenceNumber())
            .cas_pkey(authorization.getAuthUniqeIdentifer())
            .aprv_cd(rocMatchRequest.getRocAuthDAC())
            .auth2dac_appr_cd(authorization.getAuth2DACApproveCode())
            .auth6dac_appr_cd(authorization.getAuth6DACApproveCode())
            .auth_am_local_curr(authorization.getAmountInLocalCurrency())
            .auth_am_in_usd(authorization.getAmountInUSD())
            .auth_curr(authorization.getAuthCurrency())
            .auth_dt(
                authorization.getAuthorizationDate() != null
                    ? authorization.getAuthorizationDate().toString()
                    : null)
            .auth_frd_loss_prbl_score(authorization.getFraudLossProbabilityScore())
            .auth_frgn_spend_in(authorization.getForeignSpendIndicator())
            .auth_lwrc_7dlog_tx(authorization.getCasLogIdentifier())
            .auth_mag_swipe_in(authorization.getMagStripeIndicator())
            .auth_mcc(authorization.getmCC())
            .auth_se10(authorization.getSeNumber())
            .auth_se_ctry_cd(authorization.getSeCountryCode())
            .auth_se_indus_ctgy_cd(authorization.getSeIndustryCode())
            .auth_se_type_cd(authorization.getSeTypeCode())
            .auth_trans_id(authorization.getTransID())
            .auth_ts(
                authorization.getAuthorizationTime() != null
                    ? authorization.getAuthorizationTime().toString()
                    : null)
            .chrg_dt(rocMatchRequest.getRocTransactionDate())
            .ctry_cd(authorization.getSeCountryCode())
            .ntwk_gen_tid_id(rocMatchRequest.getRocNetworkGeneratedTID())
            .roc_auth_dac_cd(rocMatchRequest.getRocAuthDAC())
            .roc_cm15(rocMatchRequest.getRocCardNumber())
            .roc_loc_am(
                rocMatchRequest.getRocLocalAmount() != null
                    ? new BigDecimal(rocMatchRequest.getRocLocalAmount())
                    : null)
            .roc_loc_am_curr_cd(rocMatchRequest.getRocLocalAmountCurrency())
            .roc_loc_am_dcml_plce_no(
                rocMatchRequest.getRocLocalDecimalPlaces() != null
                    ? Integer.parseInt(rocMatchRequest.getRocLocalDecimalPlaces())
                    : 2)
            .roc_se10(rocMatchRequest.getRocSENumber())
            .roc_trans_dt(rocMatchRequest.getRocTransactionDate())
            .roc_trans_tm(rocMatchRequest.getRocTransactionTime())
            .roc_usd_am(new BigDecimal(rocMatchRequest.getRocAmountUSD()))
            .soc_arn(rocMatchRequest.getSocAcquirerReferenceNumber())
            .soc_mcc_cd(rocMatchRequest.getSocMerchantCategoryCode())
            .soc_se_indus_ctgy_cd(rocMatchRequest.getSocSEIndustryCategoryCode())
            .sourceid(authorization.getSourceID())
            .trans_id(rocMatchRequest.getRocAuthorizationTransactionId())
            .trans_type_tx(rocMatchRequest.getTransactionType())
            .auth_aprv_deny_cd(authorization.getApproveDenyCode())
            .prcs_dt(submissionMatchResponse.getProcessDate())
            .ram_in(submissionMatchResponse.getRamIndicator())
            .ram_tier(submissionMatchResponse.getRamTier())
            .hi_risk_api_ivkd_in(false)
            .hi_risk_api_resp_cd(submissionMatchResponse.getRejIndicator())
            .match_ts(submissionMatchResponse.getMatchTimeStamp())
            .posDataCode(submissionMatchResponse.getPosDataCode())
            .eciIndicator(submissionMatchResponse.getEciIndicator())
            .orig_mcc_cd(submissionMatchResponse.getMcc())
            .voiceAuthIndicator(submissionMatchResponse.getVoiceAuthIndicator())
            .dpan(submissionMatchResponse.getDpan())
            .ecbCreationTime(submissionMatchResponse.getEcbCreationTime())
            .prcs_cd(rocMatchRequest.getRocISOProcessingCode())
            .reversal_in(submissionMatchResponse.isReversed())
            .build();
    return matchResults;
  }
}
