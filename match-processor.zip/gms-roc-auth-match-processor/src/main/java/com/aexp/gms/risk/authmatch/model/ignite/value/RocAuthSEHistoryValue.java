package com.aexp.gms.risk.authmatch.model.ignite.value;

public class RocAuthSEHistoryValue {
  String rocSE;
  String authSE;
  String transactionDate;

  public RocAuthSEHistoryValue(String rocSE, String authSE, String transactionDate) {
    this.rocSE = rocSE;
    this.authSE = authSE;
    this.transactionDate = transactionDate;
  }

  public String getRocSE() {
    return rocSE;
  }

  public void setRocSE(String rocSE) {
    this.rocSE = rocSE;
  }

  public String getAuthSE() {
    return authSE;
  }

  public void setAuthSE(String authSE) {
    this.authSE = authSE;
  }

  public String getTransactionDate() {
    return transactionDate;
  }

  public void setTransactionDate(String transactionDate) {
    this.transactionDate = transactionDate;
  }
}
