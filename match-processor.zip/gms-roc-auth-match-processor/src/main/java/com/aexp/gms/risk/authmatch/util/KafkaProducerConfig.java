package com.aexp.gms.risk.authmatch.util;

import com.aexp.gms.risk.authmatch.model.RocAuthMatchResult;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.config.SslConfigs;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

@Slf4j
@PropertySource("classpath:kafka-${env}.properties")
@Component
public class KafkaProducerConfig {

  private final String producerBootstrapServers;
  private final String kafkaTopic;
  private final String keySerializer;
  private final String valueSerializer;
  private final String keystore;
  private KafkaTemplate<String, String> kafkaTemplate;
  private final String keystorePassword;

  public KafkaProducerConfig(
      @Value("${ram.producer.bootstrap.servers}") String producerBootstrapServers,
      @Value("${ram.producer.topic}") String kafkaTopic,
      @Value("${ram.producer.key.serializer}") String keySerializer,
      @Value("${ram.producer.value.serializer}") String valueSerializer,
      @Value("${ram.producer.consumer.keystore.path}") String keystore,
      @Value("${ram.producer.keystore.password}") String keystorePassword) {
    this.producerBootstrapServers = producerBootstrapServers;
    this.kafkaTopic = kafkaTopic;
    this.keySerializer = keySerializer;
    this.valueSerializer = valueSerializer;
    this.keystore = keystore;
    this.keystorePassword = keystorePassword;
  }

  @PostConstruct
  public void init() {
    this.kafkaTemplate = kafkaTemplate();
  }

  private ProducerFactory<String, String> producerFactory() {
    Map<String, Object> properties = new HashMap<>();

    log.debug("keyStoreLocation={}", properties);
    properties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, producerBootstrapServers);
    properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, keySerializer);
    properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, valueSerializer);
    properties.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SSL");
    properties.put(SslConfigs.SSL_PROTOCOL_CONFIG, "SSL");
    properties.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, keystore);
    properties.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, keystorePassword);
    properties.put(SslConfigs.SSL_ENDPOINT_IDENTIFICATION_ALGORITHM_CONFIG, "");
    log.debug("properties={}", properties);
    return new DefaultKafkaProducerFactory<>(properties);
  }

  private KafkaTemplate<String, String> kafkaTemplate() {
    return new KafkaTemplate<>(producerFactory());
  }

  public void publishROCResult(RocAuthMatchResult message) throws JsonProcessingException {
    String json = new ObjectMapper().writeValueAsString(message);
    ListenableFuture<SendResult<String, String>> future = this.kafkaTemplate.send(kafkaTopic, json);

    future.addCallback(
        new ListenableFutureCallback<SendResult<String, String>>() {
          @Override
          public void onFailure(Throwable throwable) {
            log.error("{} Failed to send message to cornerstone", message.getRoc_arn(), throwable);
          }

          @Override
          public void onSuccess(SendResult<String, String> stringStringSendResult) {
            log.info("Message Sent Successfully: ");
          }
        });
  }
}
