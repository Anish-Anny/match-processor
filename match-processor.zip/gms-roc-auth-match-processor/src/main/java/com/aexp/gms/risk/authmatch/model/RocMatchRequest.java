package com.aexp.gms.risk.authmatch.model;

import com.aexp.gmnt.imc.compute.global.IProgramData;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotEmpty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class RocMatchRequest implements IProgramData {

  @JsonProperty(value = "rocSENumber")
  @Digits(fraction = 0, integer = 15)
  @Size(min = 10, max = 15, message = "rocSENumber should be within 10 to 15 characters")
  @NotEmpty(message = "rocSENumber is a mandatory field for match")
  private String rocSENumber;

  @NotEmpty
  @Digits(fraction = 0, integer = 19)
  @Size(min = 13, max = 19, message = "rocCardNumber should be within 13 to 19 characters")
  @JsonProperty(value = "rocCardNumber")
  private String rocCardNumber;

  @NotEmpty
  @JsonProperty(value = "rocAuthorizationTransactionId")
  private String rocAuthorizationTransactionId;

  @JsonProperty(value = "rocTransactionDate")
  @NotEmpty
  @Pattern(regexp = "^\\d{4}\\-(0?[1-9]|1[012])\\-(0?[1-9]|[12][0-9]|3[01])$")
  private String rocTransactionDate;

  @JsonProperty(value = "rocTransactionTime")
  @Pattern(regexp = "^([0-9]|0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]$")
  private String rocTransactionTime;

  @NotEmpty
  @Digits(fraction = 2, integer = 17)
  @JsonProperty(value = "rocAmountUSD")
  private String rocAmountUSD;
  //	@NotEmpty
  @JsonProperty(value = "rocAuthDAC")
  private String rocAuthDAC;

  @NotEmpty
  @JsonProperty(value = "socMerchantCategoryCode")
  private String socMerchantCategoryCode;
  // @NotEmpty
  @JsonProperty(value = "socSEIndustryCategoryCode")
  private String socSEIndustryCategoryCode;

  @NotEmpty
  @JsonProperty(value = "rocAcquirerReferenceNumber")
  private String rocAcquirerReferenceNumber;

  @JsonProperty(value = "oriRocAcquirerReferenceNumber")
  private String oriRocAcquirerReferenceNumber;

  @NotEmpty
  @JsonProperty(value = "socAcquirerReferenceNumber")
  private String socAcquirerReferenceNumber;

  @NotEmpty
  @JsonProperty(value = "transactionType")
  private String transactionType;

  @Size(min = 15, max = 15, message = " rocNetworkGeneratedTID should have only 15 characters")
  @JsonProperty(value = "rocNetworkGeneratedTID")
  private String rocNetworkGeneratedTID;
  // @NotEmpty
  @Digits(fraction = 2, integer = 17)
  @JsonProperty(value = "rocLocalAmount")
  private String rocLocalAmount;

  @Size(min = 3, max = 3, message = " rocLocalAmountCurrency should have only 3 characters")
  @JsonProperty(value = "rocLocalAmountCurrency")
  private String rocLocalAmountCurrency;

  @Size(max = 1, message = " rocLocalDecimalPlaces should have only 1 character")
  @JsonProperty(value = "rocLocalDecimalPlaces")
  private String rocLocalDecimalPlaces;

  @JsonIgnore
  @JsonProperty("amexConsumerAppName")
  private String amexConsumerAppName;

  @JsonIgnore
  @JsonProperty("eligibleTiersList")
  private List<String> eligibleTiersList;

  @JsonProperty("rocISOProcessingCode")
  private String rocISOProcessingCode;

  private boolean isReversalCode;

  public boolean isReversalCode() {
    return isReversalCode;
  }

  public void setOriRocAcquirerReferenceNumber(String oriRocAcquirerReferenceNumber) {
    this.oriRocAcquirerReferenceNumber = oriRocAcquirerReferenceNumber.trim();
  }

  public void setReversalCode(boolean isReversalCode) {
    this.isReversalCode = isReversalCode;
  }

  public String getRocISOProcessingCode() {
    return rocISOProcessingCode;
  }

  public void setRocISOProcessingCode(String rocISOProcessingCode) {
    this.rocISOProcessingCode = rocISOProcessingCode;
  }

  public List<String> getEligibleTiersList() {
    return eligibleTiersList;
  }

  public void setEligibleTiersList(List<String> eligibleTiersList) {
    this.eligibleTiersList = eligibleTiersList;
  }

  public String getAmexConsumerAppName() {
    return amexConsumerAppName;
  }

  public void setAmexConsumerAppName(String amexConsumerAppName) {
    this.amexConsumerAppName = amexConsumerAppName;
  }

  public String getRocSENumber() {
    return rocSENumber;
  }

  public void setRocSENumber(String rocSENumber) {
    this.rocSENumber = rocSENumber.trim();
  }

  public String getRocCardNumber() {
    return rocCardNumber;
  }

  public void setRocCardNumber(String rocCardNumber) {
    this.rocCardNumber = rocCardNumber.trim();
  }

  public String getRocTransactionDate() {
    return rocTransactionDate;
  }

  public void setRocTransactionDate(String rocTransactionDate) {
    this.rocTransactionDate = rocTransactionDate;
  }

  public String getRocTransactionTime() {
    return rocTransactionTime;
  }

  public void setRocTransactionTime(String rocTransactionTime) {
    this.rocTransactionTime = rocTransactionTime;
  }

  public String getSocMerchantCategoryCode() {
    return socMerchantCategoryCode;
  }

  public void setSocMerchantCategoryCode(String socMerchantCategoryCode) {
    this.socMerchantCategoryCode = socMerchantCategoryCode;
  }

  public String getRocAuthorizationTransactionId() {
    return rocAuthorizationTransactionId;
  }

  public void setRocAuthorizationTransactionId(String rocAuthorizationTransactionId) {
    this.rocAuthorizationTransactionId = rocAuthorizationTransactionId.trim();
  }

  public String getRocAmountUSD() {
    return rocAmountUSD;
  }

  public void setRocAmountUSD(String rocAmountUSD) {
    this.rocAmountUSD = rocAmountUSD.trim();
  }

  public String getRocAuthDAC() {
    return rocAuthDAC;
  }

  public void setRocAuthDAC(String rocAuthDAC) {
    this.rocAuthDAC = rocAuthDAC.trim();
  }

  public String getSocSEIndustryCategoryCode() {
    return socSEIndustryCategoryCode;
  }

  public void setSocSEIndustryCategoryCode(String socSEIndustryCategoryCode) {
    this.socSEIndustryCategoryCode = socSEIndustryCategoryCode.trim();
  }

  public String getRocAcquirerReferenceNumber() {
    return rocAcquirerReferenceNumber;
  }

  public void setRocAcquirerReferenceNumber(String rocAcquirerReferenceNumber) {
    this.rocAcquirerReferenceNumber = rocAcquirerReferenceNumber.trim();
  }

  public String getOriRocAcquirerReferenceNumber() {
    return oriRocAcquirerReferenceNumber;
  }

  public String getSocAcquirerReferenceNumber() {
    return socAcquirerReferenceNumber;
  }

  public void setSocAcquirerReferenceNumber(String socAcquirerReferenceNumber) {
    this.socAcquirerReferenceNumber = socAcquirerReferenceNumber.trim();
  }

  public String getTransactionType() {
    return transactionType;
  }

  public void setTransactionType(String transactionType) {
    this.transactionType = transactionType.trim();
  }

  public String getRocNetworkGeneratedTID() {
    return rocNetworkGeneratedTID;
  }

  public void setRocNetworkGeneratedTID(String rocNetworkGeneratedTID) {
    this.rocNetworkGeneratedTID = rocNetworkGeneratedTID;
  }

  public String getRocLocalAmount() {
    return rocLocalAmount;
  }

  public void setRocLocalAmount(String rocLocalAmount) {
    this.rocLocalAmount = rocLocalAmount;
  }

  public String getRocLocalAmountCurrency() {
    return rocLocalAmountCurrency;
  }

  public void setRocLocalAmountCurrency(String rocLocalAmountCurrency) {
    this.rocLocalAmountCurrency = rocLocalAmountCurrency;
  }

  public String getRocLocalDecimalPlaces() {
    return rocLocalDecimalPlaces;
  }

  public void setRocLocalDecimalPlaces(String rocLocalDecimalPlaces) {
    this.rocLocalDecimalPlaces = rocLocalDecimalPlaces;
  }
}
