package com.aexp.gms.risk.authmatch.util;

import java.net.InetAddress;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AuthMatchUtil {

  public enum MatchTiers {
    TIER_1("T01"),
    TIER_2("T02"),
    TIER_3("T03"),
    TIER_4("T04"),
    TIER_5("T05"),
    TIER_6("T06"),
    TIER_7("T07"),
    TIER_8("T08"),
    TIER_9("T09"),
    TIER_11("T11");

    public String value;

    private MatchTiers(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }
  }

  private static final Logger logger = LoggerFactory.getLogger(AuthMatchUtil.class);
  public static final String MX_AUTH_DATE_TIME_FORMAT = "yyyy-MM-dd-HH:mm:ss.SSS";

  /*
   * This Utility method logs the Response time taken from respective
   * resource.
   */
  public static String getAPIResponseTime(long startTime) {

    return String.format("%02d", Instant.now().toEpochMilli() - startTime);
  }

  public static String getCASPKey(Date date, String casLogIdentifier) {
    return toJulian(date) + leftPad(casLogIdentifier, 10, '0');
  }

  public static long toJulian(Date date) {
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(date);
    String julian =
        String.valueOf(calendar.get(Calendar.YEAR))
            + leftPad(String.valueOf(calendar.get(Calendar.DAY_OF_YEAR)), 3, '0');
    return Long.parseLong(julian);
  }

  public static String leftPad(String originalString, int length, char padCharacter) {
    StringBuilder sb = new StringBuilder();
    while (sb.length() + originalString.length() < length) {
      sb.append(padCharacter);
    }
    sb.append(originalString);
    String paddedString = sb.toString();
    return paddedString;
  }

  public static String getMaskedCMNumber(String cardNumber) {

    return cardNumber == null
        ? ""
        : (cardNumber.substring(0, 11)) + StringUtils.repeat("X", cardNumber.length() - 11);
  }
  /**
   * Identifies the current pod name
   *
   * @return
   */
  public static String getHostName() {
    String host = "";
    try {
      host = InetAddress.getLocalHost().getHostName();
    } catch (Exception e) {

      logger.error("Unable to retrieve host name", e);
    }
    return host;
  }

  public static String getStringFromDate(Date date, String format) {
    String emptyString = "";
    try {
      DateFormat readFormat = new SimpleDateFormat(format);
      readFormat.setTimeZone(TimeZone.getTimeZone("MST"));
      return readFormat.format(date);
    } catch (Exception e) {
      logger.info("Date Conversion Issue {} And Formate {}", date, format);
    }
    return emptyString;
  }

  public static boolean isEligibleTierListContainsTier(
      List<String> eligibleTiersList, String... tiers) {
    for (String tier : tiers) {
      if (eligibleTiersList.contains(tier)) return true;
    }

    return false;
  }
}
