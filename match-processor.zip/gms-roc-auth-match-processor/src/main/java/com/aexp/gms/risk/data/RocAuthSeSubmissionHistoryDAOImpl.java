package com.aexp.gms.risk.data;

import com.aexp.gms.risk.authmatch.model.ignite.key.RocAuthSEHistoryKey;
import com.aexp.gms.risk.authmatch.model.ignite.value.RocAuthSEHistoryValue;
import com.aexp.gms.risk.authmatch.util.AuthMatchLog;
import com.datastax.driver.core.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/** Created by rmanick on 04/08/2019. */
@Component
public class RocAuthSeSubmissionHistoryDAOImpl {

  private final String CLASS_NAME = "RocAuthSeSubmissionHistoryDAOImpl";

  static PreparedStatement selectSeRocAuthSubmissionHistory = null;
  static PreparedStatement insertSeRocAuthSubmissionHistory = null;
  Session session = null;
  public static final String SELECT_HISTORICAL_SE_SUBMISSION =
      "select * from roc_auth_se_subm_hist WHERE roc_se_no = ? and auth_se_no = ?";

  public static final String INSERT_HISTORICAL_SE_SUBMISSION =
      "insert into roc_auth_se_subm_hist (roc_se_no, auth_se_no, trans_dt) "
          + " values (?,?,?) USING TTL 7776600 ";

  private AuthMatchLog authMatchLog =
      new AuthMatchLog(RocAuthSeSubmissionHistoryDAOImpl.class.getPackage().getName());

  private final Logger LOGGER = LoggerFactory.getLogger(RocAuthSeSubmissionHistoryDAOImpl.class);

  public RocAuthSeSubmissionHistoryDAOImpl() {
    session = CassandraConnectionFactory.getInstance().getCassandraSession();
    if (selectSeRocAuthSubmissionHistory == null) {
      selectSeRocAuthSubmissionHistory = session.prepare(SELECT_HISTORICAL_SE_SUBMISSION);
    }
    if (insertSeRocAuthSubmissionHistory == null) {
      insertSeRocAuthSubmissionHistory = session.prepare(INSERT_HISTORICAL_SE_SUBMISSION);
    }
  }

  public boolean isRocAuthSEHistoryPresent(RocAuthSEHistoryKey rocAuthSEHistory) {
    BoundStatement boundStatement = selectSeRocAuthSubmissionHistory.bind();
    boundStatement.setString(0, rocAuthSEHistory.getRocSE());
    boundStatement.setString(1, rocAuthSEHistory.getAuthSE());
    boundStatement.setConsistencyLevel(ConsistencyLevel.ONE);
    ResultSet resultSet = session.execute(boundStatement);
    if (resultSet.iterator().hasNext()) {
      return true;
    }

    return false;
  }

  public void insertRocAuthSEHistory(RocAuthSEHistoryValue rocAuthSEHistory) {

    java.time.LocalDate localDate =
        java.time.LocalDate.parse(rocAuthSEHistory.getTransactionDate());

    Statement insertSeRocAuthBS =
        insertSeRocAuthSubmissionHistory.bind(
            rocAuthSEHistory.getRocSE(), rocAuthSEHistory.getAuthSE(), localDate);

    session.execute(insertSeRocAuthBS);
  }
}
