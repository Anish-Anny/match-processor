package com.aexp.gms.risk.authmatch.model;

public class ResponseMetaData {

  /* Handle following HTTP response codes
   * 200 OK
   * 400 Bad Request
   * 404 Not Found
   * 403 Forbidden
   * 500 Internal Server Error
   *
   */
  private String ResponseTime;

  private String Code = "";

  private String ShortMessage;

  public String getResponseTime() {
    return ResponseTime;
  }

  public void setResponseTime(String responseTime) {
    ResponseTime = responseTime;
  }

  public String getCode() {
    return Code;
  }

  public void setCode(String code) {
    Code = code;
  }

  public String getShortMessage() {
    return ShortMessage;
  }

  public void setShortMessage(String shortMessage) {
    ShortMessage = shortMessage;
  }

  @Override
  public String toString() {
    // return String.format( "ResponseMetaData[ResponseTime=%s,Code=%s,ShortMessage=%s]",
    // ResponseTime,Code,ShortMessage);
    StringBuilder StringBuild =
        new StringBuilder(1000)
            .append("\"ResponseMetaData\":")
            .append("{\"ResponseTime\":\"")
            .append(ResponseTime)
            .append("\",")
            .append("\"Code\":\"")
            .append(Code)
            .append("\",")
            .append("\"ShortMessage\":\"")
            .append(ShortMessage)
            .append("\"}");
    return StringBuild.toString();
  }
}
