package com.aexp.gms.risk.authmatch.util;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.PropertySourcesPropertyResolver;
import org.springframework.core.env.StandardEnvironment;
import org.springframework.core.io.support.PropertiesLoaderUtils;

public class PropertyLoaderUtils {

  private static final Logger log = LoggerFactory.getLogger(PropertyLoaderUtils.class);
  private static StandardEnvironment env = new StandardEnvironment();

  private static Map<String, Properties> propertiesMap = new HashMap<String, Properties>();

  public Properties createProperties(String fileName) throws Exception {
    return loadProperties(fileName);
  }
  /**
   * Address three scenarios. Loads from only classpath If input does not ends with properties then
   * add .properties Check for input-{env}.properties if it presents loads that if not then loads
   * input.properties Check env entry in JVM System properties Utilizes Spring Framework to do the
   * file loading
   *
   * @param fileName
   * @return Properties
   * @throws Exception
   */
  public static Properties loadProperties(String fileName) throws Exception {
    Properties props = propertiesMap.get(fileName);
    if (props == null) props = readPropertyFile(fileName);
    return props;
  }

  public Properties mergeProperties(String... fileNames) {
    Properties mergedProperties = new Properties();
    Arrays.stream(fileNames)
        .map(
            t -> {
              try {
                return loadProperties(t);
              } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
              }
              return mergedProperties;
            })
        .forEach(mergedProperties::putAll);
    return mergedProperties;
  }

  private static String getFileName(String fileName) {
    String tmpFileName = fileName;
    if (!fileName.endsWith(".properties")) {
      tmpFileName = tmpFileName + ".properties";
    }
    return tmpFileName;
  }

  private static String getEnvFileName(String fileName) {
    String tmpFileName = fileName.substring(0, fileName.lastIndexOf(".properties"));
    if (!(tmpFileName.contains("${env}"))) {
      tmpFileName = tmpFileName + "-${env}";
    }
    tmpFileName = tmpFileName + ".properties";
    return tmpFileName;
  }

  public static String resolveFileName(String fileName) {
    String returnFile = fileName;
    if (returnFile.contains("-${env}")) {
      PropertySourcesPropertyResolver resolver =
          new PropertySourcesPropertyResolver(env.getPropertySources());
      returnFile = resolver.resolvePlaceholders(fileName);
    }
    if (returnFile.contains("-${env}")) {
      returnFile = returnFile.replace("-${env}", "");
    }
    return returnFile;
  }

  public static String getProperty(String fileName, String propertyName) throws Exception {
    return loadProperties(fileName).getProperty(propertyName);
  }

  private static synchronized Properties readPropertyFile(String fileName) throws Exception {
    Properties properties = propertiesMap.get(fileName);
    if (properties != null) return properties;
    PropertySourcesPropertyResolver resolver =
        new PropertySourcesPropertyResolver(env.getPropertySources());
    String propertyFile = getFileName(fileName);
    String s = getEnvFileName(propertyFile);
    String envPropFileName = resolver.resolvePlaceholders(s);

    Properties props = null;
    try {
      props = PropertiesLoaderUtils.loadAllProperties(envPropFileName);
    } catch (IOException e) {
      log.error("Exception thrown when loading properties with env specific " + envPropFileName, e);
    }
    if (props == null || props.isEmpty()) {
      log.info("Unable to load properties with env specific {} ", envPropFileName);
      log.info("Going to load properties without env suffix {} ", propertyFile);
      try {
        props = PropertiesLoaderUtils.loadAllProperties(propertyFile);
      } catch (IOException e) {
        log.error(
            "Exception thrown when loading properties without env specific {} ", propertyFile, e);
      }
      if (props == null) {
        log.info("Unable to load properties {} ", propertyFile);
      }
    } else {
      log.info("Loaded properties with env specific {} ", envPropFileName);
    }
    if (props == null) {
      throw new Exception(String.format("Unable to load properties %s ", propertyFile));
    }
    log.info("Properties loaded {} ", props);
    propertiesMap.put(fileName, props);
    return props;
  }
  /**
   * Goes through the input string and replaces "${key}" with its value, if found.
   *
   * @param input
   * @return
   */
  public static String resolveString(String input) {
    if (input == null) {
      return input;
    }

    PropertySourcesPropertyResolver resolver =
        new PropertySourcesPropertyResolver(env.getPropertySources());
    String out = resolver.resolvePlaceholders(input);

    return out;
  }
}
