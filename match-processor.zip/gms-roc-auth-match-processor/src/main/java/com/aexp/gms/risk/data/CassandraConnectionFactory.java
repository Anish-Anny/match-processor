package com.aexp.gms.risk.data;

import com.aexp.gmnt.imc.compute.global.IMCRuntimeException;
import com.aexp.gms.risk.authmatch.util.PropertyLoaderUtils;
import com.datastax.driver.core.*;
import com.datastax.driver.core.policies.DCAwareRoundRobinPolicy;
import com.datastax.driver.core.policies.TokenAwarePolicy;
import com.datastax.driver.dse.auth.DsePlainTextAuthProvider;
import com.datastax.driver.extras.codecs.date.SimpleTimestampCodec;
import com.datastax.driver.extras.codecs.jdk8.LocalDateCodec;
import com.datastax.driver.extras.codecs.jdk8.LocalTimeCodec;
import java.security.GeneralSecurityException;
import java.util.Properties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.cassandra.core.cql.CqlTemplate;

public class CassandraConnectionFactory {
  private Cluster cluster = null;
  private volatile Session cassandraSession;
  private volatile CqlTemplate cassandraCqlTemplate;
  private volatile KeyspaceMetadata keyspaceMetadata;
  private String keySpace = "";
  private final Logger LOGGER = LoggerFactory.getLogger(CassandraConnectionFactory.class);

  public CassandraConnectionFactory() {

    try {

      Properties connectionProperties =
          PropertyLoaderUtils.loadProperties("cassandra-connection-${env}.properties");
      String[] hostnames = connectionProperties.getProperty("cassandra.conn.hostnames").split(",");
      Integer port = Integer.parseInt(connectionProperties.getProperty("cassandra.conn.port"));
      keySpace =
          PropertyLoaderUtils.resolveString(
              connectionProperties.getProperty("cassandra.conn.keyspace"));
      String user = connectionProperties.getProperty("cassandra.cred.user");
      String password = connectionProperties.getProperty("cassandra.cred.password");
      Integer heartBeatInterval =
          Integer.parseInt(connectionProperties.getProperty("cassandra.pool.hearbeatsecs"));
      Integer poolCoreConnections =
          Integer.parseInt(connectionProperties.getProperty("cassandra.pool.coreconns"));
      Integer poolMaxConnections =
          Integer.parseInt(connectionProperties.getProperty("cassandra.pool.maxconns"));
      Integer poolConnectionTimeout =
          Integer.parseInt(connectionProperties.getProperty("cassandra.pool.timeoutms"));
      String localDc = connectionProperties.getProperty("cassandra.conn.localDC");
      Integer usedHostsPerRemoteDc =
          Integer.parseInt(connectionProperties.getProperty("cassandra.conn.usedHostsPerRemoteDc"));

      /*
                  if (user != null)
                      user = EncryptionUtil.decrypt(user);
                  if (password != null)
                      password = EncryptionUtil.decrypt(password);
      */

      DCAwareRoundRobinPolicy dcPolicy =
          DCAwareRoundRobinPolicy.builder()
              .withLocalDc(localDc)
              .withUsedHostsPerRemoteDc(usedHostsPerRemoteDc)
              .build();
      TokenAwarePolicy tokenAwareDcPolicy = new TokenAwarePolicy(dcPolicy);

      cluster =
          Cluster.builder()
              .addContactPoints(hostnames)
              .withLoadBalancingPolicy(tokenAwareDcPolicy)
              .withPort(port)
              .withAuthProvider(new DsePlainTextAuthProvider(user, password))
              .withQueryOptions(new QueryOptions().setConsistencyLevel(ConsistencyLevel.TWO))
              .withPoolingOptions(
                  new PoolingOptions()
                      .setHeartbeatIntervalSeconds(heartBeatInterval)
                      .setConnectionsPerHost(
                          HostDistance.LOCAL, poolCoreConnections, poolMaxConnections))
              .build();

      cluster
          .getConfiguration()
          .getCodecRegistry()
          .register(LocalTimeCodec.instance)
          .register(LocalDateCodec.instance)
          .register(SimpleTimestampCodec.instance);

      cassandraSession = cluster.connect(keySpace);
    } catch (NumberFormatException nfe) {
      LOGGER.error(
          "CassandraConnectionFactory",
          "CassandraConnectionFactory",
          "Invalid value for Cassandra configuration parameter - One or more number only configuration paramenter has non numeric value",
          "RAM",
          "",
          nfe);
    } catch (GeneralSecurityException gse) {
      LOGGER.error(
          "CassandraConnectionFactory",
          "CassandraConnectionFactory",
          "Exception in decrypting cassandra credentials ",
          "RAM",
          "",
          gse);
    } catch (Exception e) {
      LOGGER.error(
          "CassandraConnectionFactory",
          "CassandraConnectionFactory",
          "General Error",
          "RAM",
          "",
          e);
    }
  }

  public static CassandraConnectionFactory getInstance() throws IMCRuntimeException {
    return LazyHolder.CASSANDRA_CONNECTION_FACTORY;
  }

  public Session getCassandraSession() {
    Session returnSession = cassandraSession;
    if (returnSession == null || returnSession.isClosed()) {
      synchronized (this) {
        returnSession = cassandraSession;
        if (returnSession == null || returnSession.isClosed()) {
          cassandraSession = returnSession = cluster.connect(keySpace);
        }
      }
    }
    return returnSession;
  }

  public Session getLocalCassandraSession() {
    Cluster cluster = new Cluster.Builder().addContactPoints("localhost").withPort(9142).build();
    cassandraSession = cluster.connect("PDCKS1031");
    Session returnSession = cassandraSession;
    if (returnSession == null || returnSession.isClosed()) {
      synchronized (this) {
        returnSession = cassandraSession;
        if (returnSession == null || returnSession.isClosed()) {
          cassandraSession = returnSession = cluster.connect(keySpace);
        }
      }
    }
    return returnSession;
  }

  public CqlTemplate getCassandraCqlTemplate() {
    CqlTemplate returnCqlTemplate = cassandraCqlTemplate;
    if (returnCqlTemplate == null) {
      synchronized (this) {
        returnCqlTemplate = cassandraCqlTemplate;
        if (returnCqlTemplate == null) {
          cassandraCqlTemplate = returnCqlTemplate = new CqlTemplate(getCassandraSession());
        }
      }
    }
    return returnCqlTemplate;
  }

  public KeyspaceMetadata getKeyspaceMetadata() {

    KeyspaceMetadata returnKeyspaceMetadata = keyspaceMetadata;

    if (returnKeyspaceMetadata == null) {
      synchronized (this) {
        returnKeyspaceMetadata = keyspaceMetadata;
        if (returnKeyspaceMetadata == null) {
          keyspaceMetadata =
              returnKeyspaceMetadata =
                  getCassandraSession().getCluster().getMetadata().getKeyspace(keySpace);
        }
      }
    }
    return returnKeyspaceMetadata;
  }

  private static class LazyHolder {
    private static final CassandraConnectionFactory CASSANDRA_CONNECTION_FACTORY =
        new CassandraConnectionFactory();

    private LazyHolder() {}
  }
}
