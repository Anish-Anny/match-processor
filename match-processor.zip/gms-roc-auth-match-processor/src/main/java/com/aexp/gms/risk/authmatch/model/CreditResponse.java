package com.aexp.gms.risk.authmatch.model;

import com.aexp.gmnt.imc.compute.global.IProgramData;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "creditResponse")
@XmlType(propOrder = {"responseMetaData", "creditCheck"})
@XmlAccessorType(XmlAccessType.FIELD)
public class CreditResponse implements IProgramData {

  private ResponseMetaData responseMetaData;
  private String creditCheck;

  public ResponseMetaData getResponseMetaData() {
    return responseMetaData;
  }

  public void setResponseMetaData(ResponseMetaData responseMetaData) {
    this.responseMetaData = responseMetaData;
  }

  public String getCreditCheck() {
    return creditCheck;
  }

  public void setCreditCheck(String creditCheck) {
    this.creditCheck = creditCheck;
  }

  //	public String getResultRemarks() {
  //		return resultRemarks;
  //	}
  //
  //	public void setResultRemarks(String resultRemarks) {
  //		this.resultRemarks = resultRemarks;
  //	}

}
