package com.aexp.gms.risk.authmatch.util;

import java.math.BigDecimal;

public interface AuthMatchConstants {

  String ENV_DEPENDENT_PROPS = "env_dependent_props";
  String SEVERITY = "1PSEV";
  String SEV_4 = "4";

  String BOOTSTRAP_SERVERS = "bootstrap.servers";
  String ENABLE_AUTO_COMMIT = "enable.auto.commit";
  String AUTO_COMMIT_INTERVAL_MS = "auto.commit.interval.ms";
  String SESSION_TIMEOUT_MS = "session.timeout.ms";
  String KEY_DESERIALIZER = "key.deserializer";
  String VALUE_DESERIALIZER = "value.deserializer";
  String KEY_SERIALIZER = "key.serializer";
  String VALUE_SERIALIZER = "value.serializer";
  String AUTH_MATCH_KAFKA_TOPIC = "kafka.input.topicname";
  String GROUP_ID = "group.id";
  String KAFKA_TRUSTSTORE_PATH = "kafka.truststore.path";
  String CONSUMER_KEYSTORE_PATH = "consumer.keystore.path";
  String CAS_AUTH_CACHE = "GMSRisk_CACHE_CAS_AUTH";
  String CAS_AUTH_TID_CM_CACHE = "GMS_CAS_AUTH_TID_CM_CACHE_V3";
  String CAS_AUTH_CM_DAC6_CACHE = "GMS_CAS_AUTH_CM_DAC6_CACHE_V1";
  String CAS_AUTH_CM_DAC2_CACHE = "GMS_CAS_AUTH_CM_DAC2_CACHE_V1";
  String SE_SE_INDUSTRY_LEVERAGE_CACHE = "SE_INDUSTRY_LEVERAGE_CACHE_V2";
  String CACHE_TABLENAME = "CasAuthTransIdCardCacheBean2";
  String IGNITE_COUNT_DOWN_CACHE = "RAM-RISK-ASSESS-THRESHOLD";

  int RISK_ASSESSMENT_THRESHOLD_LIMIT = 3000000;
  BigDecimal RISK_ASSESSMENT_AMOUNT_THRESHOLD = BigDecimal.valueOf(100000, 2);
  int RISK_ASSESSMENT_THRESHOLD_TTL = 5;

  String updateByCMAndIndustryLeverage =
      "UPDATE CasAuthTransIdCardCacheBean SET RocAuthMatchedFlag = 'Y', rocAuthMatchedCriteriaId = '3' WHERE _KEY = '%s' AND AUTHAMOUNTUSD >= %s and AUTHAMOUNTUSD <= %s";
  String updateByCMAndIndustryLeverageAmountDiff =
      "UPDATE CasAuthTransIdCardCacheBean SET RocAuthMatchedFlag = 'Y', rocAuthMatchedCriteriaId = '3' WHERE _KEY = '%s' AND (%s - AUTHAMOUNTUSD) <= 100";
  String updateByCardDac6AndAmoutLeverageSEDate =
      "UPDATE CASAUTHCARDACCESSCODE6CACHEBEAN SET RocAuthMatchedFlag ='Y' , rocAuthMatchedCriteriaId = '4' WHERE _KEY like '%s' AND SENUMBER= '%s' AND  FORMATDATETIME (AUTHTRANSACTIONDATETIME, 'YYYY-MM-dd') >='%s' AND FORMATDATETIME (AUTHTRANSACTIONDATETIME, 'YYYY-MM-dd') < '%s' AND AUTHAMOUNTUSD >= %s and AUTHAMOUNTUSD <= %s";
  String updateDac6AMatched =
      "UPDATE CASAUTHCARDACCESSCODE6CACHEBEAN SET RocAuthMatchedFlag ='Y' , rocAuthMatchedCriteriaId = '4' WHERE _KEY = '%s'";
  String updateDac2AMatched =
      "UPDATE CASAUTHCARDACCESSCODE2CACHEBEAN SET RocAuthMatchedFlag ='Y' , rocAuthMatchedCriteriaId = '4' WHERE _KEY = '%s'";
  String getTidCMCacheDataByKey =
      "SELECT _KEY, AUTHAMOUNTUSD, AUTHTRANSACTIONDATETIME, CARDDAC6PRIMARYKEY, CARDDAC2PRIMARYKEY FROM CasAuthTransIdCardCacheBean WHERE _KEY = '%s'";
  String getCardDac6CacheDataByKey =
      "SELECT _key, CARDNUMBER,AUTH6DAC,SENUMBER, AUTHTRANSACTIONDATETIME, AUTHAMOUNTUSD, ROCAUTHMATCHEDFLAG, TIDCMPRIMARYKEY, CARDDAC2PRIMARYKEY FROM CASAUTHCARDACCESSCODE6CACHEBEAN WHERE _KEY = '%s'";
  String getCardDac2CacheDataByKey =
      "SELECT _key, CARDNUMBER,AUTH2DAC,SENUMBER, AUTHTRANSACTIONDATETIME, AUTHAMOUNTUSD, ROCAUTHMATCHEDFLAG, TIDCMPRIMARYKEY, CARDDAC6PRIMARYKEY FROM CASAUTHCARDACCESSCODE2CACHEBEAN WHERE _KEY = '%s'";

  String getCasAuthDataByCardSE =
      "SELECT authAmountUSD, transactionId, cardDac6PrimaryKey, cardDac2PrimaryKey FROM %s WHERE approveDenyCode = 'A' AND cardNumber = '%s' AND seNumber = '%s' AND FORMATDATETIME (authTransactionDateTime, 'YYYY-MM-dd') = FORMATDATETIME ('%s', 'YYYY-MM-dd') AND transactionId != %S AND authAmountUSD < %S AND ROCAUTHMATCHEDFLAG <> 'Y'";
  String getCasAuthDataByTier9 =
      "SELECT transactionId, cardDac6PrimaryKey FROM %s WHERE approveDenyCode = 'A' AND cardNumber = '%s' AND seNumber = '%s' "
          + " AND FORMATDATETIME (AUTHTRANSACTIONDATETIME, 'YYYY-MM-dd') >=FORMATDATETIME ('%s', 'YYYY-MM-dd') "
          + " AND FORMATDATETIME (AUTHTRANSACTIONDATETIME, 'YYYY-MM-dd') < FORMATDATETIME ('%s', 'YYYY-MM-dd') "
          + " AND ROCAUTHMATCHEDFLAG <> 'Y'";

  String getCasAuthDataByCardSEDateAmount =
      "SELECT * FROM %s WHERE cardNumber = '%s' AND seNumber = '%s' "
          + " AND FORMATDATETIME (AUTHTRANSACTIONDATETIME, 'YYYY-MM-dd') >=FORMATDATETIME ('%s', 'YYYY-MM-dd') "
          + " AND FORMATDATETIME (AUTHTRANSACTIONDATETIME, 'YYYY-MM-dd') < FORMATDATETIME ('%s', 'YYYY-MM-dd') "
          + "AND authAmountUSD >= %S AND authAmountUSD <= %S";

  String CASAUTH_DATABY_CARD_SE_DATE =
      "SELECT authAmountUSD, transactionId FROM %s WHERE cardNumber = '%s' AND seNumber = '%s' "
          + " AND FORMATDATETIME (AUTHTRANSACTIONDATETIME, 'YYYY-MM-dd') >=FORMATDATETIME ('%s', 'YYYY-MM-dd') "
          + " AND FORMATDATETIME (AUTHTRANSACTIONDATETIME, 'YYYY-MM-dd') < FORMATDATETIME ('%s', 'YYYY-MM-dd') "
          + "AND %S >= authAmountUSD*0.75 "
          + "AND %S <= authAmountUSD*1.25";

  String CASAUTH_DATABY_CARD_SE_DATE_LOCAL_AMOUNT =
      "SELECT authAmountLocal, transactionId FROM %s WHERE cardNumber = '%s' AND seNumber = '%s' "
          + " AND FORMATDATETIME (AUTHTRANSACTIONDATETIME, 'YYYY-MM-dd') >=FORMATDATETIME ('%s', 'YYYY-MM-dd') "
          + " AND FORMATDATETIME (AUTHTRANSACTIONDATETIME, 'YYYY-MM-dd') < FORMATDATETIME ('%s', 'YYYY-MM-dd') "
          + "AND %S >= authAmountLocal*0.75 "
          + "AND %S <= authAmountLocal*1.25";

  String selectCassAuthByTid =
      "select * from auth_by_trans_id where trans_id = ? and cm_15 = ? and aprv_deny_cd = ?";
  String deleteCassAuthByTid =
      "delete from auth_by_trans_id where trans_id = ? and cm_15 = ? and aprv_deny_cd = ?";

  String selectCassAuthByDac6 =
      "select * from auth_by_6dac_and_se where cm15 = ? and six_dgt_aprv_cde = ? and aprv_deny_cd = ?";
}
