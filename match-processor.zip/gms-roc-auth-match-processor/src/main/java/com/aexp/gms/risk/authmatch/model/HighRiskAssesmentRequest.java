package com.aexp.gms.risk.authmatch.model;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Builder
@Getter
@Setter
@RequiredArgsConstructor
@EqualsAndHashCode
@ToString
public class HighRiskAssesmentRequest {

  public HighRiskAssesmentRequest(RiskAssessmentRequest riskAssessmentRequest) {
    setRisk_assessment(riskAssessmentRequest);
  }

  private RiskAssessmentRequest risk_assessment;
}
