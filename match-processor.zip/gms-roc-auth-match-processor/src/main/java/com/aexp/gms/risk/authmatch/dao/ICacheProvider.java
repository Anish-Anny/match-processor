package com.aexp.gms.risk.authmatch.dao;

import com.aexp.gms.imc.risk.rules.vo.keys.ICacheKey;
import com.aexp.gms.imc.risk.rules.vo.values.ICacheBean;
import com.aexp.gms.risk.authmatch.exception.AuthMatchSystemException;
import java.util.List;
import org.apache.ignite.binary.BinaryObject;

public interface ICacheProvider {

  public boolean startCacheProvider() throws AuthMatchSystemException;

  public boolean reStartCacheProvider() throws AuthMatchSystemException;

  public ICacheBean getCache(String cacheName, ICacheKey key) throws AuthMatchSystemException;

  public boolean putCache(String cacheName, Object key, Object value)
      throws AuthMatchSystemException;

  public boolean removeCacheData(String cacheName, ICacheBean cacheBean)
      throws AuthMatchSystemException;

  public boolean removeCacheData(String cacheName, ICacheKey key) throws AuthMatchSystemException;

  public int getCacheCount(String cacheName) throws AuthMatchSystemException;

  public int updateCache(String cacheName, String command) throws AuthMatchSystemException;

  public List<List<?>> getCacheData(String cacheName, ICacheBean cacheBean, String command)
      throws AuthMatchSystemException;

  public List<List<?>> getCacheData(String cacheName, String command)
      throws AuthMatchSystemException;

  boolean removeCacheData(String cacheName, String cachekey) throws AuthMatchSystemException;

  boolean checkCache(BinaryObject cacheKey, String cacheName) throws AuthMatchSystemException;

  BinaryObject getCache(String cacheName, BinaryObject key) throws AuthMatchSystemException;

  boolean putCache(String cacheName, BinaryObject key, BinaryObject value)
      throws AuthMatchSystemException;

  BinaryObject getCache(String cacheName, String key) throws AuthMatchSystemException;
}
