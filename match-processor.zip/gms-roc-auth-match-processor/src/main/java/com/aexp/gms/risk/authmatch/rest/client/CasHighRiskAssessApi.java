package com.aexp.gms.risk.authmatch.rest.client;

import com.aexp.gms.risk.authmatch.model.HighRiskAssesmentRequest;
import com.aexp.gms.risk.authmatch.model.HighRiskAssesmentResponse;
import com.aexp.gms.risk.authmatch.util.AuthMatchUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.security.SecureRandom;
import java.util.UUID;
import javax.annotation.PostConstruct;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.DefaultResponseErrorHandler;
import org.springframework.web.client.RestTemplate;

public class CasHighRiskAssessApi {

  @Value("${cas.highrisk.asses.api.url}")
  private String url;

  @Value("${cas.highrisk.asses.api.timeout.connect}")
  int connectTimeout;

  @Value("${cas.highrisk.asses.api.timeout.socket}")
  int socketTimeout;

  @Value("${cas.highrisk.asses.api.retry.count}")
  int retryCount;

  @Value("${cas.highrisk.asses.api.retry.backoff.ms}")
  int backoffMs;

  @Value("${cas.highrisk.asses.api.retry.wait.cap}")
  int waitCapMs;

  private ClientHttpRequestFactory clientHttpRequestFactory;
  private DefaultResponseErrorHandler errorHandler;
  private final BackoffJitter backoffJitter;
  private RestTemplate restTemplate;

  private java.security.SecureRandom secureRandom;
  private final Logger log = LoggerFactory.getLogger(CasHighRiskAssessApi.class);

  private final int RANDOM_HEADER_SIZE = 16;
  private final String API_CONSUMER_NAME = "41140955_RAM";
  private final String API_REQUEST_TYPE = "submissions";

  public CasHighRiskAssessApi(
      RiskRestClientErrorHandler errorHandler,
      BackoffJitter backoffJitter,
      ClientHttpRequestFactory clientHttpRequestFactory) {
    this.errorHandler = errorHandler;
    this.backoffJitter = backoffJitter;

    this.clientHttpRequestFactory = clientHttpRequestFactory;
    this.restTemplate = new RestTemplate(clientHttpRequestFactory);
    this.restTemplate.setErrorHandler(errorHandler);
  }

  public CasHighRiskAssessApi(
      RiskRestClientErrorHandler errorHandler, BackoffJitter backoffJitter) {
    this.errorHandler = errorHandler;
    this.backoffJitter = backoffJitter;
  }

  @PostConstruct
  public void init() {
    log.info("cas risk assessment api url = {}", url);
    log.info("connectTimeout = {}", connectTimeout);
    log.info("socketTimeout = {}", socketTimeout);
    log.info("backoffMs = {}", backoffMs);
    log.info("waitCapMs = {}", waitCapMs);

    this.clientHttpRequestFactory = getClientHttpRequestFactory(connectTimeout, socketTimeout);

    this.restTemplate = new RestTemplate(clientHttpRequestFactory);
    this.restTemplate.setErrorHandler(errorHandler);
    secureRandom = new SecureRandom();
  }

  private static ClientHttpRequestFactory getClientHttpRequestFactory(
      int connectTimeout, int socketTimeout) {
    RequestConfig config =
        RequestConfig.custom()
            .setConnectTimeout(connectTimeout)
            .setConnectionRequestTimeout(connectTimeout)
            .setSocketTimeout(socketTimeout)
            .build();
    CloseableHttpClient client =
        HttpClientBuilder.create()
            .setSSLHostnameVerifier(new NoopHostnameVerifier())
            .setDefaultRequestConfig(config)
            .setMaxConnTotal(200)
            .setMaxConnPerRoute(50)
            .build();
    return new HttpComponentsClientHttpRequestFactory(client);
  }

  public HighRiskAssesmentResponse callApi(HighRiskAssesmentRequest request) {
    int numOfTries = 0;
    ResponseEntity<HighRiskAssesmentResponse> responseEntity;
    do {
      backoffJitter.backoffJitter(numOfTries, backoffMs, waitCapMs);
      responseEntity = performCall(request);
      numOfTries += 1;
    } while (numOfTries < retryCount
        && !HttpStatus.OK.equals(responseEntity.getStatusCode())
        && !HttpStatus.BAD_REQUEST.equals(responseEntity.getStatusCode()));

    return (HttpStatus.OK.equals(responseEntity.getStatusCode()))
        ? responseEntity.getBody()
        : new HighRiskAssesmentResponse();
  }

  // Generate a random byte array for cryptographic use.
  private byte[] generateRandomBytes(final int size) {
    final byte[] key = new byte[size];
    secureRandom.nextBytes(key);
    return key;
  }

  private ResponseEntity<HighRiskAssesmentResponse> performCall(HighRiskAssesmentRequest request) {

    ResponseEntity<HighRiskAssesmentResponse> response =
        new ResponseEntity<>(HttpStatus.NOT_MODIFIED);
    try {

      String randomBytes = UUID.randomUUID().toString();
      request.getRisk_assessment().setRequest_unique_id(randomBytes);
      request.getRisk_assessment().setRequest_type(API_REQUEST_TYPE);
      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_JSON);
      headers.set("x-amex-request-unique-id", randomBytes);
      headers.set("x-amex-api-consumer", API_CONSUMER_NAME);

      org.springframework.http.HttpEntity<HighRiskAssesmentRequest> requestHttpEntity =
          new HttpEntity<>(request, headers);

      ObjectMapper mapper = new ObjectMapper();
      log.info("calling CAS API with request");
      response =
          restTemplate.exchange(
              url, HttpMethod.POST, requestHttpEntity, HighRiskAssesmentResponse.class);
      if (response != null && response.getStatusCode().equals(HttpStatus.OK)) {
        HighRiskAssesmentResponse riskAssesmentResponse = response.getBody();

        log.info(
            "Response Received from CAS for Card -{}, SE -{}, Amount -{}, Response Code -{}, Response Message -{}",
            AuthMatchUtil.getMaskedCMNumber(
                request.getRisk_assessment().getPrimary_account_number()),
            request.getRisk_assessment().getMerchant_number(),
            request.getRisk_assessment().getRequested_amount(),
            riskAssesmentResponse.getRisk_assessment().getResponse_code(),
            riskAssesmentResponse.getRisk_assessment().getResponse_message());
      } else {
        log.error("Error Response Status Code received from CAS {}", response.getStatusCode());
        log.error(
            "Error Response Body received from CAS {}",
            mapper.writeValueAsString(response.getBody()));
      }

      return response;
    } catch (Exception e) {

      log.error("cas api call failed ", e);
    }

    return response;
  }
}
