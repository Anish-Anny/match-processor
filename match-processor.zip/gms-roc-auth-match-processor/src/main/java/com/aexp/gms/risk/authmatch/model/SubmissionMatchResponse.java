package com.aexp.gms.risk.authmatch.model;

import com.aexp.gmnt.imc.compute.global.IProgramData;
import com.fasterxml.jackson.annotation.JsonFilter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.sql.Timestamp;
import java.util.ArrayList;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Builder
@Getter
@Setter
@AllArgsConstructor
@RequiredArgsConstructor
@EqualsAndHashCode
@ToString
@XmlRootElement(name = "submissionMatchResponse")
@XmlType(propOrder = {"responseMetaData", "matchStatus"})
@XmlAccessorType(XmlAccessType.FIELD)
@JsonFilter("SubmissionMatchResponseFilter")
public class SubmissionMatchResponse implements IProgramData {

  private ResponseMetaData responseMetaData;
  private String ramIndicator;
  private String ramTier;
  private String resultRemarks;
  private String rocAcquirerReferenceNumber;
  private String processDate;
  private String matchTimeStamp;
  private String rocCardNumber;
  private String rocSENumber;
  private String rocAuthDAC;

  @JsonIgnore private String authUniqueIdentifer;
  @JsonIgnore private boolean matched;
  @JsonIgnore private String cacheKey;
  @JsonIgnore private String cacheName;
  @JsonIgnore private String tidCardKey;
  @JsonIgnore private String dac6CardKey;
  @JsonIgnore private String dac2CardKey;
  @JsonIgnore private ArrayList<String> tidCardKeysList;
  @JsonIgnore private ArrayList<String> dac6CardKeysList;
  @JsonIgnore private ArrayList<String> dac2CardKeysList;
  @JsonIgnore private String authSeNumber;
  @JsonIgnore private boolean doNotDeleteFlag;
  @JsonIgnore private boolean matchedMultipleRocToAuth;
  @JsonIgnore private String authDate;
  @JsonIgnore private String authTime;

  @JsonIgnore private boolean riskAssessmentThreshold;

  @JsonProperty("caspKey")
  private String caspKey;

  @JsonProperty("posDataCode")
  private String posDataCode;

  @JsonProperty("eciIndicator")
  private String eciIndicator;

  @JsonProperty("approvalCode")
  private String approvalCode;

  @JsonProperty("mcc")
  private String mcc;

  @JsonProperty("voiceAuthIndicator")
  private String voiceAuthIndicator;

  @JsonProperty("rejIndicator")
  private String rejIndicator;

  @JsonProperty("highRiskCardResponse")
  private String highRiskCardResponse;

  @JsonProperty("transactionId")
  private String transactionId;

  @JsonProperty("ecbCreationTime")
  private String ecbCreationTime;

  @JsonIgnore private boolean reversed;

  @JsonProperty("reversalTimeStamp")
  private Timestamp reversalTimeStamp;

  @JsonProperty("originalMccCode")
  private String originalMccCode;

  @JsonProperty("seCountryCode")
  private String seCountryCode;

  @JsonProperty("seIndustryCategoryCode")
  private String seIndustryCategoryCode;

  @JsonProperty("authAmountUsd")
  private String authAmountUsd;

  @JsonProperty("authAmountLocal")
  private String authAmountLocal;

  @JsonProperty("authAmountCurrencyCode")
  private String authAmountCurrencyCode;

  @JsonProperty("foreignSpendIndicator")
  private String foreignSpendIndicator;

  @JsonProperty("auth2Dac")
  private String auth2Dac;

  @JsonProperty("auth6Dac")
  private String auth6Dac;

  @JsonProperty("magneticStripeCode")
  private String magneticStripeCode;

  @JsonProperty("fraudLossProbability")
  private Float fraudLossProbability;

  @JsonProperty("seTypeCode")
  private String seTypeCode;

  @JsonProperty("dpan")
  private String dpan;

  @JsonIgnore private boolean isFromPrevMatch;
}
