package com.aexp.gms.risk.authmatch.model;

import com.aexp.gms.risk.authmatch.util.AuthMatchConstants;
import java.math.BigDecimal;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Builder
@Getter
@Setter
@AllArgsConstructor
@RequiredArgsConstructor
public class CasAuthTransIdCardCacheBean {

  /** */
  //	private static final long serialVersionUID = 655814863422556823L;

  private String transactionId;

  private String cardNumber;

  private String approveDenyCode;

  private BigDecimal authAmountUSD;

  private String rocAuthMatchedFlag; // Y -> Matched, N -> Not matched

  private String rocAuthMatchedCriteriaId; // 1 - Matched by TID

  private String persistedFlag; // Y -> Cassandra updated

  private String cardDac6PrimaryKey;

  private String cardDac2PrimaryKey;

  private String authUniqueIdentifier;

  private String seNumber;

  private Date authTransactionDateTime;

  private BigDecimal matchedAmountUSD;

  private String sourceIdentifier;

  private BigDecimal authAmountLocal;

  private String voiceAuthIndicator;

  private String posDataCode;

  private String eciIndicator;

  private String mccMerchant;

  private String creditDeniedcode;

  private String fraudDeniedCode;

  private Date transactionTimeStamp;

  public String getTableName() {
    return "CasAuthTransIdCardCacheBean2";
  }

  public String getCacheName() {
    return AuthMatchConstants.CAS_AUTH_TID_CM_CACHE;
  }

  @Override
  public String toString() {
    return "CasAuthTransIdCardCacheBean [transactionId="
        + transactionId
        + ", cardNumber="
        + cardNumber
        + ", approveDenyCode="
        + approveDenyCode
        + ", authAmountUSD="
        + authAmountUSD
        + ", rocAuthMatchedFlag="
        + rocAuthMatchedFlag
        + ", rocAuthMatchedCriteriaId="
        + rocAuthMatchedCriteriaId
        + ", persistedFlag="
        + persistedFlag
        + ", cardDac6PrimaryKey="
        + cardDac6PrimaryKey
        + ", cardDac2PrimaryKey="
        + cardDac2PrimaryKey
        + ", authUniqueIdentifier="
        + authUniqueIdentifier
        + ", seNumber="
        + seNumber
        + ", authTransactionDateTime="
        + authTransactionDateTime
        + ", matchedAmountUSD="
        + matchedAmountUSD
        + ", sourceIdentifier="
        + sourceIdentifier
        + "] version 2.6.0";
  }

  public String getCacheStringKey() {
    return this.transactionId + "|" + this.cardNumber + "|" + this.getApproveDenyCode();
  }
}
