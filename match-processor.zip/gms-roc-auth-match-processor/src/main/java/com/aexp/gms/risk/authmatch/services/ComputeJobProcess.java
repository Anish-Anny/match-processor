package com.aexp.gms.risk.authmatch.services;

import com.aexp.gmnt.imc.compute.global.IMCProcessException;
import com.aexp.gmnt.imc.compute.global.IProgramData;
import com.aexp.gms.imc.metadata.vo.RiskThresholdValue;
import com.aexp.gms.risk.authmatch.dao.*;
import com.aexp.gms.risk.authmatch.model.CasAuthCardAccessCode2CacheBean;
import com.aexp.gms.risk.authmatch.model.CasAuthCardAccessCode6CacheBean;
import com.aexp.gms.risk.authmatch.model.CasAuthTransIdCardCacheBean;
import com.aexp.gms.risk.authmatch.model.RocMatchRequest;
import com.aexp.gms.risk.authmatch.model.SubmissionMatchResponse;
import com.aexp.gms.risk.authmatch.model.ignite.key.RocAuthSEHistoryKey;
import com.aexp.gms.risk.authmatch.util.AuthMatchConstants;
import com.aexp.gms.risk.authmatch.util.AuthMatchLog;
import com.aexp.gms.risk.authmatch.util.AuthMatchUtil;
import com.aexp.gms.risk.authmatch.util.ITier;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteLogger;
import org.apache.ignite.Ignition;
import org.apache.ignite.binary.BinaryObject;
import org.apache.ignite.resources.LoggerResource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

public class ComputeJobProcess {

  private AuthMatchLog authMatchLog =
      new AuthMatchLog(ComputeJobProcess.class.getPackage().getName());
  private final Logger LOGGER = LoggerFactory.getLogger(ComputeJobProcess.class);
  @LoggerResource private transient IgniteLogger log;
  private static final String CLASS_NAME = "ComputeJobProcess";
  boolean igniteStarted;

  // @Autowired
  AuthMatchDAOImpl authMatchDAOImpl = new AuthMatchDAOImpl();
  SeChar501Dao seChar501Ignite = new SeChar501IgniteImpl();
  RocAuthSEHistoryDao rocAuthSeHistoryIgnite = new RocAuthSeHistoryIgniteImpl();
  RiskAssessmentThresholdDao riskAssessmentThresholdDao = new RiskAssessmentThresholdIgniteImpl();

  DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
  private Ignite ignite;
  IgniteProvider igniteProvider = new IgniteProvider(false);

  @LoggerResource
  public void setLog(IgniteLogger log) {
    if (log == null)
      LOGGER.error(
          "{}|Logger can't be null {} ",
          authMatchLog.getCommonLogAttributes("S", "GR5003"),
          new IllegalStateException());
    this.log = log;
  }

  /**
   * This is invoked from IgniteCompute class. This should have all business computations to be
   * performed on Ignite. This will need an instance to ignite which can be injected here or passed
   * as parameter from IgniteCompute.
   *
   * @param programDataInput
   * @param ignite
   * @return
   * @throws Exception
   */
  public SubmissionMatchResponse process(IProgramData programDataInput) throws Exception {
    RocMatchRequest input = (RocMatchRequest) programDataInput;
    igniteProvider.setIgnite(Ignition.ignite());
    authMatchDAOImpl.setCacheProvider(igniteProvider);
    riskAssessmentThresholdDao.setIgniteProvider(igniteProvider);
    seChar501Ignite.setIgniteProvider(igniteProvider);
    rocAuthSeHistoryIgnite.setIgniteProvider(igniteProvider);
    List<String> eligibleTiersList = input.getEligibleTiersList();

    this.ignite = Ignition.ignite();
    SubmissionMatchResponse response = new SubmissionMatchResponse();

    try {
      // Matches tier 2, 3a, and 3c
      if (AuthMatchUtil.isEligibleTierListContainsTier(
          eligibleTiersList,
          AuthMatchUtil.MatchTiers.TIER_2.getValue(),
          AuthMatchUtil.MatchTiers.TIER_3.getValue()))
        response = matchByApprovedTIDAndAmount(input, response);
      // // Matches tier 1
      if (!response.isMatched()
          && AuthMatchUtil.isEligibleTierListContainsTier(
              eligibleTiersList, AuthMatchUtil.MatchTiers.TIER_1.getValue()))
        response = matchByRejectedTID(input, response);
      if (!response.isMatched()
          && AuthMatchUtil.isEligibleTierListContainsTier(
              eligibleTiersList,
              AuthMatchUtil.MatchTiers.TIER_4.getValue(),
              AuthMatchUtil.MatchTiers.TIER_5.getValue()))
        // Matches tiers 4 and 5
        response = matchByCardDac6AndAmoutLeverageSEDate(input, response);
      if (!response.isMatched()
          && AuthMatchUtil.isEligibleTierListContainsTier(
              eligibleTiersList,
              AuthMatchUtil.MatchTiers.TIER_6.getValue(),
              AuthMatchUtil.MatchTiers.TIER_7.getValue()))
        response = matchByCardSEDac2AndAmoutLeverage(input, response);
      if (!response.isMatched()
          && AuthMatchUtil.isEligibleTierListContainsTier(
              eligibleTiersList, AuthMatchUtil.MatchTiers.TIER_8.getValue()))
        response = matchByTier8(input, response);
      if (!response.isMatched()
          && AuthMatchUtil.isEligibleTierListContainsTier(
              eligibleTiersList, AuthMatchUtil.MatchTiers.TIER_9.getValue()))
        response = matchByTier9(input, response);
      if (!response.isMatched()
          && AuthMatchUtil.isEligibleTierListContainsTier(
              eligibleTiersList, AuthMatchUtil.MatchTiers.TIER_11.getValue()))
        response = matchByCardNumberAndSeNumber(input, response);

      if (!response.isMatched()) {

        LOGGER.debug(
            "GR1201 - No match found in Ignite cache : {}, ARN : {} ",
            input.getRocAuthorizationTransactionId(),
            input.getRocAcquirerReferenceNumber(),
            ITier.REQUESTHANDLER,
            CLASS_NAME,
            CLASS_NAME);
        RiskThresholdValue riskThresholdValue = riskAssessmentThresholdDao.getThresholdValue();
        BigDecimal riskAssessmentAmountThreshold =
            riskThresholdValue != null
                ? riskThresholdValue.getRiskAssessmentThresholdAmount()
                : new BigDecimal("0.00");

        response.setRiskAssessmentThreshold(
            (new BigDecimal(input.getRocAmountUSD())).compareTo(riskAssessmentAmountThreshold) > 0
                && !riskAssessmentThresholdDao.isThresholdReached());

        LOGGER.debug(
            "GR1210- Risk Assessment Threshold {} ",
            response.isRiskAssessmentThreshold(),
            ITier.REQUESTHANDLER,
            CLASS_NAME,
            CLASS_NAME);

        response.setRamIndicator("0");
        response.setRamTier("T00");
        response.setResultRemarks(
            "1 -> Match by TID not found, "
                + "2 -> Match by card-SE-DAC6-amount leverage not found, "
                + "3 -> Match by card,SE and DAC6 not found, "
                + "4 -> Match by card and DAC6 not found, "
                + "5 -> Match by card-SE-DAC2-amount leverage not found, "
                + "6 -> Match by card,SE and DAC2 not found, "
                + "7 -> Match by card and DAC2 not found, "
                + "");
        LOGGER.debug(
            "GR1201 - No match found in Ignite cache : {}, ARN : {} ",
            input.getRocAuthorizationTransactionId(),
            input.getRocAcquirerReferenceNumber(),
            ITier.REQUESTHANDLER,
            CLASS_NAME,
            CLASS_NAME);
      }
      // ADDITIONAL PROCESSING TO ACCUMULATE SE UNMATCHED AMOUNT

      // UPDATE CASSANDRA TABLE

    } catch (Exception e) {

      LOGGER.error(
          "{}|compute process {} , {}",
          authMatchLog.getCommonLogAttributes("S", "GR5003"),
          e.getMessage(),
          e);
      if (log == null)
        LOGGER.error(
            "{}|IgniteLogger is not injected or null ",
            authMatchLog.getCommonLogAttributes("S", "GR5003"));
      else
        LOGGER.error(
            "{}|compute process {} , {}",
            authMatchLog.getCommonLogAttributes("S", "GR5003"),
            e.getMessage(),
            e);
      throw new IMCProcessException(e);
    }
    return response;
  }

  public SubmissionMatchResponse matchByRejectedTID(
      RocMatchRequest rocMatchRequest, SubmissionMatchResponse submissionMatchResponse) {
    boolean rocMatched = false;

    try {
      CasAuthTransIdCardCacheBean transCardBean = null;
      if (igniteProvider.checkCache(
          authMatchDAOImpl.getTransCardBinaryKey(
              rocMatchRequest.getRocAuthorizationTransactionId(),
              rocMatchRequest.getRocCardNumber(),
              "D"),
          AuthMatchConstants.CAS_AUTH_TID_CM_CACHE)) {
        rocMatched = true;

        transCardBean =
            authMatchDAOImpl.getTransCardBean(
                AuthMatchConstants.CAS_AUTH_TID_CM_CACHE,
                authMatchDAOImpl.getTransCardBinaryKey(
                    rocMatchRequest.getRocAuthorizationTransactionId(),
                    rocMatchRequest.getRocCardNumber(),
                    "D"));
        transCardBean.setRocAuthMatchedCriteriaId("T01");
        transCardBean.setRocAuthMatchedFlag("Y");
        igniteProvider.putCache(
            AuthMatchConstants.CAS_AUTH_TID_CM_CACHE,
            authMatchDAOImpl.getTransCardBinaryKey(
                rocMatchRequest.getRocAuthorizationTransactionId(),
                rocMatchRequest.getRocCardNumber(),
                "D"),
            authMatchDAOImpl.getTransCardBinaryBean(transCardBean));

        String[] approvalCode = transCardBean.getCardDac6PrimaryKey().split("\\|", 5);

        submissionMatchResponse.setCaspKey(transCardBean.getAuthUniqueIdentifier());
        submissionMatchResponse.setAuthUniqueIdentifer(transCardBean.getAuthUniqueIdentifier());
        submissionMatchResponse.setPosDataCode(transCardBean.getPosDataCode());
        submissionMatchResponse.setEciIndicator(transCardBean.getEciIndicator());
        submissionMatchResponse.setApprovalCode(approvalCode[1]);
        submissionMatchResponse.setMcc(transCardBean.getMccMerchant());
        submissionMatchResponse.setVoiceAuthIndicator(transCardBean.getVoiceAuthIndicator());
        submissionMatchResponse.setRejIndicator("");
        submissionMatchResponse.setAuthSeNumber(transCardBean.getSeNumber());
        submissionMatchResponse.setRamIndicator("2");
        submissionMatchResponse.setRamTier("T01");
        submissionMatchResponse.setTransactionId(transCardBean.getTransactionId());
        submissionMatchResponse.setResultRemarks("1 -> Match by Rejected TID found in Cache");
        //				String cacheKey = transCardBinaryBean.field("transactionId") + "|" +
        // transCardBinaryBean.field("cardNumber") + "|"
        // +transCardBinaryBean.field("approveDenyCode");
        submissionMatchResponse.setCacheKey(transCardBean.getCacheStringKey());
        submissionMatchResponse.setCacheName(AuthMatchConstants.CAS_AUTH_TID_CM_CACHE);
        submissionMatchResponse.setTidCardKey(transCardBean.getCacheStringKey());
        submissionMatchResponse.setDac6CardKey(transCardBean.getCardDac6PrimaryKey());
        submissionMatchResponse.setDac2CardKey(transCardBean.getCardDac2PrimaryKey());
        submissionMatchResponse.setEcbCreationTime(
            transCardBean.getTransactionTimeStamp() != null
                ? AuthMatchUtil.getStringFromDate(
                    transCardBean.getTransactionTimeStamp(), AuthMatchUtil.MX_AUTH_DATE_TIME_FORMAT)
                : "");
        submissionMatchResponse.setRocAuthDAC(rocMatchRequest.getRocAuthDAC());
        submissionMatchResponse.setRocCardNumber(rocMatchRequest.getRocCardNumber());
        submissionMatchResponse.setRocSENumber(rocMatchRequest.getRocSENumber());
      }

    } catch (Exception e) {
      LOGGER.error(
          "{}| Error in Match by Rejected TID",
          authMatchLog.getCommonLogAttributes("S", "GE000M06", rocMatchRequest),
          ITier.REQUESTHANDLER,
          CLASS_NAME,
          CLASS_NAME);
      rocMatched = false;
      StringWriter outError = new StringWriter();
      e.printStackTrace(new PrintWriter(outError));
      String errorString = outError.toString();
      LOGGER.error("{} ERRor during Match by Rejected TID ", errorString);
    }
    submissionMatchResponse.setMatched(rocMatched);
    return submissionMatchResponse;
  }

  public SubmissionMatchResponse matchByApprovedTIDAndAmount(
      RocMatchRequest rocMatchRequest, SubmissionMatchResponse submissionMatchResponse) {
    boolean rocMatched = false;
    BigDecimal lowerMultiplier = BigDecimal.valueOf(0L);
    BigDecimal higherMultiplier = BigDecimal.valueOf(0L);
    BigDecimal rocLocalAmount = null;
    BigDecimal rocAmount = null;
    BigDecimal authAmount = null;
    String approvalCode = "";
    boolean isLocalAmount = false;

    try {
      if (rocMatchRequest.getRocLocalAmount() != null
          && rocMatchRequest.getRocLocalDecimalPlaces() != null) {
        Double localDecimalPlaces = Double.valueOf(rocMatchRequest.getRocLocalDecimalPlaces());
        Double localamount =
            (Double.valueOf(rocMatchRequest.getRocLocalAmount())
                / (((int) Math.pow(10, localDecimalPlaces))));
        if (org.apache.commons.lang.StringUtils.isNotEmpty(
            rocMatchRequest.getRocLocalDecimalPlaces())) {
          rocLocalAmount = new BigDecimal(localamount.toString());
        } else {
          rocLocalAmount = new BigDecimal(localamount).setScale(2, RoundingMode.FLOOR);
        }
      }
    } catch (Exception e) {
    }
    try {
      CasAuthTransIdCardCacheBean transCardBean =
          authMatchDAOImpl.getTransCardBean(
              AuthMatchConstants.CAS_AUTH_TID_CM_CACHE,
              authMatchDAOImpl.getTransCardBinaryKey(
                  rocMatchRequest.getRocAuthorizationTransactionId(),
                  rocMatchRequest.getRocCardNumber(),
                  "A"));
      if (transCardBean != null) {
        String[] dac6Key = transCardBean.getCardDac6PrimaryKey().split("\\|", 5);
        if (dac6Key.length > 0) approvalCode = dac6Key[1];
        if (rocLocalAmount != null && transCardBean.getAuthAmountLocal() != null) {
          rocAmount = rocLocalAmount;
          authAmount = transCardBean.getAuthAmountLocal();
          isLocalAmount = true;
        } else {
          rocAmount = new BigDecimal(rocMatchRequest.getRocAmountUSD());
          authAmount = transCardBean.getAuthAmountUSD();
        }
      }
      // Match with Tier 2 logic
      if (transCardBean != null
          && authAmount != null
          && rocAmount != null
          && authAmount.compareTo(rocAmount) == 0) {
        rocMatched = true;
        transCardBean.setRocAuthMatchedCriteriaId("T02");
        transCardBean.setRocAuthMatchedFlag("Y");
        submissionMatchResponse.setRamIndicator("1");
        submissionMatchResponse.setRamTier("T02");
        submissionMatchResponse.setTransactionId(transCardBean.getTransactionId());
        submissionMatchResponse.setResultRemarks(
            "2 -> Match by Approved TID and Amount found in Cache"
                + (isLocalAmount ? " with Local amount" : ""));
        submissionMatchResponse.setEcbCreationTime(
            transCardBean.getTransactionTimeStamp() != null
                ? AuthMatchUtil.getStringFromDate(
                    transCardBean.getTransactionTimeStamp(), AuthMatchUtil.MX_AUTH_DATE_TIME_FORMAT)
                : "");
      }

      // Match with Tier 3a logic
      // Match Single Auth Amount with Rocs difference
      BigDecimal diffAmount = null;
      if (authAmount != null) diffAmount = authAmount.subtract(rocAmount);
      if (!rocMatched
          && transCardBean != null
          && authAmount != null
          && rocAmount != null
          && diffAmount != null
          && (diffAmount.compareTo(new BigDecimal("1.00")) > 0)) {
        BigDecimal matchAmount = transCardBean.getMatchedAmountUSD();

        if (matchAmount == null) {
          matchAmount = new BigDecimal("0.00");
        } else {
          submissionMatchResponse.setMatchedMultipleRocToAuth(true);
        }

        matchAmount = matchAmount.add(rocAmount);
        transCardBean.setMatchedAmountUSD(matchAmount);

        if (authAmount.compareTo(matchAmount) != 0) {
          submissionMatchResponse.setDoNotDeleteFlag(true);
        }
        rocMatched = true;
        transCardBean.setRocAuthMatchedCriteriaId("T03");
        transCardBean.setRocAuthMatchedFlag("Y");
        submissionMatchResponse.setRamIndicator("1");
        submissionMatchResponse.setRamTier("T03");
        submissionMatchResponse.setTransactionId(transCardBean.getTransactionId());
        submissionMatchResponse.setResultRemarks(
            "3a -> Match by Approved TID and Amount found in Cache"
                + (isLocalAmount ? " with Local amount" : ""));
      }

      // Match with Tier 3b is not possible as it needs another table in Cassandra to lookup data by
      // Card and SE
      submissionMatchResponse = matchByTier3b(rocMatchRequest, submissionMatchResponse);
      if (submissionMatchResponse.getRamIndicator() != null
          && submissionMatchResponse.getRamIndicator().equals("1")) rocMatched = true;

      BinaryObject industryLeverageBinaryBean =
          (BinaryObject)
              igniteProvider.getCache(
                  AuthMatchConstants.SE_SE_INDUSTRY_LEVERAGE_CACHE,
                  rocMatchRequest.getSocSEIndustryCategoryCode());
      if (industryLeverageBinaryBean == null) {
        industryLeverageBinaryBean =
            (BinaryObject)
                igniteProvider.getCache(AuthMatchConstants.SE_SE_INDUSTRY_LEVERAGE_CACHE, "Others");
      }
      if (industryLeverageBinaryBean != null) {
        lowerMultiplier = industryLeverageBinaryBean.field("lowerMultiplier");
        higherMultiplier = industryLeverageBinaryBean.field("higherMultiplier");
      } else LOGGER.error("GR50010 - Industry Leverage cache does not exist or not created ");

      // Match with Tier 3c logic
      if (!rocMatched && transCardBean != null && authAmount != null && rocAmount != null) {

        // Compare Auth amount with lower and high multiplier by SE Industry leverage code
        if (authAmount.compareTo(rocAmount.multiply(lowerMultiplier)) >= 0
            && authAmount.compareTo(rocAmount.multiply(higherMultiplier)) <= 0) {
          rocMatched = true;
          submissionMatchResponse.setTransactionId(transCardBean.getTransactionId());
          submissionMatchResponse.setResultRemarks(
              "3c.1 -> Match by CM and industry leverage found in Cache"
                  + (isLocalAmount ? " with Local amount" : ""));
        }

        // If above criteria not matched, then check if Roc Amount - Auth Amount < 100
        BigDecimal amountDifference = rocAmount.subtract(authAmount);
        if (!rocMatched && (amountDifference.compareTo(new BigDecimal(100)) <= 0)) {
          rocMatched = true;
          submissionMatchResponse.setTransactionId(transCardBean.getTransactionId());
          submissionMatchResponse.setResultRemarks(
              "3c.2 -> Match by CM and ROC Amount - CAS Amount <= 100 found in Cache"
                  + (isLocalAmount ? " with Local amount" : ""));
        }

        // If 3c.1 or 3c.2 matched
        if (rocMatched) {
          transCardBean.setRocAuthMatchedCriteriaId("T03");
          transCardBean.setRocAuthMatchedFlag("Y");

          submissionMatchResponse.setRamIndicator("1");
          submissionMatchResponse.setRamTier("T03");
        }
      }

      // If any of criteria matched, then update cache as matched and set response with common
      // attributes
      if (rocMatched) {
        igniteProvider.putCache(
            AuthMatchConstants.CAS_AUTH_TID_CM_CACHE,
            authMatchDAOImpl.getTransCardBinaryKey(
                rocMatchRequest.getRocAuthorizationTransactionId(),
                rocMatchRequest.getRocCardNumber(),
                "A"),
            authMatchDAOImpl.getTransCardBinaryBean(transCardBean));
        submissionMatchResponse.setCaspKey(transCardBean.getAuthUniqueIdentifier());
        submissionMatchResponse.setAuthUniqueIdentifer(transCardBean.getAuthUniqueIdentifier());
        submissionMatchResponse.setCacheKey(transCardBean.getCacheStringKey());
        submissionMatchResponse.setCacheName(AuthMatchConstants.CAS_AUTH_TID_CM_CACHE);
        submissionMatchResponse.setTidCardKey(transCardBean.getCacheStringKey());
        submissionMatchResponse.setDac6CardKey(transCardBean.getCardDac6PrimaryKey());
        submissionMatchResponse.setDac2CardKey(transCardBean.getCardDac2PrimaryKey());
        submissionMatchResponse.setAuthSeNumber(transCardBean.getSeNumber());
        submissionMatchResponse.setPosDataCode(transCardBean.getPosDataCode());
        submissionMatchResponse.setEciIndicator(transCardBean.getEciIndicator());
        submissionMatchResponse.setApprovalCode(approvalCode);
        submissionMatchResponse.setMcc(transCardBean.getMccMerchant());
        submissionMatchResponse.setVoiceAuthIndicator(transCardBean.getVoiceAuthIndicator());
        submissionMatchResponse.setRejIndicator("");
        submissionMatchResponse.setEcbCreationTime(
            transCardBean.getTransactionTimeStamp() != null
                ? AuthMatchUtil.getStringFromDate(
                    transCardBean.getTransactionTimeStamp(), AuthMatchUtil.MX_AUTH_DATE_TIME_FORMAT)
                : "");
        submissionMatchResponse.setRocAuthDAC(rocMatchRequest.getRocAuthDAC());
        submissionMatchResponse.setRocCardNumber(rocMatchRequest.getRocCardNumber());
        submissionMatchResponse.setRocSENumber(rocMatchRequest.getRocSENumber());
      }
    } catch (Exception e) {
      LOGGER.error(
          "{}| Error in Match by Approved TID and Amount",
          authMatchLog.getCommonLogAttributes("S", "GE000M04", rocMatchRequest),
          ITier.REQUESTHANDLER,
          CLASS_NAME,
          CLASS_NAME);
      rocMatched = false;
      StringWriter outError = new StringWriter();
      e.printStackTrace(new PrintWriter(outError));
      String errorString = outError.toString();
      LOGGER.error("{} ERRor during Match by Approved TID and Amount", errorString);
      rocMatched = false;
    }
    submissionMatchResponse.setMatched(rocMatched);
    return submissionMatchResponse;
  }

  public SubmissionMatchResponse matchByTier3b(
      RocMatchRequest rocMatchRequest, SubmissionMatchResponse submissionMatchResponse) {
    boolean rocMatched = false;
    BigDecimal rocLocalAmount = null;
    BigDecimal rocAmount = null;
    BigDecimal authAmount = null;
    String approvalCode = "";
    boolean isLocalAmount = false;

    try {
      if (rocMatchRequest.getRocLocalAmount() != null
          && rocMatchRequest.getRocLocalDecimalPlaces() != null) {
        Double localDecimalPlaces = Double.valueOf(rocMatchRequest.getRocLocalDecimalPlaces());
        Double localamount =
            (Double.valueOf(rocMatchRequest.getRocLocalAmount())
                / (((int) Math.pow(10, localDecimalPlaces))));
        if (org.apache.commons.lang.StringUtils.isNotEmpty(
            rocMatchRequest.getRocLocalDecimalPlaces())) {
          rocLocalAmount = new BigDecimal(localamount.toString());
        } else {
          rocLocalAmount = new BigDecimal(localamount).setScale(2, RoundingMode.FLOOR);
        }
      }
    } catch (Exception e) {
    }

    try {
      CasAuthTransIdCardCacheBean transCardBean =
          authMatchDAOImpl.getTransCardBean(
              AuthMatchConstants.CAS_AUTH_TID_CM_CACHE,
              authMatchDAOImpl.getTransCardBinaryKey(
                  rocMatchRequest.getRocAuthorizationTransactionId(),
                  rocMatchRequest.getRocCardNumber(),
                  "A"));
      if (transCardBean != null) {
        String[] dac6Key = transCardBean.getCardDac6PrimaryKey().split("\\|", 5);
        if (dac6Key.length > 0) approvalCode = dac6Key[1];
        if (rocLocalAmount != null && transCardBean.getAuthAmountLocal() != null) {
          rocAmount = rocLocalAmount;
          authAmount = transCardBean.getAuthAmountLocal();
          isLocalAmount = true;
        } else {
          rocAmount = new BigDecimal(rocMatchRequest.getRocAmountUSD());
          authAmount = transCardBean.getAuthAmountUSD();
        }
      }

      // Match with Tier 3b logic
      if (transCardBean != null && authAmount.compareTo(rocAmount) < 0) {
        BigDecimal difference = rocAmount.subtract(authAmount);

        LOGGER.debug(
            "GR3b01 - TID : {}, AuthAmount : {}, Difference : {} ",
            rocMatchRequest.getRocAuthorizationTransactionId(),
            authAmount,
            difference,
            ITier.REQUESTHANDLER,
            CLASS_NAME,
            CLASS_NAME);
        String sqlStatement =
            String.format(
                AuthMatchConstants.getCasAuthDataByCardSE,
                AuthMatchConstants.CACHE_TABLENAME,
                rocMatchRequest.getRocCardNumber(),
                rocMatchRequest.getRocSENumber(),
                rocMatchRequest.getRocTransactionDate(),
                rocMatchRequest.getRocAuthorizationTransactionId(),
                rocMatchRequest.getRocAmountUSD());

        List<List<?>> resultSet =
            igniteProvider.getCacheData(AuthMatchConstants.CAS_AUTH_TID_CM_CACHE, sqlStatement);

        if (resultSet != null && resultSet.size() == 1) {
          Object next = resultSet.get(0);
          BigDecimal authAmountUsd = (BigDecimal) ((ArrayList) next).get(0);
          String transId = (String) ((ArrayList) next).get(1);
          String dac6Key = (String) ((ArrayList) next).get(2);
          String dac2Key = (String) ((ArrayList) next).get(3);
          LOGGER.debug(
              "GR3b02 - TID : {}, Record count : {} ",
              rocMatchRequest.getRocAuthorizationTransactionId(),
              resultSet.size(),
              ITier.REQUESTHANDLER,
              CLASS_NAME,
              CLASS_NAME);
          String cacheKey1 =
              transId
                  + "|"
                  + transCardBean.getCardNumber()
                  + "|"
                  + transCardBean.getApproveDenyCode();
          if (difference.compareTo(authAmountUsd) == 0) {
            LOGGER.debug(
                "GR3b03 - Matched by tier T03 - TID : {}, ROC SE : {} ",
                rocMatchRequest.getRocAuthorizationTransactionId(),
                rocMatchRequest.getRocSENumber(),
                ITier.REQUESTHANDLER,
                CLASS_NAME,
                CLASS_NAME);
            // Match by 3b
            rocMatched = true;
            transCardBean.setRocAuthMatchedCriteriaId("T03");
            transCardBean.setRocAuthMatchedFlag("Y");
            igniteProvider.putCache(
                AuthMatchConstants.CAS_AUTH_TID_CM_CACHE,
                authMatchDAOImpl.getTransCardBinaryKey(
                    rocMatchRequest.getRocAuthorizationTransactionId(),
                    rocMatchRequest.getRocCardNumber(),
                    "A"),
                authMatchDAOImpl.getTransCardBinaryBean(transCardBean));

            submissionMatchResponse.setRamIndicator("1");
            submissionMatchResponse.setRamTier("T03");
            submissionMatchResponse.setTransactionId(transCardBean.getTransactionId());
            submissionMatchResponse.setResultRemarks(
                "3b -> Match by CM, SE and CAS Date found in Cache");
            submissionMatchResponse.setCaspKey(transCardBean.getAuthUniqueIdentifier());
            submissionMatchResponse.setAuthUniqueIdentifer(transCardBean.getAuthUniqueIdentifier());
            submissionMatchResponse.setCacheKey(transCardBean.getCacheStringKey());
            submissionMatchResponse.setCacheName(AuthMatchConstants.CAS_AUTH_TID_CM_CACHE);
            submissionMatchResponse.setTidCardKey(transCardBean.getCacheStringKey());
            submissionMatchResponse.setTidCardKeysList(
                new ArrayList<String>(Arrays.asList(cacheKey1)));
            submissionMatchResponse.setDac6CardKey(transCardBean.getCardDac6PrimaryKey());
            submissionMatchResponse.setDac6CardKeysList(
                new ArrayList<String>(Arrays.asList(dac6Key)));
            submissionMatchResponse.setDac2CardKey(transCardBean.getCardDac2PrimaryKey());
            submissionMatchResponse.setDac2CardKeysList(
                new ArrayList<String>(Arrays.asList(dac2Key)));
            submissionMatchResponse.setPosDataCode(transCardBean.getPosDataCode());
            submissionMatchResponse.setEciIndicator(transCardBean.getEciIndicator());
            submissionMatchResponse.setApprovalCode(approvalCode);
            submissionMatchResponse.setMcc(transCardBean.getMccMerchant());
            submissionMatchResponse.setVoiceAuthIndicator(transCardBean.getVoiceAuthIndicator());
            submissionMatchResponse.setRejIndicator("");
            submissionMatchResponse.setAuthSeNumber(transCardBean.getSeNumber());
            submissionMatchResponse.setEcbCreationTime(
                transCardBean.getTransactionTimeStamp() != null
                    ? AuthMatchUtil.getStringFromDate(
                        transCardBean.getTransactionTimeStamp(),
                        AuthMatchUtil.MX_AUTH_DATE_TIME_FORMAT)
                    : "");
            submissionMatchResponse.setRocAuthDAC(rocMatchRequest.getRocAuthDAC());
            submissionMatchResponse.setRocCardNumber(rocMatchRequest.getRocCardNumber());
            submissionMatchResponse.setRocSENumber(rocMatchRequest.getRocSENumber());
          }
        }
      }
    } catch (Exception e) {
      LOGGER.error(
          "{}| Error in Match by Tier 3b",
          authMatchLog.getCommonLogAttributes("S", "GE000M04", rocMatchRequest),
          ITier.REQUESTHANDLER,
          CLASS_NAME,
          "ComputeJobProcess");
      rocMatched = false;
    }
    submissionMatchResponse.setMatched(rocMatched);
    return submissionMatchResponse;
  }

  /*
   * 1 -> Set keys for lookup - card number, DAC6 and date without time
   * 2 -> Get records from cache and validate that there is only one record before update
   * 				TO DO - Handle the scenario of multiple records
   * 3 -> Get CardAuthCache key, DAC6 key and DAC2 key to be removed if match is success
   * 4 -> Match for level 4 criteria - same CM15, same APPROVAL_CD, same SE10* and CAS transaction date between (-7, +1) of ROC charge date and Amount leverage**
   * 5 -> Run update statement to update flag if matched
   * 6 -> If match level 4 is not successful then match for level 5 criteria -
   * 				same CM15, same APPROVAL_CD and CAS transaction date between (-7, +1) of ROC charge date and Amount leverage**
   * 7 -> Run update statement to update flag if matched
   */
  public SubmissionMatchResponse matchByCardDac6AndAmoutLeverageSEDate(
      RocMatchRequest rocMatchRequest, SubmissionMatchResponse submissionMatchResponse) {
    boolean rocMatched = false;
    Date authDateTime = null;
    BigDecimal rocLocalAmount = null;
    BigDecimal rocAmount = null;
    BigDecimal authAmount = null;
    BigDecimal lowerMultiplier = BigDecimal.valueOf(0);
    BigDecimal higherMultiplier = BigDecimal.valueOf(0);
    boolean isLocalAmount = false;

    try {
      if (rocMatchRequest.getRocLocalAmount() != null
          && rocMatchRequest.getRocLocalDecimalPlaces() != null) {
        Double localDecimalPlaces = Double.valueOf(rocMatchRequest.getRocLocalDecimalPlaces());
        Double localamount =
            (Double.valueOf(rocMatchRequest.getRocLocalAmount())
                / (((int) Math.pow(10, localDecimalPlaces))));
        if (org.apache.commons.lang.StringUtils.isNotEmpty(
            rocMatchRequest.getRocLocalDecimalPlaces())) {
          rocLocalAmount = new BigDecimal(localamount.toString());
        } else {
          rocLocalAmount = new BigDecimal(localamount).setScale(2, RoundingMode.FLOOR);
        }
      }
    } catch (Exception e) {
    }

    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    try {

      BinaryObject industryLeverageBinaryBean =
          (BinaryObject)
              igniteProvider.getCache(
                  AuthMatchConstants.SE_SE_INDUSTRY_LEVERAGE_CACHE,
                  rocMatchRequest.getSocSEIndustryCategoryCode());
      if (industryLeverageBinaryBean == null) {
        industryLeverageBinaryBean =
            (BinaryObject)
                igniteProvider.getCache(AuthMatchConstants.SE_SE_INDUSTRY_LEVERAGE_CACHE, "Others");
      }
      if (industryLeverageBinaryBean != null) {
        lowerMultiplier = industryLeverageBinaryBean.field("lowerMultiplier");
        higherMultiplier = industryLeverageBinaryBean.field("higherMultiplier");
      } else LOGGER.error("GR50011 - Industry Leverage cache does not exist or not created ");

      // 1 -> Set keys for lookup - card number, DAC6 and date without time

      CasAuthCardAccessCode6CacheBean cardDac6Bean =
          authMatchDAOImpl.getCardDac6Bean(
              AuthMatchConstants.CAS_AUTH_CM_DAC6_CACHE,
              authMatchDAOImpl.getCardDac6BinaryKey(
                  rocMatchRequest.getRocCardNumber(), rocMatchRequest.getRocAuthDAC(), "A"));

      if (cardDac6Bean != null) {
        if (rocLocalAmount != null && cardDac6Bean.getAuthAmountLocal() != null) {
          rocAmount = rocLocalAmount;
          authAmount = cardDac6Bean.getAuthAmountLocal();
          isLocalAmount = true;
        } else {
          rocAmount = new BigDecimal(rocMatchRequest.getRocAmountUSD());
          authAmount = cardDac6Bean.getAuthAmountUSD();
        }
      }

      try {
        if (StringUtils.isEmpty(
            StringUtils.trimTrailingWhitespace(rocMatchRequest.getRocTransactionTime()))) {
          rocMatchRequest.setRocTransactionTime("00:00:00");
        }
        sdf.setLenient(false);
        authDateTime =
            sdf.parse(
                rocMatchRequest.getRocTransactionDate()
                    + " "
                    + rocMatchRequest.getRocTransactionTime());
      } catch (ParseException e1) {
        LOGGER.error(
            "{}|Date parse exception in matchByCardDac6AndAmoutLeverageSEDate {} , {} ",
            authMatchLog.getCommonLogAttributes("S", "GR5001", rocMatchRequest),
            e1.getMessage(),
            e1);
        try {
          authDateTime = dateFormat.parse("1900-01-01 00:00:00");
        } catch (ParseException e) {
        }
      }
      LocalDateTime localDateTime =
          authDateTime.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
      Date fromDate =
          Date.from(localDateTime.minusDays(7).atZone(ZoneId.systemDefault()).toInstant());
      Date toDate = Date.from(localDateTime.plusDays(1).atZone(ZoneId.systemDefault()).toInstant());

      // 4 -> Match for level 4 criteria - same CM15, same APPROVAL_CD, same SE10* and CAS
      // transaction date between (-7, +1) of ROC charge date and Amount leverage**

      if (cardDac6Bean != null
          && rocMatchRequest.getRocSENumber() != null
          && isSEOrToocMatched(rocMatchRequest.getRocSENumber(), cardDac6Bean.getSeNumber())
          && cardDac6Bean.getAuthTransactionDateTime() != null
          && cardDac6Bean.getAuthTransactionDateTime().after(fromDate)
          && cardDac6Bean.getAuthTransactionDateTime().before(toDate)
          && (((rocAmount.compareTo(authAmount.multiply(lowerMultiplier)) >= 0)
                  && (rocAmount.compareTo(authAmount.multiply(higherMultiplier)) <= 0))
              || (authAmount.compareTo(rocAmount) > 0))) {
        BigDecimal matchAmount = cardDac6Bean.getMatchedAmountUSD();

        if (matchAmount == null) {
          matchAmount = new BigDecimal("0.00");
        } else {
          submissionMatchResponse.setMatchedMultipleRocToAuth(true);
        }

        matchAmount = matchAmount.add(rocAmount);
        cardDac6Bean.setMatchedAmountUSD(matchAmount);

        if (authAmount.compareTo(matchAmount) != 0) {
          submissionMatchResponse.setDoNotDeleteFlag(true);
        }
        // 5 -> Run update statement to update flag if matched
        cardDac6Bean.setRocAuthMatchedCriteriaId("T04");
        cardDac6Bean.setRocAuthMatchedFlag("Y");

        submissionMatchResponse.setMatched(rocMatched);
        submissionMatchResponse.setRamIndicator("1");
        submissionMatchResponse.setRamTier("T04");
        submissionMatchResponse.setResultRemarks(
            "4 -> Match by DAC6, Approval code, SE10, CAS date and amount leverage found in Cache"
                + (isLocalAmount ? " with Local amount" : ""));

        rocMatched = true;
      }
      // 6 -> Match for level 5 criteria - same CM15, same APPROVAL_CD, and CAS transaction date
      // between (-7, +1) of ROC charge date and Amount leverage**

      if (!rocMatched
          && cardDac6Bean != null
          && cardDac6Bean.getAuthTransactionDateTime() != null
          && cardDac6Bean.getAuthTransactionDateTime().after(fromDate)
          && cardDac6Bean.getAuthTransactionDateTime().before(toDate)
          && rocAmount != null
          && (rocAmount.compareTo(authAmount.multiply(lowerMultiplier)) >= 0)
          && (rocAmount.compareTo(authAmount.multiply(higherMultiplier)) <= 0)) {
        // 7 -> Run update statement to update flag if matched
        cardDac6Bean.setRocAuthMatchedCriteriaId("T04");
        cardDac6Bean.setRocAuthMatchedFlag("Y");

        submissionMatchResponse.setMatched(rocMatched);
        submissionMatchResponse.setRamIndicator("1");
        submissionMatchResponse.setRamTier("T05");
        submissionMatchResponse.setResultRemarks(
            "5 -> Match by DAC6, Approval code, CAS date and amount leverage found in Cache"
                + (isLocalAmount ? " with Local amount" : ""));
        rocMatched = true;
      }

      if (rocMatched) {
        igniteProvider.putCache(
            AuthMatchConstants.CAS_AUTH_CM_DAC6_CACHE,
            authMatchDAOImpl.getCardDac6BinaryKey(
                rocMatchRequest.getRocCardNumber(), rocMatchRequest.getRocAuthDAC(), "A"),
            authMatchDAOImpl.getCardDac6BinaryBean(cardDac6Bean));
        submissionMatchResponse.setCaspKey(cardDac6Bean.getAuthUniqueIdentifier());
        submissionMatchResponse.setAuthUniqueIdentifer(cardDac6Bean.getAuthUniqueIdentifier());
        submissionMatchResponse.setCacheKey(cardDac6Bean.getCacheStringKey());
        submissionMatchResponse.setCacheName(AuthMatchConstants.CAS_AUTH_CM_DAC6_CACHE);
        submissionMatchResponse.setDac6CardKey(cardDac6Bean.getCacheStringKey());
        submissionMatchResponse.setTidCardKey(cardDac6Bean.getTidCMPrimaryKey());
        submissionMatchResponse.setDac2CardKey(cardDac6Bean.getCardDac2PrimaryKey());
        submissionMatchResponse.setAuthSeNumber(cardDac6Bean.getSeNumber());
        submissionMatchResponse.setRocCardNumber(rocMatchRequest.getRocCardNumber());
        submissionMatchResponse.setRocSENumber(rocMatchRequest.getRocSENumber());
        submissionMatchResponse.setRocAuthDAC(rocMatchRequest.getRocAuthDAC());
        String[] keyList = cardDac6Bean.getTidCMPrimaryKey().split("\\|");
        if (keyList.length == 3) {
          CasAuthTransIdCardCacheBean transCardBean =
              authMatchDAOImpl.getTransCardBean(
                  AuthMatchConstants.CAS_AUTH_TID_CM_CACHE,
                  authMatchDAOImpl.getTransCardBinaryKey(keyList[0], keyList[1], keyList[2]));
          if (transCardBean != null) {
            submissionMatchResponse.setPosDataCode(transCardBean.getPosDataCode());
            submissionMatchResponse.setEciIndicator(transCardBean.getEciIndicator());
            submissionMatchResponse.setApprovalCode(cardDac6Bean.getAuth6Dac());
            submissionMatchResponse.setMcc(transCardBean.getMccMerchant());
            submissionMatchResponse.setVoiceAuthIndicator(transCardBean.getVoiceAuthIndicator());
            submissionMatchResponse.setTransactionId(transCardBean.getTransactionId());
            submissionMatchResponse.setEcbCreationTime(
                transCardBean.getTransactionTimeStamp() != null
                    ? AuthMatchUtil.getStringFromDate(
                        transCardBean.getTransactionTimeStamp(),
                        AuthMatchUtil.MX_AUTH_DATE_TIME_FORMAT)
                    : "");
          }
        }

        submissionMatchResponse.setRejIndicator("");
      }

    } catch (Exception e) {
      StringWriter outError = new StringWriter();
      e.printStackTrace(new PrintWriter(outError));
      String errorString = outError.toString();
      LOGGER.error(
          "Error in Match by cm15 , dac6 and approval code {} | {}",
          errorString,
          authMatchLog.getCommonLogAttributes("S", "GE000M08", rocMatchRequest),
          ITier.REQUESTHANDLER,
          CLASS_NAME,
          CLASS_NAME);

      rocMatched = false;
    }
    submissionMatchResponse.setMatched(rocMatched);
    return submissionMatchResponse;
  }

  /*
   * 1 -> Set keys for lookup - card number, DAC2 and date without time
   * 2 -> Get records from cache and validate that there is only one record before update
   * 				TO DO - Handle the scenario of multiple records
   * 3 -> Get CardAuthCache key, DAC2 key and DAC6 key to be removed if match is success
   * 4 -> Match for level 6 criteria - same CM15, same APPROVAL_2_CD, same SE10* and CAS transaction date between (-2, +1) of ROC charge date and Amount leverage**
   * 5 -> Run update statement to update flag if matched
   * 6 -> If match level 6 is not successful then match for level 7 criteria -
   * 				same CM15, same APPROVAL_2_CD and CAS transaction date between (-1, +1) of ROC charge date and Amount leverage**
   * 7 -> Run update statement to update flag if matched
   */
  public SubmissionMatchResponse matchByCardSEDac2AndAmoutLeverage(
      RocMatchRequest rocMatchRequest, SubmissionMatchResponse submissionMatchResponse) {
    boolean rocMatched = false;
    Date authDateTime = null;
    BigDecimal rocLocalAmount = null;
    BigDecimal rocAmount = null;
    BigDecimal authAmount = null;
    BigDecimal lowerMultiplier = BigDecimal.valueOf(0);
    BigDecimal higherMultiplier = BigDecimal.valueOf(0);
    boolean isLocalAmount = false;

    try {
      if (rocMatchRequest.getRocLocalAmount() != null
          && rocMatchRequest.getRocLocalDecimalPlaces() != null) {
        Double localDecimalPlaces = Double.valueOf(rocMatchRequest.getRocLocalDecimalPlaces());
        Double localamount =
            (Double.valueOf(rocMatchRequest.getRocLocalAmount())
                / (((int) Math.pow(10, localDecimalPlaces))));
        if (org.apache.commons.lang.StringUtils.isNotEmpty(
            rocMatchRequest.getRocLocalDecimalPlaces())) {
          rocLocalAmount = new BigDecimal(localamount.toString());
        } else {
          rocLocalAmount = new BigDecimal(localamount).setScale(2, RoundingMode.FLOOR);
        }
      }
    } catch (Exception e) {
    }

    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    try {

      BinaryObject industryLeverageBinaryBean =
          (BinaryObject)
              igniteProvider.getCache(
                  AuthMatchConstants.SE_SE_INDUSTRY_LEVERAGE_CACHE,
                  rocMatchRequest.getSocSEIndustryCategoryCode());
      if (industryLeverageBinaryBean == null) {
        industryLeverageBinaryBean =
            (BinaryObject)
                igniteProvider.getCache(AuthMatchConstants.SE_SE_INDUSTRY_LEVERAGE_CACHE, "Others");
      }
      if (industryLeverageBinaryBean != null) {
        lowerMultiplier = industryLeverageBinaryBean.field("lowerMultiplier");
        higherMultiplier = industryLeverageBinaryBean.field("higherMultiplier");
      } else LOGGER.error("GR50011 - Industry Leverage cache does not exist or not created ");

      // 1 -> Set keys for lookup - card number, DAC2 and date without time

      CasAuthCardAccessCode2CacheBean cardDac2Bean =
          authMatchDAOImpl.getCardDac2Bean(
              AuthMatchConstants.CAS_AUTH_CM_DAC2_CACHE,
              authMatchDAOImpl.getCardDac2BinaryKey(
                  rocMatchRequest.getRocCardNumber(), rocMatchRequest.getRocAuthDAC(), "A"));

      if (cardDac2Bean != null) {
        if (rocLocalAmount != null && cardDac2Bean.getAuthAmountLocal() != null) {
          rocAmount = rocLocalAmount;
          authAmount = cardDac2Bean.getAuthAmountLocal();
          isLocalAmount = true;
        } else {
          rocAmount = new BigDecimal(rocMatchRequest.getRocAmountUSD());
          authAmount = cardDac2Bean.getAuthAmountUSD();
        }
      }

      try {
        if (StringUtils.isEmpty(
            StringUtils.trimTrailingWhitespace(rocMatchRequest.getRocTransactionTime()))) {
          rocMatchRequest.setRocTransactionTime("00:00:00");
        }
        sdf.setLenient(false);
        authDateTime =
            sdf.parse(
                rocMatchRequest.getRocTransactionDate()
                    + " "
                    + rocMatchRequest.getRocTransactionTime());
      } catch (ParseException e1) {
        LOGGER.error(
            "{}|Date parse exception in matchByCardDac2AndAmoutLeverageSEDate {} , {} ",
            authMatchLog.getCommonLogAttributes("S", "GR5001", rocMatchRequest),
            e1.getMessage(),
            e1);
        try {
          authDateTime = dateFormat.parse("1900-01-01 00:00:00");
        } catch (ParseException e) {
        }
      }
      LocalDateTime localDateTime =
          authDateTime.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
      Date fromDate =
          Date.from(localDateTime.minusDays(2).atZone(ZoneId.systemDefault()).toInstant());
      Date toDate = Date.from(localDateTime.plusDays(1).atZone(ZoneId.systemDefault()).toInstant());

      // 4 -> Match for level 6 criteria - same CM15, same APPROVAL_CD, same SE10* and CAS
      // transaction date between (-2, +1) of ROC charge date and Amount leverage**

      if (cardDac2Bean != null
          && rocMatchRequest.getRocSENumber() != null
          && isSEOrToocMatched(rocMatchRequest.getRocSENumber(), cardDac2Bean.getSeNumber())
          && cardDac2Bean.getAuthTransactionDateTime() != null
          && cardDac2Bean.getAuthTransactionDateTime().after(fromDate)
          && cardDac2Bean.getAuthTransactionDateTime().before(toDate)
          && (((rocAmount.compareTo(authAmount.multiply(lowerMultiplier)) >= 0)
                  && (rocAmount.compareTo(authAmount.multiply(higherMultiplier)) <= 0))
              || (authAmount.compareTo(rocAmount) > 0))) {
        BigDecimal matchAmount = cardDac2Bean.getMatchedAmountUSD();

        if (matchAmount == null) {
          matchAmount = new BigDecimal("0.00");
        } else {
          submissionMatchResponse.setMatchedMultipleRocToAuth(true);
        }

        matchAmount = matchAmount.add(rocAmount);
        cardDac2Bean.setMatchedAmountUSD(matchAmount);

        if (authAmount.compareTo(matchAmount) != 0) {
          submissionMatchResponse.setDoNotDeleteFlag(true);
        }
        // 5 -> Run update statement to update flag if matched
        cardDac2Bean.setRocAuthMatchedCriteriaId("T06");
        cardDac2Bean.setRocAuthMatchedFlag("Y");

        submissionMatchResponse.setMatched(rocMatched);
        submissionMatchResponse.setRamIndicator("1");
        submissionMatchResponse.setRamTier("T06");
        submissionMatchResponse.setResultRemarks(
            "6 -> Match by DAC2, Approval code, SE10, CAS date and amount leverage found in Cache"
                + (isLocalAmount ? " with Local amount" : ""));

        rocMatched = true;
      }
      // 6 -> Match for level 7 criteria - same CM15, same APPROVAL_2_CD, and CAS transaction date
      // between (-1, +1) of ROC charge date and Amount leverage**

      fromDate = Date.from(localDateTime.minusDays(1).atZone(ZoneId.systemDefault()).toInstant());
      toDate = Date.from(localDateTime.plusDays(1).atZone(ZoneId.systemDefault()).toInstant());

      if (!rocMatched
          && cardDac2Bean != null
          && cardDac2Bean.getAuthTransactionDateTime() != null
          && cardDac2Bean.getAuthTransactionDateTime().after(fromDate)
          && cardDac2Bean.getAuthTransactionDateTime().before(toDate)
          && rocAmount != null
          && (rocAmount.compareTo(authAmount.multiply(lowerMultiplier)) >= 0)
          && (rocAmount.compareTo(authAmount.multiply(higherMultiplier)) <= 0)) {
        // 7 -> Run update statement to update flag if matched
        cardDac2Bean.setRocAuthMatchedCriteriaId("T07");
        cardDac2Bean.setRocAuthMatchedFlag("Y");

        submissionMatchResponse.setMatched(rocMatched);
        submissionMatchResponse.setRamIndicator("1");
        submissionMatchResponse.setRamTier("T07");
        submissionMatchResponse.setResultRemarks(
            "7 -> Match by DAC2, Approval code, CAS date and amount leverage found in Cache"
                + (isLocalAmount ? " with Local amount" : ""));
        rocMatched = true;
      }

      if (rocMatched) {
        igniteProvider.putCache(
            AuthMatchConstants.CAS_AUTH_CM_DAC2_CACHE,
            authMatchDAOImpl.getCardDac2BinaryKey(
                rocMatchRequest.getRocCardNumber(), rocMatchRequest.getRocAuthDAC(), "A"),
            authMatchDAOImpl.getCardDac2BinaryBean(cardDac2Bean));
        submissionMatchResponse.setCaspKey(cardDac2Bean.getAuthUniqueIdentifier());
        submissionMatchResponse.setAuthUniqueIdentifer(cardDac2Bean.getAuthUniqueIdentifier());
        submissionMatchResponse.setCacheKey(cardDac2Bean.getCacheStringKey());
        submissionMatchResponse.setCacheName(AuthMatchConstants.CAS_AUTH_CM_DAC2_CACHE);
        submissionMatchResponse.setDac2CardKey(cardDac2Bean.getCacheStringKey());
        submissionMatchResponse.setTidCardKey(cardDac2Bean.getTidCMPrimaryKey());
        submissionMatchResponse.setDac6CardKey(cardDac2Bean.getCardDac6PrimaryKey());
        submissionMatchResponse.setAuthSeNumber(cardDac2Bean.getSeNumber());
        submissionMatchResponse.setRocAuthDAC(rocMatchRequest.getRocAuthDAC());
        submissionMatchResponse.setRocCardNumber(rocMatchRequest.getRocCardNumber());
        submissionMatchResponse.setRocSENumber(rocMatchRequest.getRocSENumber());
        String[] keyList = cardDac2Bean.getTidCMPrimaryKey().split("\\|");
        if (keyList.length == 3) {
          CasAuthTransIdCardCacheBean transCardBean =
              authMatchDAOImpl.getTransCardBean(
                  AuthMatchConstants.CAS_AUTH_TID_CM_CACHE,
                  authMatchDAOImpl.getTransCardBinaryKey(keyList[0], keyList[1], keyList[2]));

          if (transCardBean != null) {
            submissionMatchResponse.setPosDataCode(transCardBean.getPosDataCode());
            submissionMatchResponse.setEciIndicator(transCardBean.getEciIndicator());
            submissionMatchResponse.setApprovalCode(cardDac2Bean.getAuth2Dac());
            submissionMatchResponse.setMcc(transCardBean.getMccMerchant());
            submissionMatchResponse.setVoiceAuthIndicator(transCardBean.getVoiceAuthIndicator());
            submissionMatchResponse.setTransactionId(transCardBean.getTransactionId());
            submissionMatchResponse.setEcbCreationTime(
                transCardBean.getTransactionTimeStamp() != null
                    ? AuthMatchUtil.getStringFromDate(
                        transCardBean.getTransactionTimeStamp(),
                        AuthMatchUtil.MX_AUTH_DATE_TIME_FORMAT)
                    : "");
          }
        }

        submissionMatchResponse.setRejIndicator("");
      }

    } catch (Exception e) {
      StringWriter outError = new StringWriter();
      e.printStackTrace(new PrintWriter(outError));
      String errorString = outError.toString();
      LOGGER.error(
          "Error in Match by cm15 , dac2 and approval code {} | {}",
          errorString,
          authMatchLog.getCommonLogAttributes("S", "GE000M10", rocMatchRequest),
          ITier.REQUESTHANDLER,
          CLASS_NAME,
          CLASS_NAME);

      rocMatched = false;
    }
    submissionMatchResponse.setMatched(rocMatched);
    return submissionMatchResponse;
  }

  public SubmissionMatchResponse matchByTier8(
      RocMatchRequest rocMatchRequest, SubmissionMatchResponse submissionMatchResponse) {
    boolean rocMatched = false;
    BigDecimal rocLocalAmount = null;
    BigDecimal rocAmount = null;
    BigDecimal authAmount = null;
    String approvalCode = "";
    boolean isLocalAmount = false;

    LOGGER.debug(
        "GRDEBUG3 - TID : {}, RocAmount : {}, ",
        rocMatchRequest.getRocAuthorizationTransactionId(),
        rocMatchRequest.getRocAmountUSD(),
        ITier.REQUESTHANDLER,
        CLASS_NAME,
        CLASS_NAME);

    try {
      if (rocMatchRequest.getRocLocalAmount() != null
          && rocMatchRequest.getRocLocalDecimalPlaces() != null) {
        Double localDecimalPlaces = Double.valueOf(rocMatchRequest.getRocLocalDecimalPlaces());
        Double localamount =
            (Double.valueOf(rocMatchRequest.getRocLocalAmount())
                / (((int) Math.pow(10, localDecimalPlaces))));
        if (org.apache.commons.lang.StringUtils.isNotEmpty(
            rocMatchRequest.getRocLocalDecimalPlaces())) {
          rocLocalAmount = new BigDecimal(localamount.toString());
        } else {
          rocLocalAmount = new BigDecimal(localamount).setScale(2, RoundingMode.FLOOR);
        }
      }
    } catch (Exception e) {
    }

    try {
      CasAuthTransIdCardCacheBean transCardBean =
          authMatchDAOImpl.getTransCardBean(
              AuthMatchConstants.CAS_AUTH_TID_CM_CACHE,
              authMatchDAOImpl.getTransCardBinaryKey(
                  rocMatchRequest.getRocAuthorizationTransactionId(),
                  rocMatchRequest.getRocCardNumber(),
                  "A"));
      if (transCardBean != null) {
        String[] dac6Key = transCardBean.getCardDac6PrimaryKey().split("\\|", 5);
        if (dac6Key.length > 0) approvalCode = dac6Key[1];
        if (rocLocalAmount != null && transCardBean.getAuthAmountLocal() != null) {
          rocAmount = rocLocalAmount;
          authAmount = transCardBean.getAuthAmountLocal();
          isLocalAmount = true;
        } else {
          rocAmount = new BigDecimal(rocMatchRequest.getRocAmountUSD());
          authAmount = transCardBean.getAuthAmountUSD();
        }
      }

      // Match with Tier 8 logic
      if (transCardBean != null && authAmount.compareTo(rocAmount) < 0) {
        BigDecimal difference = rocAmount.subtract(authAmount);

        LOGGER.debug(
            "GRDEBUG2 - TID : {}, AuthAmount : {}, Difference : {} ",
            rocMatchRequest.getRocAuthorizationTransactionId(),
            authAmount,
            difference,
            ITier.REQUESTHANDLER,
            CLASS_NAME,
            CLASS_NAME);

        String sqlStatement =
            String.format(
                AuthMatchConstants.getCasAuthDataByCardSE,
                AuthMatchConstants.CACHE_TABLENAME,
                rocMatchRequest.getRocCardNumber(),
                rocMatchRequest.getRocSENumber(),
                rocMatchRequest.getRocTransactionDate(),
                rocMatchRequest.getRocAuthorizationTransactionId(),
                rocMatchRequest.getRocAmountUSD());

        List<List<?>> resultSet =
            igniteProvider.getCacheData(AuthMatchConstants.CAS_AUTH_TID_CM_CACHE, sqlStatement);
        if (resultSet != null && resultSet.size() > 1 && resultSet.size() < 1000) {
          LOGGER.debug(
              "GRDEBUG1 - TID : {}, Record count : {} ",
              rocMatchRequest.getRocAuthorizationTransactionId(),
              resultSet.size(),
              ITier.REQUESTHANDLER,
              CLASS_NAME,
              CLASS_NAME);
          List<String> transactionIdList = new ArrayList<String>();
          ArrayList<String> tidCardKeysList = new ArrayList<String>();
          ArrayList<String> dac6KeysList = new ArrayList<String>();
          ArrayList<String> dac2KeysList = new ArrayList<String>();
          BigDecimal sumOfAuthAmount = BigDecimal.ZERO;
          for (Object next : resultSet) {
            BigDecimal authAmountUsd = (BigDecimal) ((ArrayList) next).get(0);
            String transId = (String) ((ArrayList) next).get(1);
            String dac6Key = (String) ((ArrayList) next).get(2);
            String dac2Key = (String) ((ArrayList) next).get(3);
            transactionIdList.add(transId);
            dac6KeysList.add(dac6Key);
            dac2KeysList.add(dac2Key);
            sumOfAuthAmount = sumOfAuthAmount.add(authAmountUsd);
          }
          if (difference.compareTo(sumOfAuthAmount) == 0) {
            // Match by 8
            rocMatched = true;
            transCardBean.setRocAuthMatchedCriteriaId("T08");
            transCardBean.setRocAuthMatchedFlag("Y");
            igniteProvider.putCache(
                AuthMatchConstants.CAS_AUTH_TID_CM_CACHE,
                authMatchDAOImpl.getTransCardBinaryKey(
                    rocMatchRequest.getRocAuthorizationTransactionId(),
                    rocMatchRequest.getRocCardNumber(),
                    "A"),
                authMatchDAOImpl.getTransCardBinaryBean(transCardBean));

            submissionMatchResponse.setRamIndicator("1");
            submissionMatchResponse.setRamTier("T08");
            submissionMatchResponse.setTransactionId(transCardBean.getTransactionId());
            submissionMatchResponse.setResultRemarks(
                "8 -> Match by CM, SE and CAS Date found in Cache");

            final CasAuthTransIdCardCacheBean transCardBeanTemp = transCardBean;
            transactionIdList.forEach(
                tranId -> {
                  String cacheKey2 =
                      tranId
                          + "|"
                          + transCardBeanTemp.getCardNumber()
                          + "|"
                          + transCardBeanTemp.getApproveDenyCode();
                  tidCardKeysList.add(cacheKey2);
                });
            submissionMatchResponse.setCaspKey(transCardBean.getAuthUniqueIdentifier());
            submissionMatchResponse.setAuthUniqueIdentifer(transCardBean.getAuthUniqueIdentifier());
            submissionMatchResponse.setCacheKey(transCardBean.getCacheStringKey());
            submissionMatchResponse.setCacheName(AuthMatchConstants.CAS_AUTH_TID_CM_CACHE);
            submissionMatchResponse.setAuthSeNumber(transCardBean.getSeNumber());
            submissionMatchResponse.setTidCardKey(transCardBean.getCacheStringKey());
            submissionMatchResponse.setTidCardKeysList(tidCardKeysList);
            submissionMatchResponse.setDac6CardKey(transCardBean.getCardDac6PrimaryKey());
            submissionMatchResponse.setDac6CardKeysList(dac6KeysList);
            submissionMatchResponse.setDac2CardKey(transCardBean.getCardDac2PrimaryKey());
            submissionMatchResponse.setDac2CardKeysList(dac2KeysList);

            submissionMatchResponse.setPosDataCode(transCardBean.getPosDataCode());
            submissionMatchResponse.setEciIndicator(transCardBean.getEciIndicator());
            submissionMatchResponse.setApprovalCode(approvalCode);
            submissionMatchResponse.setMcc(transCardBean.getMccMerchant());
            submissionMatchResponse.setVoiceAuthIndicator(transCardBean.getVoiceAuthIndicator());
            submissionMatchResponse.setRejIndicator("");
            submissionMatchResponse.setEcbCreationTime(
                transCardBean.getTransactionTimeStamp() != null
                    ? AuthMatchUtil.getStringFromDate(
                        transCardBean.getTransactionTimeStamp(),
                        AuthMatchUtil.MX_AUTH_DATE_TIME_FORMAT)
                    : "");
            submissionMatchResponse.setRocAuthDAC(rocMatchRequest.getRocAuthDAC());
            submissionMatchResponse.setRocCardNumber(rocMatchRequest.getRocCardNumber());
            submissionMatchResponse.setRocSENumber(rocMatchRequest.getRocSENumber());
          }
        }
      }
    } catch (Exception e) {
      LOGGER.error(
          "{}| Error in Match by Approved TID and Amount",
          authMatchLog.getCommonLogAttributes("S", "GE000M04", rocMatchRequest),
          ITier.REQUESTHANDLER,
          CLASS_NAME,
          "ComputeJobProcess");
      rocMatched = false;
    }
    submissionMatchResponse.setMatched(rocMatched);
    return submissionMatchResponse;
  }

  public SubmissionMatchResponse matchByTier9(
      RocMatchRequest rocMatchRequest, SubmissionMatchResponse submissionMatchResponse) {
    boolean rocMatched = false;
    BigDecimal rocLocalAmount = null;
    BigDecimal rocAmount = null;
    BigDecimal authAmount = null;
    String approvalCode = "";
    boolean isLocalAmount = false;
    BigDecimal lowerMultiplier = BigDecimal.valueOf(0);
    BigDecimal higherMultiplier = BigDecimal.valueOf(0);

    try {
      if (rocMatchRequest.getRocLocalAmount() != null
          && rocMatchRequest.getRocLocalDecimalPlaces() != null) {
        Double localDecimalPlaces = Double.valueOf(rocMatchRequest.getRocLocalDecimalPlaces());
        Double localamount =
            (Double.valueOf(rocMatchRequest.getRocLocalAmount())
                / (((int) Math.pow(10, localDecimalPlaces))));
        if (org.apache.commons.lang.StringUtils.isNotEmpty(
            rocMatchRequest.getRocLocalDecimalPlaces())) {
          rocLocalAmount = new BigDecimal(localamount.toString());
        } else {
          rocLocalAmount = new BigDecimal(localamount).setScale(2, RoundingMode.FLOOR);
        }
      }
    } catch (Exception e) {
    }

    try {
      BinaryObject industryLeverageBinaryBean =
          (BinaryObject)
              igniteProvider.getCache(
                  AuthMatchConstants.SE_SE_INDUSTRY_LEVERAGE_CACHE,
                  rocMatchRequest.getSocSEIndustryCategoryCode());
      if (industryLeverageBinaryBean == null) {
        industryLeverageBinaryBean =
            (BinaryObject)
                igniteProvider.getCache(AuthMatchConstants.SE_SE_INDUSTRY_LEVERAGE_CACHE, "Others");
      }
      if (industryLeverageBinaryBean != null) {
        lowerMultiplier = industryLeverageBinaryBean.field("lowerMultiplier");
        higherMultiplier = industryLeverageBinaryBean.field("higherMultiplier");
      } else LOGGER.error("GR50011 - Industry Leverage cache does not exist or not created ");

      SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
      Date rocDateTime = null;
      try {
        if (StringUtils.isEmpty(
            StringUtils.trimTrailingWhitespace(rocMatchRequest.getRocTransactionTime()))) {
          rocMatchRequest.setRocTransactionTime("00:00:00");
        }
        sdf.setLenient(false);
        rocDateTime =
            sdf.parse(
                rocMatchRequest.getRocTransactionDate()
                    + " "
                    + rocMatchRequest.getRocTransactionTime());
      } catch (ParseException e1) {
        LOGGER.error(
            "{}|Date parse exception in matchByCardDac2AndAmoutLeverageSEDate {} , {} ",
            authMatchLog.getCommonLogAttributes("S", "GR5001", rocMatchRequest),
            e1.getMessage(),
            e1);
        try {
          rocDateTime = dateFormat.parse("1900-01-01 00:00:00");
        } catch (ParseException e) {
        }
      }
      LocalDateTime localDateTime =
          rocDateTime.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
      String fromDate = (localDateTime.minusDays(1)).format(DateTimeFormatter.ISO_LOCAL_DATE);
      // this date should be until EOD of current date
      String toDate =
          (localDateTime.plusDays(1)).format(DateTimeFormatter.ISO_LOCAL_DATE) + " 23:59:59";

      String sqlStatement =
          String.format(
              AuthMatchConstants.getCasAuthDataByTier9,
              AuthMatchConstants.CACHE_TABLENAME,
              rocMatchRequest.getRocCardNumber(),
              rocMatchRequest.getRocSENumber(),
              fromDate,
              toDate);

      List<List<?>> resultSet =
          igniteProvider.getCacheData(AuthMatchConstants.CAS_AUTH_TID_CM_CACHE, sqlStatement);

      if (resultSet != null && resultSet.size() == 1) {
        Object next = resultSet.get(0);
        String transId = (String) ((ArrayList) next).get(0);
        String dac6Key = (String) ((ArrayList) next).get(1);
        CasAuthTransIdCardCacheBean transCardBean =
            authMatchDAOImpl.getTransCardBean(
                AuthMatchConstants.CAS_AUTH_TID_CM_CACHE,
                authMatchDAOImpl.getTransCardBinaryKey(
                    transId, rocMatchRequest.getRocCardNumber(), "A"));
        if (transCardBean != null) {
          if (rocLocalAmount != null && transCardBean.getAuthAmountLocal() != null) {
            rocAmount = rocLocalAmount;
            authAmount = transCardBean.getAuthAmountLocal();
            isLocalAmount = true;
          } else {
            rocAmount = new BigDecimal(rocMatchRequest.getRocAmountUSD());
            authAmount = transCardBean.getAuthAmountUSD();
          }
        }

        if (transCardBean != null
            && (rocAmount.compareTo(authAmount.multiply(lowerMultiplier)) >= 0)
            && (rocAmount.compareTo(authAmount.multiply(higherMultiplier)) <= 0)) {
          rocMatched = true;
          transCardBean.setRocAuthMatchedCriteriaId("T09");
          transCardBean.setRocAuthMatchedFlag("Y");
          igniteProvider.putCache(
              AuthMatchConstants.CAS_AUTH_TID_CM_CACHE,
              authMatchDAOImpl.getTransCardBinaryKey(
                  transId, rocMatchRequest.getRocCardNumber(), "A"),
              authMatchDAOImpl.getTransCardBinaryBean(transCardBean));
          submissionMatchResponse.setRamIndicator("1");
          submissionMatchResponse.setRamTier("T09");
          submissionMatchResponse.setAuthSeNumber(transCardBean.getSeNumber());
          submissionMatchResponse.setTransactionId(transCardBean.getTransactionId());
          submissionMatchResponse.setResultRemarks(
              "9 -> Match by CM, SE, CAS Date, amount found in Cache"
                  + (isLocalAmount ? " with Local amount" : ""));
          submissionMatchResponse.setCaspKey(transCardBean.getAuthUniqueIdentifier());
          submissionMatchResponse.setAuthUniqueIdentifer(transCardBean.getAuthUniqueIdentifier());
          submissionMatchResponse.setCacheKey(transCardBean.getCacheStringKey());
          submissionMatchResponse.setCacheName(AuthMatchConstants.CAS_AUTH_TID_CM_CACHE);
          submissionMatchResponse.setTidCardKey(transCardBean.getCacheStringKey());
          submissionMatchResponse.setDac6CardKey(transCardBean.getCardDac6PrimaryKey());
          submissionMatchResponse.setDac2CardKey(transCardBean.getCardDac2PrimaryKey());
          submissionMatchResponse.setPosDataCode(transCardBean.getPosDataCode());
          submissionMatchResponse.setEciIndicator(transCardBean.getEciIndicator());
          submissionMatchResponse.setApprovalCode((dac6Key.split("\\|", 5)[1]).toString());
          submissionMatchResponse.setMcc(transCardBean.getMccMerchant());
          submissionMatchResponse.setVoiceAuthIndicator(transCardBean.getVoiceAuthIndicator());
          submissionMatchResponse.setRejIndicator("");
          submissionMatchResponse.setEcbCreationTime(
              transCardBean.getTransactionTimeStamp() != null
                  ? AuthMatchUtil.getStringFromDate(
                      transCardBean.getTransactionTimeStamp(),
                      AuthMatchUtil.MX_AUTH_DATE_TIME_FORMAT)
                  : "");
          submissionMatchResponse.setRocAuthDAC(rocMatchRequest.getRocAuthDAC());
          submissionMatchResponse.setRocCardNumber(rocMatchRequest.getRocCardNumber());
          submissionMatchResponse.setRocSENumber(rocMatchRequest.getRocSENumber());
        }
      }
    } catch (Exception e) {
      LOGGER.error(
          "{}| Error in Match by Approved TID and Amount",
          authMatchLog.getCommonLogAttributes("S", "GE000M09", rocMatchRequest),
          ITier.REQUESTHANDLER,
          CLASS_NAME,
          "ComputeJobProcess");
      rocMatched = false;
    }
    submissionMatchResponse.setMatched(rocMatched);
    return submissionMatchResponse;
  }

  /*
   * 1 -> Set keys for lookup - card number, SE number
   * 2 -> Get records from cache and if there is only one record then
   * 3 -> If CAS date of this identified transaction lies between (-7, +1) of the ROC charge date
   * 4 -> Auth amount is between (0.75, 1.25) of ROC amount
   * 5 -> this ROC is considered matched with RAM indicator = 1 and RAM_TIER = 11.
   */
  public SubmissionMatchResponse matchByCardNumberAndSeNumber(
      RocMatchRequest rocMatchRequest, SubmissionMatchResponse submissionMatchResponse) {
    boolean rocMatched = false;
    Date authDateTime = null;
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    BigDecimal rocLocalAmount = null;
    boolean isLocalAmount = false;
    BigDecimal rocAmount = null;
    BigDecimal authAmount = null;
    String queryString = AuthMatchConstants.CASAUTH_DATABY_CARD_SE_DATE;

    try {
      if (StringUtils.isEmpty(
          StringUtils.trimTrailingWhitespace(rocMatchRequest.getRocTransactionTime()))) {
        rocMatchRequest.setRocTransactionTime("00:00:00");
      }
      sdf.setLenient(false);
      authDateTime =
          sdf.parse(
              rocMatchRequest.getRocTransactionDate()
                  + " "
                  + rocMatchRequest.getRocTransactionTime());
    } catch (ParseException e1) {
      LOGGER.error(
          "{}|Date parse exception in matchByCardNumberAndSeNumber {} , {} ",
          authMatchLog.getCommonLogAttributes("S", "GR5011", rocMatchRequest),
          e1.getMessage(),
          e1);
      try {
        authDateTime = dateFormat.parse("1900-01-01 00:00:00");
      } catch (ParseException e) {
      }
    }
    try {
      if (rocMatchRequest.getRocLocalAmount() != null
          && rocMatchRequest.getRocLocalDecimalPlaces() != null) {
        Double localDecimalPlaces = Double.valueOf(rocMatchRequest.getRocLocalDecimalPlaces());
        Double localamount =
            (Double.valueOf(rocMatchRequest.getRocLocalAmount())
                / (((int) Math.pow(10, localDecimalPlaces))));
        if (org.apache.commons.lang.StringUtils.isNotEmpty(
            rocMatchRequest.getRocLocalDecimalPlaces())) {
          rocLocalAmount = new BigDecimal(localamount.toString());
        } else {
          rocLocalAmount = new BigDecimal(localamount).setScale(2, RoundingMode.FLOOR);
        }
      }
    } catch (Exception e) {
      LOGGER.error("localamount Conversion Issue ", e.getMessage(), e);
    }

    if (rocLocalAmount != null && rocMatchRequest.getRocLocalAmount() != null) {
      rocAmount = rocLocalAmount;
      isLocalAmount = true;
      queryString = AuthMatchConstants.CASAUTH_DATABY_CARD_SE_DATE_LOCAL_AMOUNT;
    } else {
      rocAmount = new BigDecimal(rocMatchRequest.getRocAmountUSD());
    }

    try {
      LocalDateTime localDateTime =
          authDateTime.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
      String fromDate = (localDateTime.minusDays(7).format(DateTimeFormatter.ISO_LOCAL_DATE));
      String toDate = (localDateTime.plusDays(1).format(DateTimeFormatter.ISO_LOCAL_DATE));

      String sqlStatement =
          String.format(
              queryString,
              AuthMatchConstants.CACHE_TABLENAME,
              rocMatchRequest.getRocCardNumber(),
              rocMatchRequest.getRocSENumber(),
              fromDate,
              toDate,
              rocAmount,
              rocAmount);

      List<List<?>> resultSet =
          igniteProvider.getCacheData(AuthMatchConstants.CAS_AUTH_TID_CM_CACHE, sqlStatement);

      if (resultSet != null && resultSet.size() == 1) {
        Object next = resultSet.get(0);
        BigDecimal authAmountUSD = (BigDecimal) ((ArrayList) next).get(0);
        String transId = (String) ((ArrayList) next).get(1);
        authAmount = authAmountUSD;
        if (transId != null) {
          rocMatched = true;
          CasAuthTransIdCardCacheBean transCardBean =
              authMatchDAOImpl.getTransCardBean(
                  AuthMatchConstants.CAS_AUTH_TID_CM_CACHE,
                  authMatchDAOImpl.getTransCardBinaryKey(
                      transId, rocMatchRequest.getRocCardNumber(), "A"));
          transCardBean.setRocAuthMatchedCriteriaId("T11");
          transCardBean.setRocAuthMatchedFlag("Y");
          igniteProvider.putCache(
              AuthMatchConstants.CAS_AUTH_TID_CM_CACHE,
              authMatchDAOImpl.getTransCardBinaryKey(
                  rocMatchRequest.getRocAuthorizationTransactionId(),
                  rocMatchRequest.getRocCardNumber(),
                  "A"),
              authMatchDAOImpl.getTransCardBinaryBean(transCardBean));

          String[] approvalCode = transCardBean.getCardDac6PrimaryKey().split("\\|", 5);

          submissionMatchResponse.setCaspKey(transCardBean.getAuthUniqueIdentifier());
          submissionMatchResponse.setAuthUniqueIdentifer(transCardBean.getAuthUniqueIdentifier());
          submissionMatchResponse.setPosDataCode(transCardBean.getPosDataCode());
          submissionMatchResponse.setEciIndicator(transCardBean.getEciIndicator());
          submissionMatchResponse.setApprovalCode(approvalCode[1]);
          submissionMatchResponse.setMcc(transCardBean.getMccMerchant());
          submissionMatchResponse.setVoiceAuthIndicator(transCardBean.getVoiceAuthIndicator());
          submissionMatchResponse.setRejIndicator("");

          submissionMatchResponse.setRamIndicator("1");
          submissionMatchResponse.setRamTier("T11");
          submissionMatchResponse.setTransactionId(transCardBean.getTransactionId());
          submissionMatchResponse.setResultRemarks(
              "11 -> Match by Card number and SE number found in Cache"
                  + (isLocalAmount ? " with Local amount" : ""));
          submissionMatchResponse.setCacheKey(transCardBean.getCacheStringKey());
          submissionMatchResponse.setCacheName(AuthMatchConstants.CAS_AUTH_TID_CM_CACHE);
          submissionMatchResponse.setTidCardKey(transCardBean.getCacheStringKey());
          submissionMatchResponse.setDac6CardKey(transCardBean.getCardDac6PrimaryKey());
          submissionMatchResponse.setDac2CardKey(transCardBean.getCardDac2PrimaryKey());
          submissionMatchResponse.setEcbCreationTime(
              transCardBean.getTransactionTimeStamp() != null
                  ? AuthMatchUtil.getStringFromDate(
                      transCardBean.getTransactionTimeStamp(),
                      AuthMatchUtil.MX_AUTH_DATE_TIME_FORMAT)
                  : "");
          submissionMatchResponse.setAuthSeNumber(transCardBean.getSeNumber());
          submissionMatchResponse.setRocAuthDAC(rocMatchRequest.getRocAuthDAC());
          submissionMatchResponse.setRocCardNumber(rocMatchRequest.getRocCardNumber());
          submissionMatchResponse.setRocSENumber(rocMatchRequest.getRocSENumber());
        }
      }
    } catch (Exception e) {
      LOGGER.error(
          "{}| Error in Match by Card number and SE number",
          authMatchLog.getCommonLogAttributes("S", "GE000M11", rocMatchRequest),
          ITier.REQUESTHANDLER,
          CLASS_NAME,
          "ComputeJobProcess");
      rocMatched = false;
      LOGGER.error("{} Error during Match by Card number and SE number", e.getMessage());
    }
    submissionMatchResponse.setMatched(rocMatched);
    return submissionMatchResponse;
  }

  private boolean isSEOrToocMatched(String seNumberFromRocMatchRequest, String seNumberFromCache) {
    try {
      if (seNumberFromRocMatchRequest.equals(seNumberFromCache)) {
        return true;
      } else {

        LOGGER.debug("isSEOrToocMatched", ITier.REQUESTHANDLER, CLASS_NAME, CLASS_NAME);

        String topofChainRoc = seChar501Ignite.get(seNumberFromRocMatchRequest).getTopOfChain();

        LOGGER.debug(
            "isSEOrToocMatched RocValue for Se"
                + seNumberFromRocMatchRequest
                + "= "
                + topofChainRoc,
            ITier.REQUESTHANDLER,
            CLASS_NAME,
            CLASS_NAME);

        String topofChainAuth = seChar501Ignite.get(seNumberFromCache).getTopOfChain();

        LOGGER.debug(
            "Looked up Roc SE from Cache" + seNumberFromCache + "-" + topofChainAuth,
            ITier.REQUESTHANDLER,
            CLASS_NAME,
            CLASS_NAME);

        if (!StringUtils.isEmpty(topofChainRoc)
            && !topofChainRoc.equals("0")
            && !StringUtils.isEmpty(topofChainAuth)
            && !topofChainAuth.equals("0")
            && topofChainRoc.trim().equals(topofChainAuth.trim())) {
          return true;
        } else {
          if (rocAuthSeHistoryIgnite.get(
                  new RocAuthSEHistoryKey(seNumberFromRocMatchRequest, seNumberFromCache))
              != null) {
            return true;
          }
        }
      }
    } catch (Exception e) {
      LOGGER.error("Error:", e);
      return false;
    }
    return false;
  }
}
