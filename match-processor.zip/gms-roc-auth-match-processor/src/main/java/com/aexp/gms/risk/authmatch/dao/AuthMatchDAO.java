package com.aexp.gms.risk.authmatch.dao;

import com.aexp.gms.imc.risk.rules.vo.keys.ICacheKey;
import com.aexp.gms.imc.risk.rules.vo.values.ICacheBean;
import com.aexp.gms.imc.risk.rules.vo.values.IndustryLeverageBean;
import com.aexp.gms.risk.authmatch.exception.AuthMatchSystemException;
import com.aexp.gms.risk.authmatch.model.CasAuthCardAccessCode2CacheBean;
import com.aexp.gms.risk.authmatch.model.CasAuthCardAccessCode6CacheBean;
import com.aexp.gms.risk.authmatch.model.CasAuthTransIdCardCacheBean;
import java.util.List;
import org.apache.ignite.binary.BinaryObject;

public interface AuthMatchDAO {

  public boolean getCache() throws AuthMatchSystemException;

  public ICacheBean getCacheData(String cacheName, ICacheKey key) throws AuthMatchSystemException;

  public String getAuthUniqueIdentifer(ICacheBean bean) throws AuthMatchSystemException;

  public List<List<?>> getCacheData(ICacheBean bean, String command)
      throws AuthMatchSystemException;

  public List<List<?>> getCacheData(String cacheName, String sql) throws AuthMatchSystemException;

  public boolean loadCache(ICacheKey key, ICacheBean bean) throws AuthMatchSystemException;

  public void putCache(String cacheName, Object key, Object value) throws AuthMatchSystemException;

  public int getCacheCount(String cacheName) throws AuthMatchSystemException;

  public boolean checkCacheData(BinaryObject cacheKey, String cacheName)
      throws AuthMatchSystemException;

  public boolean updateCache(String cacheName, String command) throws AuthMatchSystemException;

  public void setCacheProvider(IgniteProvider cacheProvider) throws AuthMatchSystemException;

  public IgniteProvider getCacheProvider() throws AuthMatchSystemException;

  public void removeCacheData(String cacheName, ICacheBean cacheBean)
      throws AuthMatchSystemException;

  public void removeCacheData(String cacheName, ICacheKey key) throws AuthMatchSystemException;

  public void removeCacheData(String cacheName, String cacheKey) throws AuthMatchSystemException;

  public boolean checkIgniteHealth();

  public IndustryLeverageBean getIndustryLeverageByCode(String cacheName, ICacheKey key)
      throws AuthMatchSystemException;

  public CasAuthTransIdCardCacheBean getTransCardBean(String cacheName, BinaryObject key)
      throws AuthMatchSystemException;

  public CasAuthCardAccessCode6CacheBean getCardDac6Bean(String cacheName, BinaryObject key)
      throws AuthMatchSystemException;

  public CasAuthCardAccessCode2CacheBean getCardDac2Bean(String cacheName, BinaryObject key)
      throws AuthMatchSystemException;

  public BinaryObject getTransCardBinaryBean(CasAuthTransIdCardCacheBean transCardBean)
      throws AuthMatchSystemException;

  public BinaryObject getCardDac6BinaryBean(CasAuthCardAccessCode6CacheBean cardDac6Bean)
      throws AuthMatchSystemException;

  public BinaryObject getCardDac2BinaryBean(CasAuthCardAccessCode2CacheBean cardDac2Bean)
      throws AuthMatchSystemException;

  public BinaryObject getTransCardBinaryKey(
      String transactionId, String cardNumber, String approveDenyCode)
      throws AuthMatchSystemException;

  public BinaryObject getCardDac6BinaryKey(
      String cardNumber, String auth6Dac, String approveDenyCode) throws AuthMatchSystemException;

  public BinaryObject getCardDac2BinaryKey(
      String cardNumber, String auth2Dac, String approveDenyCode) throws AuthMatchSystemException;
}
