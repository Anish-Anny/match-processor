package com.aexp.gms.risk.authmatch.model;

import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Builder
@Getter
@Setter
@AllArgsConstructor
@RequiredArgsConstructor
@EqualsAndHashCode
@ToString
public class RiskAssessmentRequest {

  private String request_unique_id;
  private String request_type;
  private String primary_account_number;
  private String merchant_number;
  private String transaction_id;
  private BigDecimal requested_amount = BigDecimal.valueOf(0L, 2);;
}
