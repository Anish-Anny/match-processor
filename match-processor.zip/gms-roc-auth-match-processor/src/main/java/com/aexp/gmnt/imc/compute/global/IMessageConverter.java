/** */
package com.aexp.gmnt.imc.compute.global;

/** @author vmuthusa */
public interface IMessageConverter {

  public IProgramData convert(String jsonMessage) throws IMCProcessException;
}
