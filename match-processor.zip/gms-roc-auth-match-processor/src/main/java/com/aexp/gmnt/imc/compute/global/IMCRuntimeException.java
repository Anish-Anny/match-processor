package com.aexp.gmnt.imc.compute.global;

public class IMCRuntimeException extends RuntimeException {

  public IMCRuntimeException() {}

  public IMCRuntimeException(String message) {
    super(message);
  }

  public IMCRuntimeException(Throwable cause) {
    super(cause);
  }

  public IMCRuntimeException(String message, Throwable cause) {
    super(message, cause);
  }

  public IMCRuntimeException(
      String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }
}
