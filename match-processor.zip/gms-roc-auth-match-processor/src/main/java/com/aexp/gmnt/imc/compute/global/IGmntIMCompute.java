package com.aexp.gmnt.imc.compute.global;

/**
 * @author akkore
 * @param <T>
 */
public interface IGmntIMCompute<T> {

  /**
   * @param object
   * @return
   * @throws IMCProcessException
   */
  IProgramData affinityCall(IProgramData inputData, String key, Long igniteTimeOut)
      throws IMCProcessException;

  void broadCastCacheVersion();
}
